# Build BT Kite Android APK with GitHub Actions

1. Upload the contents of this ZIP to the root of your GitHub repository (keep the `android-app` folder at repository root).
2. Ensure `.github/workflows/android-apk.yml` is included.
3. Commit to `main` or `master`, or open **Actions → BT Kite Android APK Build → Run workflow**.
4. Open the workflow run. If it succeeds, download **BT-Kite-Release-APK** under Artifacts.
5. If it fails, download **BT-Kite-Gradle-Build-Log** and share it. It contains the actual Kotlin/Gradle compiler error.

The workflow uses JDK 17 and Gradle 8.9 and builds `android-app/app` with `assembleRelease`.

## API key (optional)
The app can build without a Gemini API key. To enable cloud Gemini features, add a repository Actions secret named `GEMINI_API_KEY` and configure the Gradle build to read it if the app's current implementation requires it. Never commit API keys.
