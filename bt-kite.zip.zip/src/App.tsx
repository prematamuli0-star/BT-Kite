import { useEffect, useState } from 'react';
import { CameraModal } from './components/CameraModal';
import { EditorWorkspace } from './components/EditorWorkspace';
import { HomeHub } from './components/HomeHub';
import { OfflineIndicator } from './components/OfflineIndicator';
import { fetchAIStatus } from './lib/aiService';
import { clearCutoutCache } from './lib/backgroundRemoval';
import { loadImage } from './lib/imageEngine';
import { AIStatus, SourcePhoto } from './types/editor';

const DEFAULT_AI_STATUS: AIStatus = {
  localNeuralBgRemoval: true,
  localColorAndEnhance: true,
  localBrushObjectRemoval: true,
  geminiVisionAvailable: false,
  paidGenerativeImageAvailable: false,
  visionModel: null,
  generativeModels: null,
};

export default function App() {
  const [aiStatus, setAiStatus] = useState<AIStatus>(DEFAULT_AI_STATUS);
  const [activePhoto, setActivePhoto] = useState<SourcePhoto | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [intakeError, setIntakeError] = useState<string | null>(null);

  useEffect(() => {
    fetchAIStatus().then(setAiStatus);
  }, []);

  const openPhotoFromDataUrl = async (dataUrl: string, name: string, mimeType = 'image/jpeg') => {
    try {
      setIntakeError(null);
      const img = await loadImage(dataUrl);
      clearCutoutCache();
      setActivePhoto({
        id: `photo_${Date.now()}`,
        name,
        dataUrl,
        width: img.naturalWidth,
        height: img.naturalHeight,
        mimeType,
      });
    } catch {
      setIntakeError('Could not load that image file. Please try another JPG, PNG, or WebP photo.');
    }
  };

  const handleFileUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setIntakeError('Please select a valid image file (JPG, PNG, or WebP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        openPhotoFromDataUrl(reader.result, file.name, file.type || 'image/jpeg');
      }
    };
    reader.onerror = () => setIntakeError('Failed to read the selected file.');
    reader.readAsDataURL(file);
  };

  const handleSampleSelect = async (url: string, title: string) => {
    try {
      setIntakeError(null);
      const img = await loadImage(url);
      // Preserve clean data URL from sample photo so canvas operations never suffer taint issues
      const c = document.createElement('canvas');
      c.width = img.naturalWidth;
      c.height = img.naturalHeight;
      const ctx = c.getContext('2d');
      if (!ctx) throw new Error('Canvas unavailable');
      ctx.drawImage(img, 0, 0);
      const dataUrl = c.toDataURL('image/jpeg', 0.94);
      clearCutoutCache();
      setActivePhoto({
        id: `sample_${Date.now()}`,
        name: `${title}.jpg`,
        dataUrl,
        width: img.naturalWidth,
        height: img.naturalHeight,
        mimeType: 'image/jpeg',
      });
    } catch {
      setIntakeError('Unable to load sample photo. Please try uploading a photo from your device.');
    }
  };

  const handleCameraCapture = (dataUrl: string, width: number, height: number) => {
    clearCutoutCache();
    setActivePhoto({
      id: `camera_${Date.now()}`,
      name: `BT_Kite_Capture_${new Date().toISOString().slice(0, 10)}.jpg`,
      dataUrl,
      width,
      height,
      mimeType: 'image/jpeg',
    });
  };

  return (
    <>
      {intakeError && !activePhoto && (
        <div
          role="alert"
          className="fixed top-16 left-1/2 -translate-x-1/2 z-50 max-w-md rounded-xl bg-red-50 border border-red-200 px-4 py-2.5 text-xs font-semibold text-red-800 shadow-md flex items-center gap-3"
        >
          <span>{intakeError}</span>
          <button
            type="button"
            onClick={() => setIntakeError(null)}
            className="text-red-600 hover:text-red-900 font-bold cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {activePhoto ? (
        <EditorWorkspace
          key={activePhoto.id}
          sourcePhoto={activePhoto}
          aiStatus={aiStatus}
          onBack={() => setActivePhoto(null)}
        />
      ) : (
        <HomeHub
          aiStatus={aiStatus}
          onSelectFile={handleFileUpload}
          onOpenCamera={() => setCameraOpen(true)}
          onSelectSample={handleSampleSelect}
        />
      )}

      <CameraModal
        open={cameraOpen}
        onClose={() => setCameraOpen(false)}
        onCapture={handleCameraCapture}
      />

      <OfflineIndicator />
    </>
  );
}
