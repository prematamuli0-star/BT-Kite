import {
  BackgroundCategoryId,
  CameraAngle,
  CameraDistance,
  ColorAdjustments,
  ColorStyleId,
  DEFAULT_ADJUSTMENTS,
  LightingDirection,
  RecommendedBackgroundItem,
  SubjectPose,
} from '../types/editor';

export interface SamplePhotoPreset {
  id: string;
  title: string;
  category: string;
  subtitle: string;
  url: string;
}

export const SAMPLE_PHOTOS: SamplePhotoPreset[] = [
  {
    id: 'sample-portrait',
    title: 'City Street Portrait',
    category: 'Portrait',
    subtitle: 'Try Auto Background or Portrait Enhance',
    url: '/src/assets/images/sample_portrait_1795251947836.jpg',
  },
  {
    id: 'sample-product',
    title: 'Wireless Headphones',
    category: 'Product',
    subtitle: 'Try Product Studio Background & Clean Cutout',
    url: '/src/assets/images/sample_product_1795251949698.jpg',
  },
  {
    id: 'sample-street',
    title: 'Coastal Cafe Street',
    category: 'Travel & Street',
    subtitle: 'Try AI Color Tune & Golden Hour Grading',
    url: '/src/assets/images/sample_street_golden_1795252046830.jpg',
  },
];

export interface BackgroundPreset {
  id: BackgroundCategoryId;
  name: string;
  shortDesc: string;
  imageUrl?: string;
  gradientStops: [string, string, string];
  ambientTint: [number, number, number];
  ambientLuminance: number;
  defaultBlur: number;
  defaultShadow: number;
  /** Natural horizon / eye-line Y (0..1) and ground/seating contact Y (0..1) in the backdrop plate */
  horizonY: number;
  groundY: number;
  keyLightDirection: LightingDirection;
  suitablePoses: SubjectPose[];
  suitablePhotoTypes: string[];
  supportsSeatingOrSteps?: boolean;
  keywords: string[];
  proceduralStyle?:
    | 'studio-sweep'
    | 'passport'
    | 'luxury-marble'
    | 'nature-bokeh'
    | 'mountain-mist'
    | 'beach-horizon'
    | 'fashion-editorial'
    | 'business-slate'
    | 'product-podium'
    | 'cinematic-teal';
}

export const BACKGROUND_PRESETS: BackgroundPreset[] = [
  {
    id: 'professional-studio',
    name: 'Professional Studio',
    shortDesc: 'Soft diffused studio cyclorama',
    imageUrl: '/src/assets/images/bg_studio_pro_1795251948545.jpg',
    gradientStops: ['#e2e8f0', '#cbd5e1', '#94a3b8'],
    ambientTint: [232, 238, 246],
    ambientLuminance: 0.78,
    defaultBlur: 10,
    defaultShadow: 56,
    horizonY: 0.62,
    groundY: 0.84,
    keyLightDirection: 'top-left',
    suitablePoses: ['standing', 'posing', 'sitting', 'object_still_life'],
    suitablePhotoTypes: ['Portrait', 'Professional', 'Fashion', 'Product', 'Casual'],
    keywords: ['studio', 'portrait', 'clean', 'grey', 'gray', 'backdrop', 'soft', 'photography'],
  },
  {
    id: 'mountains',
    name: 'Mountain Viewpoint',
    shortDesc: 'Scenic alpine overlook with stone terrace',
    imageUrl: '/src/assets/images/bg_mountain_viewpoint_1795257729702.jpg',
    gradientStops: ['#dbeafe', '#93c5fd', '#475569'],
    ambientTint: [226, 238, 248],
    ambientLuminance: 0.76,
    defaultBlur: 14,
    defaultShadow: 54,
    horizonY: 0.42,
    groundY: 0.82,
    keyLightDirection: 'top-left',
    suitablePoses: ['sitting', 'standing', 'leaning', 'posing', 'walking'],
    suitablePhotoTypes: ['Travel', 'Outdoor', 'Landscape', 'Casual', 'Nature'],
    supportsSeatingOrSteps: true,
    keywords: ['mountain', 'mountains', 'viewpoint', 'alps', 'peak', 'travel', 'overlook', 'scenic', 'bench'],
  },
  {
    id: 'luxury-terrace',
    name: 'Luxury Outdoor Terrace',
    shortDesc: 'Travertine steps overlooking coastal hills',
    imageUrl: '/src/assets/images/bg_luxury_terrace_1795257731362.jpg',
    gradientStops: ['#f7f3eb', '#d8cab4', '#648da8'],
    ambientTint: [246, 239, 228],
    ambientLuminance: 0.8,
    defaultBlur: 18,
    defaultShadow: 52,
    horizonY: 0.48,
    groundY: 0.84,
    keyLightDirection: 'top-left',
    suitablePoses: ['sitting', 'leaning', 'standing', 'posing', 'walking'],
    suitablePhotoTypes: ['Travel', 'Luxury', 'Fashion', 'Wedding', 'Outdoor', 'Casual'],
    supportsSeatingOrSteps: true,
    keywords: ['terrace', 'balcony', 'steps', 'coastal', 'villa', 'resort', 'travel', 'luxury', 'sitting'],
  },
  {
    id: 'architectural-stairs',
    name: 'Modern Architectural Stairs',
    shortDesc: 'Sunlit minimalist limestone steps',
    imageUrl: '/src/assets/images/bg_architectural_stairs_1795257733752.jpg',
    gradientStops: ['#f1f5f9', '#e2dfd7', '#94a3b8'],
    ambientTint: [240, 238, 232],
    ambientLuminance: 0.79,
    defaultBlur: 14,
    defaultShadow: 58,
    horizonY: 0.46,
    groundY: 0.78,
    keyLightDirection: 'top-right',
    suitablePoses: ['sitting', 'leaning', 'standing', 'walking', 'posing'],
    suitablePhotoTypes: ['Fashion', 'Travel', 'Street', 'Casual', 'Outdoor', 'Portrait'],
    supportsSeatingOrSteps: true,
    keywords: ['stairs', 'steps', 'staircase', 'architectural', 'modern', 'sitting', 'concrete', 'urban'],
  },
  {
    id: 'office',
    name: 'Office',
    shortDesc: 'Modern architectural daylight workspace',
    imageUrl: '/src/assets/images/bg_luxury_office_1795251949962.jpg',
    gradientStops: ['#f5f0e8', '#e5dccf', '#c8bba8'],
    ambientTint: [244, 236, 224],
    ambientLuminance: 0.76,
    defaultBlur: 24,
    defaultShadow: 48,
    horizonY: 0.56,
    groundY: 0.84,
    keyLightDirection: 'right',
    suitablePoses: ['standing', 'sitting', 'leaning', 'posing'],
    suitablePhotoTypes: ['Professional', 'Portrait', 'Business', 'Indoor'],
    supportsSeatingOrSteps: true,
    keywords: ['office', 'corporate', 'desk', 'workspace', 'interior', 'executive', 'linkedin'],
  },
  {
    id: 'sunset',
    name: 'Sunset',
    shortDesc: 'Golden hour warm mountain horizon',
    imageUrl: '/src/assets/images/bg_sunset_nature_1795251948404.jpg',
    gradientStops: ['#fde68a', '#f59e0b', '#7c2d12'],
    ambientTint: [255, 206, 152],
    ambientLuminance: 0.68,
    defaultBlur: 18,
    defaultShadow: 56,
    horizonY: 0.44,
    groundY: 0.86,
    keyLightDirection: 'backlit',
    suitablePoses: ['standing', 'sitting', 'walking', 'posing', 'leaning'],
    suitablePhotoTypes: ['Travel', 'Outdoor', 'Landscape', 'Nature', 'Wedding', 'Portrait'],
    supportsSeatingOrSteps: true,
    keywords: ['sunset', 'golden', 'warm', 'dusk', 'sunrise', 'amber', 'horizon', 'scenic'],
  },
  {
    id: 'city',
    name: 'City',
    shortDesc: 'Blue-hour metropolitan avenue bokeh',
    imageUrl: '/src/assets/images/bg_city_cinematic_1795252046970.jpg',
    gradientStops: ['#1e3a8a', '#3b82f6', '#0f172a'],
    ambientTint: [176, 205, 246],
    ambientLuminance: 0.56,
    defaultBlur: 22,
    defaultShadow: 60,
    horizonY: 0.56,
    groundY: 0.84,
    keyLightDirection: 'top-right',
    suitablePoses: ['standing', 'walking', 'leaning', 'posing'],
    suitablePhotoTypes: ['Street', 'Fashion', 'Travel', 'Night', 'Portrait', 'Casual'],
    keywords: ['city', 'urban', 'street', 'skyline', 'night', 'lights', 'downtown'],
  },
  {
    id: 'wedding',
    name: 'Wedding',
    shortDesc: 'Romantic floral garden bokeh',
    imageUrl: '/src/assets/images/bg_wedding_floral_1795252046977.jpg',
    gradientStops: ['#fefce8', '#f0f4ea', '#d6e3cd'],
    ambientTint: [250, 245, 235],
    ambientLuminance: 0.84,
    defaultBlur: 26,
    defaultShadow: 44,
    horizonY: 0.55,
    groundY: 0.85,
    keyLightDirection: 'top-left',
    suitablePoses: ['standing', 'posing', 'walking', 'sitting'],
    suitablePhotoTypes: ['Wedding', 'Portrait', 'Outdoor', 'Fashion'],
    keywords: ['wedding', 'floral', 'garden', 'bride', 'romantic', 'flowers', 'ceremony'],
  },
  {
    id: 'passport-id',
    name: 'Passport / ID Photo',
    shortDesc: 'Official solid studio white or blue',
    gradientStops: ['#ffffff', '#f8fafc', '#f1f5f9'],
    ambientTint: [255, 255, 255],
    ambientLuminance: 0.92,
    defaultBlur: 0,
    defaultShadow: 12,
    horizonY: 0.5,
    groundY: 1.0,
    keyLightDirection: 'front-diffused',
    suitablePoses: ['standing', 'posing'],
    suitablePhotoTypes: ['Portrait', 'Professional'],
    keywords: ['passport', 'id', 'visa', 'white', 'document', 'official', 'license'],
    proceduralStyle: 'passport',
  },
  {
    id: 'luxury',
    name: 'Luxury',
    shortDesc: 'Warm travertine & champagne gold',
    gradientStops: ['#f7f3eb', '#dfd3be', '#9f8869'],
    ambientTint: [245, 233, 210],
    ambientLuminance: 0.72,
    defaultBlur: 20,
    defaultShadow: 58,
    horizonY: 0.56,
    groundY: 0.84,
    keyLightDirection: 'top-left',
    suitablePoses: ['standing', 'sitting', 'posing', 'object_still_life'],
    suitablePhotoTypes: ['Fashion', 'Portrait', 'Professional', 'Product', 'Wedding'],
    keywords: ['luxury', 'gold', 'marble', 'hotel', 'premium', 'champagne', 'elegant'],
    proceduralStyle: 'luxury-marble',
  },
  {
    id: 'nature',
    name: 'Nature',
    shortDesc: 'Sunlit botanical meadow depth',
    gradientStops: ['#d9f2dc', '#7db986', '#2f5e3e'],
    ambientTint: [222, 240, 224],
    ambientLuminance: 0.7,
    defaultBlur: 30,
    defaultShadow: 48,
    horizonY: 0.52,
    groundY: 0.84,
    keyLightDirection: 'top-left',
    suitablePoses: ['standing', 'sitting', 'walking', 'lying_down', 'posing'],
    suitablePhotoTypes: ['Nature', 'Outdoor', 'Travel', 'Casual', 'Portrait'],
    supportsSeatingOrSteps: true,
    keywords: ['nature', 'forest', 'park', 'green', 'trees', 'outdoor', 'botanical', 'leaves'],
    proceduralStyle: 'nature-bokeh',
  },
  {
    id: 'beach',
    name: 'Beach',
    shortDesc: 'Turquoise shoreline & bright sky',
    gradientStops: ['#e0f2fe', '#38bdf8', '#e7d5b5'],
    ambientTint: [232, 244, 250],
    ambientLuminance: 0.85,
    defaultBlur: 18,
    defaultShadow: 46,
    horizonY: 0.54,
    groundY: 0.84,
    keyLightDirection: 'top-left',
    suitablePoses: ['standing', 'sitting', 'walking', 'lying_down', 'posing'],
    suitablePhotoTypes: ['Travel', 'Outdoor', 'Casual', 'Landscape'],
    supportsSeatingOrSteps: true,
    keywords: ['beach', 'ocean', 'sea', 'coast', 'summer', 'sand', 'tropical'],
    proceduralStyle: 'beach-horizon',
  },
  {
    id: 'cinematic',
    name: 'Cinematic',
    shortDesc: 'Teal & amber filmic anamorphic depth',
    gradientStops: ['#0f2937', '#1e4e68', '#c27a44'],
    ambientTint: [195, 214, 224],
    ambientLuminance: 0.54,
    defaultBlur: 26,
    defaultShadow: 62,
    horizonY: 0.54,
    groundY: 0.84,
    keyLightDirection: 'top-right',
    suitablePoses: ['standing', 'leaning', 'posing', 'walking'],
    suitablePhotoTypes: ['Fashion', 'Street', 'Travel', 'Night', 'Portrait'],
    keywords: ['cinematic', 'film', 'movie', 'dramatic', 'moody', 'teal', 'neon'],
    proceduralStyle: 'cinematic-teal',
  },
  {
    id: 'fashion',
    name: 'Fashion',
    shortDesc: 'Editorial studio warm taupe gradient',
    gradientStops: ['#f4efe9', '#d6ccc2', '#9c8f84'],
    ambientTint: [242, 236, 228],
    ambientLuminance: 0.78,
    defaultBlur: 8,
    defaultShadow: 58,
    horizonY: 0.58,
    groundY: 0.86,
    keyLightDirection: 'top-left',
    suitablePoses: ['standing', 'posing', 'sitting', 'leaning', 'walking'],
    suitablePhotoTypes: ['Fashion', 'Portrait', 'Professional'],
    keywords: ['fashion', 'editorial', 'magazine', 'model', 'runway', 'minimal'],
    proceduralStyle: 'fashion-editorial',
  },
  {
    id: 'business-portrait',
    name: 'Business Portrait',
    shortDesc: 'Executive slate-blue studio vignette',
    gradientStops: ['#eff6ff', '#bfdbfe', '#1e3a8a'],
    ambientTint: [224, 236, 252],
    ambientLuminance: 0.74,
    defaultBlur: 12,
    defaultShadow: 48,
    horizonY: 0.52,
    groundY: 0.92,
    keyLightDirection: 'front-diffused',
    suitablePoses: ['standing', 'posing', 'sitting'],
    suitablePhotoTypes: ['Professional', 'Portrait'],
    keywords: ['business', 'headshot', 'resume', 'profile', 'executive', 'professional', 'blue'],
    proceduralStyle: 'business-slate',
  },
  {
    id: 'product-photography',
    name: 'Product Photography',
    shortDesc: 'Clean commercial studio pedestal',
    gradientStops: ['#ffffff', '#e8eff7', '#cbd5e1'],
    ambientTint: [245, 248, 252],
    ambientLuminance: 0.88,
    defaultBlur: 4,
    defaultShadow: 64,
    horizonY: 0.68,
    groundY: 0.82,
    keyLightDirection: 'top-left',
    suitablePoses: ['object_still_life'],
    suitablePhotoTypes: ['Product', 'Food'],
    keywords: ['product', 'ecommerce', 'catalog', 'shop', 'minimalist', 'podium', 'commercial'],
    proceduralStyle: 'product-podium',
  },
];

export const PASSPORT_COLORS = [
  { name: 'Pure White', hex: '#FFFFFF' },
  { name: 'Studio Ice', hex: '#F1F5F9' },
  { name: 'ID Blue', hex: '#DBEAFE' },
  { name: 'Classic Blue', hex: '#2563EB' },
  { name: 'Soft Gray', hex: '#CBD5E1' },
];

export interface ColorStylePreset {
  id: ColorStyleId;
  name: string;
  tagline: string;
  swatch: [string, string];
  adjustments: Partial<ColorAdjustments>;
}

export const COLOR_STYLE_PRESETS: ColorStylePreset[] = [
  {
    id: 'none',
    name: 'Original',
    tagline: 'No style overlay',
    swatch: ['#f8fafc', '#cbd5e1'],
    adjustments: {},
  },
  {
    id: 'natural',
    name: 'Natural',
    tagline: 'True-to-life balanced tone',
    swatch: ['#eff6ff', '#60a5fa'],
    adjustments: {
      exposure: 6,
      contrast: 8,
      highlights: -8,
      shadows: 12,
      vibrance: 10,
      clarity: 6,
      sharpness: 12,
    },
  },
  {
    id: 'cinematic',
    name: 'Cinematic',
    tagline: 'Filmic contrast & cool depth',
    swatch: ['#1e3a5f', '#d97706'],
    adjustments: {
      contrast: 18,
      highlights: -14,
      shadows: -8,
      blacks: -12,
      temperature: -8,
      tint: -4,
      saturation: -6,
      vibrance: 14,
      colorBalance: -14,
      clarity: 14,
    },
  },
  {
    id: 'professional-portrait',
    name: 'Pro Portrait',
    tagline: 'Flattering skin & soft lift',
    swatch: ['#fef3c7', '#f59e0b'],
    adjustments: {
      exposure: 8,
      contrast: 6,
      highlights: -12,
      shadows: 18,
      temperature: 6,
      skinTone: 18,
      vibrance: 8,
      clarity: 4,
      sharpness: 14,
      noiseReduction: 12,
    },
  },
  {
    id: 'hdr',
    name: 'HDR',
    tagline: 'Expanded dynamic range & crisp detail',
    swatch: ['#0284c7', '#38bdf8'],
    adjustments: {
      contrast: 16,
      highlights: -34,
      shadows: 36,
      whites: 10,
      blacks: -8,
      clarity: 26,
      vibrance: 18,
      sharpness: 22,
    },
  },
  {
    id: 'warm',
    name: 'Warm',
    tagline: 'Inviting sunlit amber tone',
    swatch: ['#fde68a', '#ea580c'],
    adjustments: {
      temperature: 22,
      tint: 4,
      exposure: 5,
      shadows: 10,
      vibrance: 12,
      skinTone: 10,
    },
  },
  {
    id: 'cool',
    name: 'Cool',
    tagline: 'Crisp Nordic azure clarity',
    swatch: ['#dbeafe', '#2563eb'],
    adjustments: {
      temperature: -22,
      tint: -4,
      contrast: 10,
      whites: 8,
      clarity: 10,
      colorBalance: -10,
    },
  },
  {
    id: 'luxury',
    name: 'Luxury',
    tagline: 'Rich editorial champagne depth',
    swatch: ['#e7e5e4', '#78716c'],
    adjustments: {
      contrast: 16,
      highlights: -10,
      blacks: -14,
      saturation: -12,
      vibrance: 12,
      temperature: 8,
      clarity: 16,
      sharpness: 16,
    },
  },
  {
    id: 'wedding',
    name: 'Wedding',
    tagline: 'Airy luminous pastel highlights',
    swatch: ['#fffbeb', '#f9a8d4'],
    adjustments: {
      exposure: 12,
      brightness: 6,
      contrast: -6,
      highlights: -16,
      shadows: 24,
      whites: 10,
      temperature: 6,
      tint: 6,
      saturation: -6,
      skinTone: 14,
    },
  },
  {
    id: 'film',
    name: 'Film',
    tagline: 'Analog 35mm tonal roll-off',
    swatch: ['#d6d3d1', '#57534e'],
    adjustments: {
      contrast: 12,
      highlights: -18,
      shadows: 12,
      blacks: 12,
      temperature: 8,
      tint: -6,
      saturation: -8,
      vibrance: 10,
      colorBalance: 8,
    },
  },
  {
    id: 'vintage',
    name: 'Vintage',
    tagline: 'Nostalgic warm faded emulsion',
    swatch: ['#fed7aa', '#9a3412'],
    adjustments: {
      contrast: -8,
      blacks: 18,
      highlights: -14,
      temperature: 20,
      tint: 8,
      saturation: -18,
      colorBalance: 14,
    },
  },
  {
    id: 'modern',
    name: 'Modern',
    tagline: 'Clean crisp commercial contrast',
    swatch: ['#e0f2fe', '#1d4ed8'],
    adjustments: {
      exposure: 4,
      contrast: 14,
      whites: 12,
      blacks: -10,
      temperature: -4,
      vibrance: 12,
      clarity: 14,
      sharpness: 18,
    },
  },
  {
    id: 'vibrant',
    name: 'Vibrant',
    tagline: 'Lively color pop without clipping',
    swatch: ['#60a5fa', '#10b981'],
    adjustments: {
      exposure: 6,
      contrast: 10,
      saturation: 14,
      vibrance: 26,
      clarity: 10,
      sharpness: 12,
    },
  },
  {
    id: 'moody',
    name: 'Moody',
    tagline: 'Deep dramatic shadows & muted chroma',
    swatch: ['#334155', '#0f172a'],
    adjustments: {
      exposure: -10,
      contrast: 20,
      highlights: -20,
      shadows: -14,
      blacks: -16,
      saturation: -18,
      temperature: -6,
      clarity: 18,
    },
  },
  {
    id: 'soft',
    name: 'Soft',
    tagline: 'Gentle diffused studio glow',
    swatch: ['#f1f5f9', '#93c5fd'],
    adjustments: {
      exposure: 8,
      contrast: -12,
      highlights: -12,
      shadows: 20,
      clarity: -10,
      saturation: -6,
      noiseReduction: 18,
    },
  },
  {
    id: 'golden-hour',
    name: 'Golden Hour',
    tagline: 'Luminous sunset glow & soft contrast',
    swatch: ['#fef08a', '#f97316'],
    adjustments: {
      exposure: 8,
      highlights: -14,
      shadows: 18,
      temperature: 28,
      tint: 8,
      vibrance: 16,
      colorBalance: 16,
      skinTone: 12,
    },
  },
];

export interface AdjustmentMeta {
  key: keyof ColorAdjustments;
  label: string;
  min: number;
  max: number;
  group: 'Light' | 'Color' | 'Detail';
}

export const ADJUSTMENT_CONTROLS: AdjustmentMeta[] = [
  { key: 'exposure', label: 'Exposure', min: -100, max: 100, group: 'Light' },
  { key: 'brightness', label: 'Brightness', min: -100, max: 100, group: 'Light' },
  { key: 'contrast', label: 'Contrast', min: -100, max: 100, group: 'Light' },
  { key: 'highlights', label: 'Highlights', min: -100, max: 100, group: 'Light' },
  { key: 'shadows', label: 'Shadows', min: -100, max: 100, group: 'Light' },
  { key: 'whites', label: 'Whites', min: -100, max: 100, group: 'Light' },
  { key: 'blacks', label: 'Blacks', min: -100, max: 100, group: 'Light' },
  { key: 'saturation', label: 'Saturation', min: -100, max: 100, group: 'Color' },
  { key: 'vibrance', label: 'Vibrance', min: -100, max: 100, group: 'Color' },
  { key: 'temperature', label: 'Temperature', min: -100, max: 100, group: 'Color' },
  { key: 'tint', label: 'Tint', min: -100, max: 100, group: 'Color' },
  { key: 'colorBalance', label: 'Color Balance', min: -100, max: 100, group: 'Color' },
  { key: 'skinTone', label: 'Skin Tone', min: -100, max: 100, group: 'Color' },
  { key: 'sharpness', label: 'Sharpness', min: 0, max: 100, group: 'Detail' },
  { key: 'clarity', label: 'Clarity', min: -100, max: 100, group: 'Detail' },
  { key: 'noiseReduction', label: 'Noise Reduction', min: 0, max: 100, group: 'Detail' },
];

export interface StickerPreset {
  id: string;
  name: string;
  svg: string;
}

export const STICKER_PRESETS: StickerPreset[] = [
  {
    id: 'studio-seal',
    name: 'Studio Seal',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><circle cx="60" cy="60" r="52" fill="#2563EB" fill-opacity="0.92" stroke="#FFFFFF" stroke-width="4"/><circle cx="60" cy="60" r="42" fill="none" stroke="#BFDBFE" stroke-width="1.5" stroke-dasharray="4 4"/><text x="60" y="57" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-weight="700" font-size="14" letter-spacing="1.5">BT KITE</text><text x="60" y="74" text-anchor="middle" fill="#DBEAFE" font-family="sans-serif" font-weight="600" font-size="9" letter-spacing="2">STUDIO</text></svg>`,
  },
  {
    id: 'new-arrival',
    name: 'New Drop',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 64"><rect x="4" y="4" width="152" height="56" rx="28" fill="#0F172A" stroke="#FFFFFF" stroke-width="3"/><text x="80" y="39" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-weight="700" font-size="18" letter-spacing="2">NEW EDIT</text></svg>`,
  },
  {
    id: 'spark-star',
    name: 'Four-Point Spark',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><path d="M60 8 C63 42 78 57 112 60 C78 63 63 78 60 112 C57 78 42 63 8 60 C42 57 57 42 60 8 Z" fill="#FFFFFF" stroke="#2563EB" stroke-width="3"/></svg>`,
  },
  {
    id: 'frame-corners',
    name: 'Viewfinder',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><path d="M14 40 V14 H40 M80 14 H106 V40 M106 80 V106 H80 M40 106 H14 V80" fill="none" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round"/><circle cx="60" cy="60" r="6" fill="#2563EB" stroke="#FFFFFF" stroke-width="2.5"/></svg>`,
  },
  {
    id: 'verified-mark',
    name: 'Verified',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><circle cx="60" cy="60" r="48" fill="#2563EB" stroke="#FFFFFF" stroke-width="4"/><path d="M38 61 L53 76 L84 44" fill="none" stroke="#FFFFFF" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  },
  {
    id: 'heart-clean',
    name: 'Heart',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><path d="M60 102 C60 102 14 73 14 41 C14 25 26 14 41 14 C50 14 57 19 60 26 C63 19 70 14 79 14 C94 14 106 25 106 41 C106 73 60 102 60 102 Z" fill="#EF4444" stroke="#FFFFFF" stroke-width="4"/></svg>`,
  },
  {
    id: 'sun-badge',
    name: 'Golden Sun',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><circle cx="60" cy="60" r="24" fill="#F59E0B" stroke="#FFFFFF" stroke-width="4"/><g stroke="#F59E0B" stroke-width="6" stroke-linecap="round"><line x1="60" y1="10" x2="60" y2="24"/><line x1="60" y1="96" x2="60" y2="110"/><line x1="10" y1="60" x2="24" y2="60"/><line x1="96" y1="60" x2="110" y2="60"/><line x1="25" y1="25" x2="35" y2="35"/><line x1="85" y1="85" x2="95" y2="95"/><line x1="95" y1="25" x2="85" y2="35"/><line x1="35" y1="85" x2="25" y2="95"/></g></svg>`,
  },
  {
    id: 'sale-tag',
    name: 'Featured Tag',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 64"><rect x="4" y="4" width="152" height="56" rx="14" fill="#2563EB" stroke="#FFFFFF" stroke-width="3"/><text x="80" y="39" text-anchor="middle" fill="#FFFFFF" font-family="sans-serif" font-weight="800" font-size="18" letter-spacing="1.5">FEATURED</text></svg>`,
  },
];

/**
 * Ranks all curated photographic backdrops against detected subject pose, environment,
 * camera distance, camera angle, lighting direction, and photo type.
 */
export function rankBackgroundsForScene(params: {
  pose: SubjectPose;
  poseDetail: string;
  photoCategory: string;
  cameraDistance: CameraDistance;
  cameraAngle: CameraAngle;
  lightingDirection: LightingDirection;
  originalEnvironment: string;
  avgLuminance?: number;
}): RecommendedBackgroundItem[] {
  const {
    pose,
    poseDetail,
    photoCategory,
    cameraDistance,
    cameraAngle,
    lightingDirection,
    originalEnvironment,
    avgLuminance = 0.55,
  } = params;

  const envLower = `${originalEnvironment} ${poseDetail}`.toLowerCase();
  const catLower = photoCategory.toLowerCase();
  const isStairsContext = /stair|step|ledge|bench|terrace|sit/.test(envLower) || pose === 'sitting';
  const isTravelContext = /travel|outdoor|landscape|nature|street|mountain|beach/.test(catLower);
  const isPortraitContext = /portrait|professional|business|headshot/.test(catLower);
  const isProductContext = pose === 'object_still_life' || /product|food/.test(catLower);

  const scored = BACKGROUND_PRESETS.map((preset) => {
    let score = 45;
    const reasons: string[] = [];

    // 1. Pose compatibility
    if (preset.suitablePoses.includes(pose)) {
      score += 18;
    } else {
      score -= 22;
    }

    // 2. Sitting / stairs / leaning perspective bonus
    if (pose === 'sitting' || pose === 'leaning' || isStairsContext) {
      if (preset.supportsSeatingOrSteps) {
        score += 22;
        if (preset.id === 'architectural-stairs' && /stair|step/.test(envLower)) {
          score += 12;
          reasons.push('Preserves natural stair & seated ground perspective');
        } else if (preset.id === 'mountains') {
          reasons.push('Natural overlook seating & elevated scenic depth');
        } else if (preset.id === 'luxury-terrace') {
          reasons.push('Architectural terrace steps fit seated pose & daylight');
        } else {
          reasons.push('Natural ground plane matches seated posture');
        }
      } else if (preset.id === 'passport-id' || preset.id === 'product-photography') {
        score -= 30;
      }
    }

    // 3. Photo type match
    const catMatch = preset.suitablePhotoTypes.some((t) =>
      catLower.includes(t.toLowerCase()) || t.toLowerCase().includes(catLower.split(' ')[0])
    );
    if (catMatch) {
      score += 18;
    }

    // 4. Context-specific boosts
    if (isProductContext) {
      if (preset.id === 'product-photography') {
        score += 35;
        reasons.push('Commercial studio surface anchors product contact shadows');
      } else if (preset.id === 'luxury' || preset.id === 'professional-studio') {
        score += 18;
        reasons.push('Clean studio lighting highlights object contours');
      } else {
        score -= 18;
      }
    } else if (isPortraitContext && (cameraDistance === 'close-up' || cameraDistance === 'medium-shot')) {
      if (preset.id === 'professional-studio' || preset.id === 'business-portrait' || preset.id === 'office') {
        score += 20;
        reasons.push('Balanced studio depth separates hair and shoulders cleanly');
      } else if (preset.id === 'fashion' || preset.id === 'luxury') {
        score += 12;
        reasons.push('Editorial portrait tones complement facial lighting');
      }
    } else if (isTravelContext) {
      if (
        preset.id === 'mountains' ||
        preset.id === 'luxury-terrace' ||
        preset.id === 'sunset' ||
        preset.id === 'architectural-stairs' ||
        preset.id === 'beach'
      ) {
        score += 20;
        reasons.push('Authentic travel environment with matching open-sky depth');
      }
    }

    // 5. Camera angle & lighting direction harmony
    if (cameraAngle === 'slightly-elevated' && (preset.id === 'mountains' || preset.id === 'luxury-terrace' || preset.id === 'architectural-stairs')) {
      score += 8;
    }
    if (preset.keyLightDirection === lightingDirection) {
      score += 7;
      reasons.push(`Matches ${lightingDirection.replace('-', ' ')} key light direction`);
    }

    // 6. Ambient brightness continuity
    const lumDiff = Math.abs(preset.ambientLuminance - avgLuminance);
    if (lumDiff < 0.22) score += 6;
    if (preset.imageUrl) score += 4; // prioritize high-res photographic plates

    // Default reason if none pushed
    if (reasons.length === 0) {
      reasons.push(`${preset.shortDesc} · balanced for ${photoCategory.toLowerCase()}`);
    }

    return {
      id: preset.id,
      name: preset.name,
      reason: reasons[0],
      matchScore: Math.max(55, Math.min(99, Math.round(score))),
    };
  });

  return scored.sort((a, b) => b.matchScore - a.matchScore).slice(0, 5);
}

/**
 * Computes smart perspective & blur defaults when blending a subject into a target backdrop.
 */
export function computeAutoBlendForScene(params: {
  preset: BackgroundPreset;
  cameraDistance: CameraDistance;
  groundLevelY: number;
  horizonY: number;
  lightingDirection: LightingDirection;
}): {
  backgroundBlur: number;
  shadowDepth: number;
  horizonShift: number;
  lightingDirection: LightingDirection;
} {
  const { preset, cameraDistance, groundLevelY, horizonY, lightingDirection } = params;

  // Match lens depth-of-field to camera distance (close-ups have softer bokeh; wide shots stay sharper)
  const distanceBlurFactor =
    cameraDistance === 'close-up'
      ? 1.45
      : cameraDistance === 'medium-shot'
      ? 1.1
      : cameraDistance === 'full-body'
      ? 0.72
      : 0.55;

  const backgroundBlur =
    preset.id === 'passport-id'
      ? 0
      : Math.max(4, Math.min(58, Math.round(preset.defaultBlur * distanceBlurFactor)));

  // Align backdrop's natural ground/horizon line with the subject's detected ground/horizon line
  const rawDeltaY =
    groundLevelY < 0.96
      ? (groundLevelY - preset.groundY) * 100
      : (horizonY - preset.horizonY) * 75;
  const horizonShift = Math.max(-28, Math.min(28, Math.round(rawDeltaY)));

  // Grounded subjects receive realistic contact shadow; cropped busts avoid unnatural floating halos
  const shadowDepth =
    preset.id === 'passport-id'
      ? 10
      : groundLevelY < 0.96
      ? Math.max(48, preset.defaultShadow)
      : Math.round(preset.defaultShadow * 0.45);

  return {
    backgroundBlur,
    shadowDepth,
    horizonShift,
    lightingDirection: lightingDirection || preset.keyLightDirection,
  };
}

export function matchPromptToBackgroundPreset(prompt: string): BackgroundPreset {
  const lower = prompt.toLowerCase();
  let best = BACKGROUND_PRESETS[0];
  let bestScore = -1;

  for (const preset of BACKGROUND_PRESETS) {
    let score = 0;
    if (lower.includes(preset.name.toLowerCase())) score += 5;
    for (const kw of preset.keywords) {
      if (lower.includes(kw)) score += 2;
    }
    if (score > bestScore) {
      bestScore = score;
      best = preset;
    }
  }
  return best;
}

export function mergeAdjustmentsWithStyle(
  base: ColorAdjustments,
  styleId: ColorStyleId,
  intensity: number
): ColorAdjustments {
  const preset = COLOR_STYLE_PRESETS.find((s) => s.id === styleId);
  if (!preset || styleId === 'none' || intensity <= 0) {
    return base;
  }
  const factor = intensity / 100;
  const result: ColorAdjustments = { ...DEFAULT_ADJUSTMENTS, ...base };
  (Object.keys(result) as Array<keyof ColorAdjustments>).forEach((key) => {
    const delta = (preset.adjustments[key] ?? 0) * factor;
    const min = key === 'sharpness' || key === 'noiseReduction' ? 0 : -100;
    result[key] = Math.max(min, Math.min(100, Math.round(result[key] + delta)));
  });
  return result;
}
