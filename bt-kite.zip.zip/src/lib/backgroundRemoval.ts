import { removeBackground } from '@imgly/background-removal';

const cutoutCache = new Map<string, string>();

export interface BgRemovalProgress {
  stage: string;
  progress: number; // 0 to 100
}

/**
 * Removes image background locally in the browser using the free open-source
 * neural segmentation model (@imgly/background-removal), outputting a true alpha-transparent PNG.
 */
export async function removeBackgroundNeural(
  imageUrl: string,
  onProgress?: (update: BgRemovalProgress) => void,
  signal?: AbortSignal
): Promise<string> {
  if (signal?.aborted) {
    throw new DOMException('Background removal cancelled', 'AbortError');
  }

  const cached = cutoutCache.get(imageUrl);
  if (cached) {
    onProgress?.({ stage: 'Using cached subject cutout...', progress: 100 });
    return cached;
  }

  onProgress?.({ stage: 'Initializing on-device AI segmentation model...', progress: 8 });

  // Convert data URL / local asset URL into a Blob so @imgly handles it consistently
  const sourceResponse = await fetch(imageUrl, { signal });
  if (!sourceResponse.ok) {
    throw new Error('Could not read source photo for segmentation.');
  }
  const sourceBlob = await sourceResponse.blob();

  if (signal?.aborted) {
    throw new DOMException('Background removal cancelled', 'AbortError');
  }

  const resultBlob = await removeBackground(sourceBlob, {
    model: 'isnet_fp16',
    output: {
      format: 'image/png',
      quality: 1,
    },
    progress: (key: string, current: number, total: number) => {
      if (signal?.aborted) return;
      const ratio = total > 0 ? Math.min(1, current / total) : 0;
      if (key.includes('fetch')) {
        onProgress?.({
          stage: 'Loading free neural segmentation weights (cached after first use)...',
          progress: Math.round(10 + ratio * 55),
        });
      } else {
        onProgress?.({
          stage: 'Detecting subject, fine hair, and complex edges...',
          progress: Math.round(65 + ratio * 30),
        });
      }
    },
  });

  if (signal?.aborted) {
    throw new DOMException('Background removal cancelled', 'AbortError');
  }

  onProgress?.({ stage: 'Finalizing transparent PNG alpha matte...', progress: 96 });

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to encode transparent cutout.'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read cutout blob.'));
    reader.readAsDataURL(resultBlob);
  });

  if (cutoutCache.size > 10) {
    const firstKey = cutoutCache.keys().next().value;
    if (firstKey) cutoutCache.delete(firstKey);
  }
  cutoutCache.set(imageUrl, dataUrl);
  onProgress?.({ stage: 'Subject isolated cleanly', progress: 100 });
  return dataUrl;
}

export function clearCutoutCache(): void {
  cutoutCache.clear();
}
