import { BACKGROUND_PRESETS, rankBackgroundsForScene } from '../data/presets';
import {
  AIStatus,
  BackgroundCategoryId,
  PhotoAnalysisResult,
  RecommendedBackgroundItem,
} from '../types/editor';
import {
  analyzePhotoLocally,
  classifyHorizontalPosition,
  loadImage,
  measureCutoutGeometry,
} from './imageEngine';

export async function fetchAIStatus(): Promise<AIStatus> {
  try {
    const res = await fetch('/api/ai/status');
    if (!res.ok) throw new Error('Status check failed');
    return (await res.json()) as AIStatus;
  } catch {
    return {
      localNeuralBgRemoval: true,
      localColorAndEnhance: true,
      localBrushObjectRemoval: true,
      geminiVisionAvailable: false,
      paidGenerativeImageAvailable: false,
      visionModel: null,
      generativeModels: null,
    };
  }
}

async function createCompactJpegBase64(imageUrl: string, maxSide = 640): Promise<string> {
  const img = await loadImage(imageUrl);
  const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable');
  ctx.drawImage(img, 0, 0, w, h);
  const dataUrl = c.toDataURL('image/jpeg', 0.82);
  return dataUrl.split(',')[1] || '';
}

function normalizeAnalysisResult(raw: PhotoAnalysisResult): PhotoAnalysisResult {
  const presetMap = new Map(BACKGROUND_PRESETS.map((p) => [p.id, p]));
  const seen = new Set<BackgroundCategoryId>();
  const hydrated: RecommendedBackgroundItem[] = [];

  if (Array.isArray(raw.recommendedBackgrounds)) {
    for (const item of raw.recommendedBackgrounds) {
      const preset = presetMap.get(item.id);
      if (preset && !seen.has(preset.id)) {
        seen.add(preset.id);
        hydrated.push({
          id: preset.id,
          name: preset.name,
          reason: item.reason || preset.shortDesc,
          matchScore: Math.max(60, Math.min(99, Math.round(item.matchScore || 88))),
        });
      }
    }
  }

  // Ensure Top 5 ranked backgrounds are always populated with physically compatible backdrops
  if (hydrated.length < 5) {
    const fallbackRanked = rankBackgroundsForScene({
      pose: raw.pose || 'standing',
      poseDetail: raw.poseDetail || '',
      photoCategory: raw.photoCategory || 'Portrait',
      cameraDistance: raw.cameraDistance || 'medium-shot',
      cameraAngle: raw.cameraAngle || 'eye-level',
      lightingDirection: raw.lightingDirection || 'top-left',
      originalEnvironment: raw.originalEnvironment || '',
    });
    for (const rec of fallbackRanked) {
      if (hydrated.length >= 5) break;
      if (!seen.has(rec.id)) {
        seen.add(rec.id);
        hydrated.push(rec);
      }
    }
  }

  const topId: BackgroundCategoryId = presetMap.has(raw.recommendedBackgroundId)
    ? raw.recommendedBackgroundId
    : hydrated[0]?.id || 'professional-studio';

  return {
    ...raw,
    recommendedBackgroundId: topId,
    recommendedBackgrounds: hydrated.slice(0, 5),
  };
}

/**
 * Refines an existing scene analysis with pixel-exact subject geometry measured from the neural cutout
 * (horizontal position, exact ground plane Y, and framing distance) while preserving semantic pose understanding.
 */
export async function refineAnalysisWithCutout(
  analysis: PhotoAnalysisResult,
  cutoutUrl: string
): Promise<PhotoAnalysisResult> {
  try {
    const cutoutImg = await loadImage(cutoutUrl);
    const geo = measureCutoutGeometry(cutoutImg);
    const exactPosition = classifyHorizontalPosition(geo.centerX);
    const exactGroundY = geo.isGroundedInFrame ? Number(geo.maxY.toFixed(2)) : 1.0;

    let cameraDistance = analysis.cameraDistance;
    if (analysis.engine === 'local-vision') {
      if (geo.isGroundedInFrame) {
        cameraDistance = geo.heightRatio < 0.55 ? 'wide-shot' : 'full-body';
      } else {
        cameraDistance = geo.widthRatio > 0.62 ? 'close-up' : 'medium-shot';
      }
    }

    return {
      ...analysis,
      subjectPosition: exactPosition,
      groundLevelY: exactGroundY,
      cameraDistance,
    };
  } catch {
    return analysis;
  }
}

/**
 * Runs intelligent photo analysis using free-tier Gemini Vision (gemini-4-hydrogen) when configured
 * and online, seamlessly falling back to BT Kite's genuine Local Smart Vision engine
 * without blocking or faking results.
 */
export async function analyzePhotoSmart(
  imageUrl: string,
  preferGeminiVision: boolean,
  signal?: AbortSignal,
  optionalCutoutUrl?: string | null
): Promise<PhotoAnalysisResult> {
  if (signal?.aborted) {
    throw new DOMException('Analysis cancelled', 'AbortError');
  }

  if (preferGeminiVision && navigator.onLine) {
    try {
      const imageBase64 = await createCompactJpegBase64(imageUrl, 640);
      if (signal?.aborted) {
        throw new DOMException('Analysis cancelled', 'AbortError');
      }

      const res = await fetch('/api/ai/analyze-tune', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64, mimeType: 'image/jpeg' }),
        signal,
      });

      if (res.ok) {
        const raw = (await res.json()) as PhotoAnalysisResult;
        const normalized = normalizeAnalysisResult(raw);
        return optionalCutoutUrl
          ? refineAnalysisWithCutout(normalized, optionalCutoutUrl)
          : normalized;
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        throw err;
      }
      // Fall through cleanly to local computer vision analyzer
    }
  }

  if (signal?.aborted) {
    throw new DOMException('Analysis cancelled', 'AbortError');
  }

  return analyzePhotoLocally(imageUrl, optionalCutoutUrl);
}

/**
 * Modular optional Paid Gemini Image API hook.
 * Explicitly reports if a paid API key is required rather than faking results.
 */
export async function requestPaidGenerativeEdit(
  imageUrl: string,
  prompt: string,
  qualityMode: 'fast' | 'studio_hd',
  signal?: AbortSignal
): Promise<{ imageUrl: string; model: string }> {
  const imageBase64 = await createCompactJpegBase64(imageUrl, 1280);
  const res = await fetch('/api/ai/generative-edit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      imageBase64,
      mimeType: 'image/jpeg',
      prompt,
      qualityMode,
    }),
    signal,
  });

  const payload = await res.json().catch(() => ({ error: 'Request failed' }));
  if (!res.ok) {
    throw new Error(payload.error || 'Generative AI edit requires a paid Gemini API key.');
  }

  return payload as { imageUrl: string; model: string };
}
