import {
  BACKGROUND_PRESETS,
  BackgroundPreset,
  STICKER_PRESETS,
  mergeAdjustmentsWithStyle,
  rankBackgroundsForScene,
} from '../data/presets';
import {
  BackgroundCategoryId,
  BackgroundState,
  CameraAngle,
  CameraDistance,
  ColorAdjustments,
  CropRect,
  CutoutGeometry,
  DEFAULT_ADJUSTMENTS,
  EditorSnapshot,
  ExportFormat,
  LightingDirection,
  PhotoAnalysisResult,
  StickerLayer,
  SubjectPose,
  SubjectPosition,
  TextLayer,
} from '../types/editor';

const imageCache = new Map<string, HTMLImageElement>();

export function loadImage(url: string): Promise<HTMLImageElement> {
  const cached = imageCache.get(url);
  if (cached && cached.complete && cached.naturalWidth > 0) {
    return Promise.resolve(cached);
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (imageCache.size > 24) {
        const firstKey = imageCache.keys().next().value;
        if (firstKey) imageCache.delete(firstKey);
      }
      imageCache.set(url, img);
      resolve(img);
    };
    img.onerror = () => reject(new Error(`Failed to load image: ${url.slice(0, 64)}`));
    img.src = url;
  });
}

function clamp255(v: number): number {
  return v < 0 ? 0 : v > 255 ? 255 : v;
}

function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

/**
 * Applies all 16 photographic color & detail adjustments in real time onto ImageData.
 */
export function applyColorAdjustments(imageData: ImageData, adj: ColorAdjustments): void {
  const hasLightOrColor =
    adj.exposure !== 0 ||
    adj.brightness !== 0 ||
    adj.contrast !== 0 ||
    adj.highlights !== 0 ||
    adj.shadows !== 0 ||
    adj.whites !== 0 ||
    adj.blacks !== 0 ||
    adj.saturation !== 0 ||
    adj.vibrance !== 0 ||
    adj.temperature !== 0 ||
    adj.tint !== 0 ||
    adj.colorBalance !== 0 ||
    adj.skinTone !== 0;

  const { data, width, height } = imageData;

  if (adj.noiseReduction > 0) {
    applyEdgePreservingDenoise(data, width, height, adj.noiseReduction / 100);
  }

  if (hasLightOrColor) {
    const expMul = Math.pow(2, adj.exposure / 65);
    const brightAdd = adj.brightness * 1.15;
    const contrastFactor = Math.pow((100 + adj.contrast * 0.85) / 100, 1.35);
    const highlightsVal = adj.highlights * 0.65;
    const shadowsVal = adj.shadows * 0.72;
    const whitesVal = adj.whites * 0.55;
    const blacksVal = adj.blacks * 0.55;
    const satMul = 1 + adj.saturation / 100;
    const vibAmt = adj.vibrance / 100;
    const tempR = adj.temperature * 0.58;
    const tempB = -adj.temperature * 0.58;
    const tintG = -adj.tint * 0.42;
    const tintRB = adj.tint * 0.22;
    const balAmt = adj.colorBalance / 100;
    const skinAmt = adj.skinTone / 100;

    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] === 0) continue;

      let r = data[i];
      let g = data[i + 1];
      let b = data[i + 2];

      // 1. Exposure + Brightness
      r = r * expMul + brightAdd;
      g = g * expMul + brightAdd;
      b = b * expMul + brightAdd;

      // 2. Tonal zones: Highlights, Shadows, Whites, Blacks
      const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
      const lumClamped = Math.max(0, Math.min(1, lum));

      let toneDelta = 0;
      if (shadowsVal !== 0) {
        const shadowWeight = 1 - smoothstep(0.05, 0.58, lumClamped);
        toneDelta += shadowWeight * shadowsVal;
      }
      if (highlightsVal !== 0) {
        const hiWeight = smoothstep(0.45, 0.95, lumClamped);
        toneDelta += hiWeight * highlightsVal;
      }
      if (blacksVal !== 0) {
        const blkWeight = 1 - smoothstep(0.0, 0.28, lumClamped);
        toneDelta += blkWeight * blacksVal;
      }
      if (whitesVal !== 0) {
        const whtWeight = smoothstep(0.72, 1.0, lumClamped);
        toneDelta += whtWeight * whitesVal;
      }
      if (toneDelta !== 0) {
        r += toneDelta;
        g += toneDelta;
        b += toneDelta;
      }

      // 3. Contrast around mid-gray (128)
      if (adj.contrast !== 0) {
        r = (r - 128) * contrastFactor + 128;
        g = (g - 128) * contrastFactor + 128;
        b = (b - 128) * contrastFactor + 128;
      }

      // 4. Temperature & Tint
      if (adj.temperature !== 0 || adj.tint !== 0) {
        r += tempR + tintRB;
        g += tintG;
        b += tempB + tintRB;
      }

      // 5. Split Color Balance (warm highlights / cool shadows or inverse)
      if (balAmt !== 0) {
        const splitHi = smoothstep(0.45, 0.95, lumClamped);
        const splitSh = 1 - smoothstep(0.05, 0.55, lumClamped);
        r += (splitHi * 18 - splitSh * 10) * balAmt;
        g += splitHi * 5 * balAmt;
        b += (-splitHi * 14 + splitSh * 16) * balAmt;
      }

      // 6. Skin Tone Harmonizer (targets realistic skin hue range)
      if (skinAmt !== 0) {
        const rn = clamp255(r);
        const gn = clamp255(g);
        const bn = clamp255(b);
        if (rn > 75 && gn > 38 && bn > 20 && rn > gn && rn > bn && rn - Math.min(gn, bn) > 12) {
          const skinMask = Math.min(1, (rn - gn) / 55) * smoothstep(0.15, 0.85, lumClamped);
          r += skinAmt * 14 * skinMask;
          g += skinAmt * 10 * skinMask;
          b += skinAmt * 4 * skinMask;
        }
      }

      // 7. Vibrance & Saturation
      if (adj.saturation !== 0 || adj.vibrance !== 0) {
        const gray = 0.299 * r + 0.587 * g + 0.114 * b;
        const maxC = Math.max(r, g, b);
        const minC = Math.min(r, g, b);
        const curSat = maxC > 0 ? (maxC - minC) / Math.max(1, maxC) : 0;

        // Vibrance boosts muted colors more while protecting already-saturated and skin tones
        const isSkin = r > g && g > b && r - b > 18;
        const vibBoost = vibAmt * (1 - curSat) * (isSkin ? 0.45 : 1.0);
        const totalSat = Math.max(0, satMul + vibBoost);

        r = gray + (r - gray) * totalSat;
        g = gray + (g - gray) * totalSat;
        b = gray + (b - gray) * totalSat;
      }

      data[i] = clamp255(r);
      data[i + 1] = clamp255(g);
      data[i + 2] = clamp255(b);
    }
  }

  // 8. Clarity (midtone micro-contrast) + Sharpness (3x3 unsharp mask)
  if (adj.sharpness > 0 || adj.clarity !== 0) {
    applyDetailConvolution(data, width, height, adj.sharpness / 100, adj.clarity / 100);
  }
}

function applyEdgePreservingDenoise(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  amount: number
): void {
  const copy = new Uint8ClampedArray(data);
  const strength = Math.min(0.85, amount * 0.85);
  const threshold = 24 + amount * 26;

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = (y * width + x) * 4;
      if (copy[idx + 3] === 0) continue;

      const cr = copy[idx];
      const cg = copy[idx + 1];
      const cb = copy[idx + 2];

      let sr = cr;
      let sg = cg;
      let sb = cb;
      let wSum = 1;

      const offsets = [-4, 4, -width * 4, width * 4];
      for (let k = 0; k < offsets.length; k++) {
        const nIdx = idx + offsets[k];
        const nr = copy[nIdx];
        const ng = copy[nIdx + 1];
        const nb = copy[nIdx + 2];
        const diff = Math.abs(nr - cr) + Math.abs(ng - cg) + Math.abs(nb - cb);
        if (diff < threshold * 3) {
          const w = 1 - diff / (threshold * 3);
          sr += nr * w;
          sg += ng * w;
          sb += nb * w;
          wSum += w;
        }
      }

      data[idx] = clamp255(cr + (sr / wSum - cr) * strength);
      data[idx + 1] = clamp255(cg + (sg / wSum - cg) * strength);
      data[idx + 2] = clamp255(cb + (sb / wSum - cb) * strength);
    }
  }
}

function applyDetailConvolution(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  sharpness: number,
  clarity: number
): void {
  const copy = new Uint8ClampedArray(data);
  const sharpGain = sharpness * 0.9;
  const clarityGain = clarity * 0.55;

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = (y * width + x) * 4;
      if (copy[idx + 3] === 0) continue;

      const top = idx - width * 4;
      const bot = idx + width * 4;
      const left = idx - 4;
      const right = idx + 4;

      for (let c = 0; c < 3; c++) {
        const center = copy[idx + c];
        const avg = (copy[top + c] + copy[bot + c] + copy[left + c] + copy[right + c]) * 0.25;
        const highFreq = center - avg;

        let val = center + highFreq * sharpGain;
        if (clarityGain !== 0) {
          // Midtone weight peaks at 128
          const midWeight = 1 - Math.abs(center - 128) / 128;
          val += highFreq * clarityGain * (0.4 + 0.6 * midWeight);
        }
        data[idx + c] = clamp255(val);
      }
    }
  }
}

/**
 * Measures exact normalized subject bounding box, horizontal centroid, ground contact footprint,
 * and whether the subject is grounded inside the frame (feet/base visible vs bottom-cropped bust).
 */
export function measureCutoutGeometry(cutoutImg: HTMLImageElement): CutoutGeometry {
  const sampleW = 180;
  const sampleH = Math.max(
    80,
    Math.round((cutoutImg.naturalHeight / Math.max(1, cutoutImg.naturalWidth)) * sampleW)
  );
  const c = document.createElement('canvas');
  c.width = sampleW;
  c.height = sampleH;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    return {
      minX: 0.25,
      maxX: 0.75,
      minY: 0.12,
      maxY: 0.98,
      centerX: 0.5,
      widthRatio: 0.5,
      heightRatio: 0.86,
      contactMinX: 0.32,
      contactMaxX: 0.68,
      isGroundedInFrame: false,
    };
  }
  ctx.drawImage(cutoutImg, 0, 0, sampleW, sampleH);
  const { data } = ctx.getImageData(0, 0, sampleW, sampleH);

  let minX = sampleW;
  let maxX = 0;
  let minY = sampleH;
  let maxY = 0;
  let sumX = 0;
  let count = 0;

  for (let y = 0; y < sampleH; y++) {
    for (let x = 0; x < sampleW; x++) {
      const a = data[(y * sampleW + x) * 4 + 3];
      if (a > 80) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
        sumX += x;
        count++;
      }
    }
  }

  if (count < 25 || maxX <= minX || maxY <= minY) {
    return {
      minX: 0.25,
      maxX: 0.75,
      minY: 0.12,
      maxY: 0.98,
      centerX: 0.5,
      widthRatio: 0.5,
      heightRatio: 0.86,
      contactMinX: 0.32,
      contactMaxX: 0.68,
      isGroundedInFrame: false,
    };
  }

  // Measure bottom 7% contact footprint so contact shadows anchor tightly under feet / base
  const bandTop = Math.max(minY, Math.floor(maxY - (maxY - minY) * 0.07));
  let cMinX = sampleW;
  let cMaxX = 0;
  let cCount = 0;
  for (let y = bandTop; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      if (data[(y * sampleW + x) * 4 + 3] > 80) {
        if (x < cMinX) cMinX = x;
        if (x > cMaxX) cMaxX = x;
        cCount++;
      }
    }
  }

  const nMinX = minX / sampleW;
  const nMaxX = maxX / sampleW;
  const nMinY = minY / sampleH;
  const nMaxY = maxY / sampleH;
  const nCenterX = sumX / count / sampleW;

  return {
    minX: nMinX,
    maxX: nMaxX,
    minY: nMinY,
    maxY: nMaxY,
    centerX: nCenterX,
    widthRatio: Math.max(0.05, nMaxX - nMinX),
    heightRatio: Math.max(0.05, nMaxY - nMinY),
    contactMinX: cCount > 8 ? cMinX / sampleW : nMinX + (nMaxX - nMinX) * 0.15,
    contactMaxX: cCount > 8 ? cMaxX / sampleW : nMaxX - (nMaxX - nMinX) * 0.15,
    isGroundedInFrame: nMaxY < 0.965,
  };
}

export function classifyHorizontalPosition(centerX: number): SubjectPosition {
  if (centerX < 0.34) return 'left';
  if (centerX < 0.45) return 'center-left';
  if (centerX <= 0.55) return 'center';
  if (centerX <= 0.66) return 'center-right';
  return 'right';
}

/**
 * Genuine client-side computer vision analyzer for scene understanding, pose/position/lighting estimation,
 * ranked background recommendations, and 16-slider AI Color Tune.
 */
export async function analyzePhotoLocally(
  imageUrl: string,
  optionalCutoutUrl?: string | null
): Promise<PhotoAnalysisResult> {
  const img = await loadImage(imageUrl);
  const sampleW = 160;
  const sampleH = Math.max(80, Math.round((img.naturalHeight / img.naturalWidth) * sampleW));

  const canvas = document.createElement('canvas');
  canvas.width = sampleW;
  canvas.height = sampleH;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) {
    throw new Error('Canvas context unavailable for analysis.');
  }
  ctx.drawImage(img, 0, 0, sampleW, sampleH);
  const { data } = ctx.getImageData(0, 0, sampleW, sampleH);

  const hist = new Uint32Array(256);
  let totalPixels = 0;
  let sumR = 0;
  let sumG = 0;
  let sumB = 0;
  let sumLum = 0;
  let sumSat = 0;
  let skinPixels = 0;
  let skinXSum = 0;
  let skinYSum = 0;
  let skyBluePixels = 0;
  let greenNaturePixels = 0;
  let centerEdgeStrength = 0;

  // Directional quadrant luminance + backlight border vs center metrics
  let tlLum = 0;
  let tlCount = 0;
  let trLum = 0;
  let trCount = 0;
  let blLum = 0;
  let blCount = 0;
  let brLum = 0;
  let brCount = 0;
  let borderLum = 0;
  let borderCount = 0;
  let centerLum = 0;
  let centerCount = 0;

  // Saliency centroid for estimating subject position when no cutout exists yet
  let salientXSum = 0;
  let salientWeightSum = 0;

  const halfW = sampleW / 2;
  const halfH = sampleH / 2;

  for (let y = 0; y < sampleH; y++) {
    for (let x = 0; x < sampleW; x++) {
      const i = (y * sampleW + x) * 4;
      if (data[i + 3] < 128) continue;
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const lum = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
      hist[lum]++;
      totalPixels++;
      sumR += r;
      sumG += g;
      sumB += b;
      sumLum += lum;

      if (y < halfH) {
        if (x < halfW) {
          tlLum += lum;
          tlCount++;
        } else {
          trLum += lum;
          trCount++;
        }
      } else if (x < halfW) {
        blLum += lum;
        blCount++;
      } else {
        brLum += lum;
        brCount++;
      }

      const isBorder =
        x < sampleW * 0.15 || x > sampleW * 0.85 || y < sampleH * 0.15;
      if (isBorder) {
        borderLum += lum;
        borderCount++;
      } else if (
        x > sampleW * 0.28 &&
        x < sampleW * 0.72 &&
        y > sampleH * 0.22 &&
        y < sampleH * 0.78
      ) {
        centerLum += lum;
        centerCount++;
      }

      const maxC = Math.max(r, g, b);
      const minC = Math.min(r, g, b);
      const sat = maxC > 0 ? (maxC - minC) / maxC : 0;
      sumSat += sat;

      // Skin pixel heuristic
      if (
        r > 85 &&
        g > 42 &&
        b > 24 &&
        r > g &&
        r > b &&
        r - Math.min(g, b) > 15 &&
        Math.abs(r - g) > 12 &&
        y > sampleH * 0.08 &&
        y < sampleH * 0.88
      ) {
        skinPixels++;
        skinXSum += x / sampleW;
        skinYSum += y / sampleH;
      }
      if (y < sampleH * 0.4 && b > r + 15 && b > 100) {
        skyBluePixels++;
      }
      if (g > r + 12 && g > b + 12 && g > 55) {
        greenNaturePixels++;
      }
      if (x > 0 && x < sampleW - 1 && y > sampleH * 0.16 && y < sampleH * 0.86) {
        const prevLum = 0.299 * data[i - 4] + 0.587 * data[i - 3] + 0.114 * data[i - 2];
        const edge = Math.abs(lum - prevLum);
        if (y > sampleH * 0.2 && y < sampleH * 0.8) {
          centerEdgeStrength += edge;
        }
        if (edge > 14) {
          salientXSum += (x / sampleW) * edge;
          salientWeightSum += edge;
        }
      }
    }
  }

  const count = Math.max(1, totalPixels);
  const avgR = sumR / count;
  const avgG = sumG / count;
  const avgB = sumB / count;
  const avgLum = sumLum / count; // 0..255
  const avgSat = sumSat / count; // 0..1
  const skinRatio = skinPixels / count;
  const skyRatio = skyBluePixels / count;
  const greenRatio = greenNaturePixels / count;
  const avgEdge = centerEdgeStrength / (count * 0.6);

  // Measure real lighting direction from quadrant & border luminance
  const tlAvg = tlLum / Math.max(1, tlCount);
  const trAvg = trLum / Math.max(1, trCount);
  const blAvg = blLum / Math.max(1, blCount);
  const brAvg = brLum / Math.max(1, brCount);
  const leftAvg = (tlAvg + blAvg) / 2;
  const rightAvg = (trAvg + brAvg) / 2;
  const topAvg = (tlAvg + trAvg) / 2;
  const botAvg = (blAvg + brAvg) / 2;
  const borderAvg = borderLum / Math.max(1, borderCount);
  const centerAvg = centerLum / Math.max(1, centerCount);

  let lightingDirection: LightingDirection = 'front-diffused';
  let lightingType = 'Soft diffused daylight';
  if (borderAvg - centerAvg > 28 && borderAvg > 155) {
    lightingDirection = 'backlit';
    lightingType = 'Bright backlit ambient';
  } else if (Math.abs(leftAvg - rightAvg) > 12) {
    const fromLeft = leftAvg > rightAvg;
    const fromTop = topAvg - botAvg > 12;
    lightingDirection = fromLeft
      ? fromTop
        ? 'top-left'
        : 'left'
      : fromTop
      ? 'top-right'
      : 'right';
    lightingType = fromTop ? 'Directional overhead daylight' : 'Directional side key light';
  } else if (topAvg - botAvg > 18) {
    lightingDirection = tlAvg >= trAvg ? 'top-left' : 'top-right';
    lightingType = 'Natural overhead sunlight';
  } else if (avgLum < 85) {
    lightingDirection = 'top-right';
    lightingType = 'Low-key ambient lighting';
  }

  // Percentile dynamic range (5th and 95th percentile luminance)
  let acc = 0;
  let p5 = 0;
  let p95 = 255;
  for (let v = 0; v < 256; v++) {
    acc += hist[v];
    if (acc >= count * 0.05 && p5 === 0) p5 = v;
    if (acc >= count * 0.95) {
      p95 = v;
      break;
    }
  }
  const dynamicRange = p95 - p5;

  // Optional cutout geometry measurement for exact subject position & grounding
  let cutoutGeo: CutoutGeometry | null = null;
  if (optionalCutoutUrl) {
    try {
      const cImg = await loadImage(optionalCutoutUrl);
      cutoutGeo = measureCutoutGeometry(cImg);
    } catch {
      cutoutGeo = null;
    }
  }

  const estCenterX = cutoutGeo
    ? cutoutGeo.centerX
    : skinPixels > 45
    ? skinXSum / skinPixels
    : salientWeightSum > 0
    ? salientXSum / salientWeightSum
    : 0.5;
  const subjectPosition = classifyHorizontalPosition(estCenterX);
  const avgSkinY = skinPixels > 45 ? skinYSum / skinPixels : 0.38;

  // Infer photo type, subject, pose, camera distance, angle, horizon & ground level
  let photoCategory = 'Portrait';
  let subjectDescription = 'Main subject';
  let pose: SubjectPose = 'standing';
  let poseDetail = 'Standing natural posture';
  let cameraDistance: CameraDistance = 'medium-shot';
  let cameraAngle: CameraAngle = 'eye-level';
  let originalEnvironment = 'Indoor studio / ambient space';
  let horizonY = 0.52;
  let groundLevelY = cutoutGeo ? (cutoutGeo.isGroundedInFrame ? cutoutGeo.maxY : 1.0) : 0.94;
  let recommendedStyleId: PhotoAnalysisResult['recommendedStyleId'] = 'natural';

  const aspect = img.naturalWidth / Math.max(1, img.naturalHeight);

  if (skinRatio > 0.055) {
    const isOutdoor = skyRatio > 0.08 || greenRatio > 0.1;
    photoCategory = isOutdoor ? 'Travel & Outdoor Portrait' : 'Portrait';
    subjectDescription = isOutdoor ? 'Person in outdoor scene' : 'Portrait subject';
    originalEnvironment =
      skyRatio > 0.1
        ? 'Open outdoor daylight scenery'
        : greenRatio > 0.12
        ? 'Natural greenery & outdoor setting'
        : avgLum < 95
        ? 'Evening ambient / indoor location'
        : 'Daylight portrait setting';

    if (cutoutGeo) {
      if (cutoutGeo.isGroundedInFrame) {
        cameraDistance = cutoutGeo.heightRatio < 0.55 ? 'wide-shot' : 'full-body';
        // Seated subjects typically have a wider aspect ratio (width/height) than tall upright standing figures
        const subAspect = cutoutGeo.widthRatio / Math.max(0.1, cutoutGeo.heightRatio);
        if (subAspect > 0.62) {
          pose = 'sitting';
          poseDetail = 'Seated relaxed posture';
        } else {
          pose = 'standing';
          poseDetail = 'Full-body standing posture';
        }
        groundLevelY = Number(cutoutGeo.maxY.toFixed(2));
        horizonY = Number(Math.max(0.32, Math.min(0.62, cutoutGeo.minY + cutoutGeo.heightRatio * 0.25)).toFixed(2));
      } else {
        cameraDistance = skinRatio > 0.18 || cutoutGeo.widthRatio > 0.62 ? 'close-up' : 'medium-shot';
        pose = 'posing';
        poseDetail = cameraDistance === 'close-up' ? 'Close-up portrait pose' : 'Waist-up portrait pose';
        groundLevelY = 1.0;
        horizonY = 0.48;
      }
    } else {
      cameraDistance = skinRatio > 0.18 ? 'close-up' : avgSkinY > 0.45 ? 'full-body' : 'medium-shot';
      if (isOutdoor && aspect >= 1.15) {
        pose = 'sitting';
        poseDetail = 'Relaxed seated / travel pose';
        groundLevelY = 0.86;
        horizonY = 0.44;
      } else {
        pose = cameraDistance === 'close-up' ? 'posing' : 'standing';
        poseDetail = cameraDistance === 'close-up' ? 'Portrait head & shoulders' : 'Natural upright pose';
        groundLevelY = cameraDistance === 'full-body' ? 0.88 : 1.0;
      }
    }
    cameraAngle = avgSkinY > 0.48 ? 'slightly-elevated' : 'eye-level';
    recommendedStyleId = isOutdoor ? 'golden-hour' : 'professional-portrait';
  } else if (avgLum < 72) {
    photoCategory = 'Night & Street';
    subjectDescription = 'Low-light subject';
    pose = 'standing';
    poseDetail = 'Standing in low-light scene';
    cameraDistance = 'medium-shot';
    originalEnvironment = 'Evening / urban night lighting';
    horizonY = 0.54;
    recommendedStyleId = 'cinematic';
  } else if (skyRatio > 0.14 || greenRatio > 0.18) {
    photoCategory = greenRatio > 0.22 ? 'Nature & Travel' : 'Travel Photography';
    subjectDescription = 'Outdoor travel subject';
    pose = aspect > 1.1 ? 'sitting' : 'standing';
    poseDetail = aspect > 1.1 ? 'Outdoor scenic / seated framing' : 'Outdoor standing framing';
    cameraDistance = 'wide-shot';
    cameraAngle = 'slightly-elevated';
    originalEnvironment = greenRatio > 0.22 ? 'Lush outdoor nature scenery' : 'Open sky outdoor location';
    horizonY = 0.44;
    groundLevelY = 0.84;
    recommendedStyleId = 'golden-hour';
  } else if (avgEdge > 11 && skinRatio < 0.03) {
    photoCategory = 'Product Photography';
    subjectDescription = 'Product / still-life object';
    pose = 'object_still_life';
    poseDetail = 'Resting on flat surface';
    cameraDistance = 'close-up';
    cameraAngle = 'slightly-elevated';
    originalEnvironment = 'Tabletop / studio surface';
    horizonY = 0.68;
    groundLevelY = cutoutGeo && cutoutGeo.isGroundedInFrame ? Number(cutoutGeo.maxY.toFixed(2)) : 0.82;
    recommendedStyleId = 'modern';
  } else if (aspect > 1.15) {
    photoCategory = 'Travel & Street';
    subjectDescription = 'Subject in wide scene';
    pose = 'standing';
    poseDetail = 'Wide environmental framing';
    cameraDistance = 'wide-shot';
    originalEnvironment = 'Architectural / street environment';
    horizonY = 0.5;
    groundLevelY = 0.86;
    recommendedStyleId = 'cinematic';
  }

  // Rank Top 5 physically compatible backgrounds using full scene understanding
  const recommendedBackgrounds = rankBackgroundsForScene({
    pose,
    poseDetail,
    photoCategory,
    cameraDistance,
    cameraAngle,
    lightingDirection,
    originalEnvironment,
    avgLuminance: avgLum / 255,
  });

  const topRec = recommendedBackgrounds[0];
  const recommendedBackgroundId: BackgroundCategoryId = topRec?.id || 'professional-studio';
  const backgroundReason =
    topRec?.reason ||
    'Balanced studio lighting and natural depth preserve subject proportions cleanly.';

  // Compute balanced, natural 16-slider corrections from real image statistics
  const targetLum = photoCategory === 'Night & Street' ? 105 : 132;
  const exposureDelta = Math.max(-24, Math.min(28, Math.round((targetLum - avgLum) * 0.38)));
  const brightnessDelta = Math.max(-15, Math.min(18, Math.round((targetLum - avgLum) * 0.15)));
  const contrastDelta =
    dynamicRange < 155
      ? Math.min(24, Math.round((175 - dynamicRange) * 0.22))
      : dynamicRange > 225
      ? -6
      : 8;
  const highlightsDelta = p95 > 235 ? -22 : p95 > 215 ? -10 : 6;
  const shadowsDelta = p5 < 24 ? 26 : p5 < 42 ? 14 : 4;
  const whitesDelta = p95 < 210 ? 14 : -4;
  const blacksDelta = p5 > 36 ? -12 : 4;

  // Gray-world white balance gentle neutralization (40% damping to keep natural mood)
  const grayAvg = (avgR + avgG + avgB) / 3;
  const rbCast = avgR - avgB;
  const tempDelta = Math.max(
    -22,
    Math.min(22, Math.round(-rbCast * 0.28 + (skinRatio > 0.055 ? 4 : 0)))
  );
  const tintDelta = Math.max(-14, Math.min(14, Math.round((avgG - grayAvg) * 0.35)));

  const vibranceDelta = avgSat < 0.22 ? 22 : avgSat < 0.35 ? 12 : 4;
  const saturationDelta = avgSat < 0.18 ? 8 : avgSat > 0.52 ? -8 : 2;
  const sharpnessDelta = avgEdge < 10 ? 24 : 14;
  const clarityDelta = skinRatio > 0.055 ? 6 : 14;
  const skinToneDelta = skinRatio > 0.055 ? 14 : 0;
  const noiseReductionDelta = avgLum < 95 ? 24 : 8;
  const colorBalanceDelta =
    skinRatio > 0.055 ? 6 : photoCategory === 'Night & Street' ? -8 : 4;

  const issues: string[] = [];
  if (avgLum < 105) issues.push('lifted underexposed shadows');
  else if (avgLum > 165) issues.push('recovered bright highlights');
  else issues.push('refined exposure balance');

  if (Math.abs(rbCast) > 16)
    issues.push(rbCast > 0 ? 'neutralized warm color cast' : 'warmed cool color cast');
  if (dynamicRange < 165) issues.push('expanded tonal contrast');
  if (skinRatio > 0.055) issues.push('protected natural skin tones');

  return {
    engine: 'local-vision',
    photoCategory,
    subjectDescription,
    pose,
    poseDetail,
    subjectPosition,
    cameraAngle,
    cameraDistance,
    lightingDirection,
    lightingType,
    originalEnvironment,
    horizonY,
    groundLevelY,
    lightingDiagnosis: `Detected ${photoCategory.toLowerCase()} (${lightingDirection.replace('-', ' ')} light): ${issues.join(', ')}.`,
    recommendedBackgroundId,
    backgroundReason,
    recommendedBackgrounds,
    recommendedStyleId,
    adjustments: {
      exposure: exposureDelta,
      brightness: brightnessDelta,
      contrast: contrastDelta,
      highlights: highlightsDelta,
      shadows: shadowsDelta,
      whites: whitesDelta,
      blacks: blacksDelta,
      saturation: saturationDelta,
      vibrance: vibranceDelta,
      temperature: tempDelta,
      tint: tintDelta,
      sharpness: sharpnessDelta,
      clarity: clarityDelta,
      colorBalance: colorBalanceDelta,
      skinTone: skinToneDelta,
      noiseReduction: noiseReductionDelta,
    },
  };
}

export async function computeAIEnhanceAdjustments(imageUrl: string): Promise<ColorAdjustments> {
  const analysis = await analyzePhotoLocally(imageUrl);
  return {
    ...analysis.adjustments,
    clarity: Math.min(35, Math.max(12, analysis.adjustments.clarity + 8)),
    sharpness: Math.min(40, Math.max(18, analysis.adjustments.sharpness + 10)),
    noiseReduction: Math.max(14, analysis.adjustments.noiseReduction),
    vibrance: Math.min(26, Math.max(8, analysis.adjustments.vibrance + 4)),
  };
}

export async function computePortraitEnhanceAdjustments(imageUrl: string): Promise<ColorAdjustments> {
  const analysis = await analyzePhotoLocally(imageUrl);
  return {
    ...analysis.adjustments,
    exposure: Math.min(20, Math.max(4, analysis.adjustments.exposure + 4)),
    highlights: Math.min(-6, analysis.adjustments.highlights - 6),
    shadows: Math.min(32, Math.max(14, analysis.adjustments.shadows + 8)),
    temperature: Math.min(18, Math.max(4, analysis.adjustments.temperature + 5)),
    skinTone: 22,
    clarity: 4,
    sharpness: 16,
    noiseReduction: 22,
    vibrance: Math.min(18, Math.max(6, analysis.adjustments.vibrance)),
  };
}

/**
 * Draws procedural studio/scenic photographic backdrops when a category uses procedural generation.
 */
function drawProceduralBackdrop(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  preset: BackgroundPreset,
  passportColor: string,
  horizonShiftPct = 0
): void {
  const style = preset.proceduralStyle || 'studio-sweep';
  const shiftY = (horizonShiftPct / 100) * h * 0.45;

  if (style === 'passport') {
    ctx.fillStyle = passportColor || '#FFFFFF';
    ctx.fillRect(0, 0, w, h);
    const rad = ctx.createRadialGradient(
      w * 0.5,
      h * 0.42,
      w * 0.1,
      w * 0.5,
      h * 0.5,
      Math.max(w, h) * 0.78
    );
    rad.addColorStop(0, 'rgba(255,255,255,0.12)');
    rad.addColorStop(1, 'rgba(15,23,42,0.04)');
    ctx.fillStyle = rad;
    ctx.fillRect(0, 0, w, h);
    return;
  }

  // Base multi-stop studio gradient
  const [c0, c1, c2] = preset.gradientStops;
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, c0);
  grad.addColorStop(Math.max(0.2, Math.min(0.85, 0.58 + shiftY / Math.max(1, h))), c1);
  grad.addColorStop(1, c2);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  if (style === 'product-podium') {
    const keyLight = ctx.createRadialGradient(
      w * 0.5,
      h * 0.35,
      w * 0.05,
      w * 0.5,
      h * 0.45,
      w * 0.8
    );
    keyLight.addColorStop(0, 'rgba(255,255,255,0.95)');
    keyLight.addColorStop(1, 'rgba(203,213,225,0.2)');
    ctx.fillStyle = keyLight;
    ctx.fillRect(0, 0, w, h);

    const horizonY = Math.max(h * 0.42, Math.min(h * 0.86, h * 0.68 + shiftY));
    const floorGrad = ctx.createLinearGradient(0, horizonY, 0, h);
    floorGrad.addColorStop(0, '#e2e8f0');
    floorGrad.addColorStop(0.18, '#f1f5f9');
    floorGrad.addColorStop(1, '#cbd5e1');
    ctx.fillStyle = floorGrad;
    ctx.fillRect(0, horizonY, w, h - horizonY);

    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = Math.max(1, h * 0.003);
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    ctx.lineTo(w, horizonY);
    ctx.stroke();
    return;
  }

  if (style === 'business-slate' || style === 'fashion-editorial' || style === 'luxury-marble') {
    const key = ctx.createRadialGradient(
      w * 0.38,
      h * 0.3 + shiftY * 0.4,
      w * 0.04,
      w * 0.46,
      h * 0.42 + shiftY * 0.4,
      Math.max(w, h) * 0.72
    );
    key.addColorStop(0, 'rgba(255,255,255,0.52)');
    key.addColorStop(0.55, 'rgba(255,255,255,0.12)');
    key.addColorStop(1, 'rgba(15,23,42,0.34)');
    ctx.fillStyle = key;
    ctx.fillRect(0, 0, w, h);

    if (style === 'luxury-marble') {
      ctx.save();
      ctx.globalAlpha = 0.16;
      for (let i = 0; i < 4; i++) {
        const bx = w * (0.12 + i * 0.26);
        const col = ctx.createLinearGradient(bx, 0, bx + w * 0.12, h);
        col.addColorStop(0, '#fff7ed');
        col.addColorStop(1, 'transparent');
        ctx.fillStyle = col;
        ctx.fillRect(bx, 0, w * 0.09, h);
      }
      ctx.restore();
    }
    return;
  }

  if (style === 'nature-bokeh' || style === 'cinematic-teal') {
    const orbs =
      style === 'nature-bokeh'
        ? [
            { x: 0.18, y: 0.22, r: 0.16, c: 'rgba(254,249,195,0.45)' },
            { x: 0.76, y: 0.18, r: 0.2, c: 'rgba(220,252,231,0.38)' },
            { x: 0.55, y: 0.42, r: 0.12, c: 'rgba(255,255,255,0.32)' },
            { x: 0.85, y: 0.55, r: 0.18, c: 'rgba(134,239,172,0.28)' },
            { x: 0.24, y: 0.68, r: 0.22, c: 'rgba(21,128,61,0.32)' },
          ]
        : [
            { x: 0.16, y: 0.34, r: 0.14, c: 'rgba(251,146,60,0.48)' },
            { x: 0.82, y: 0.28, r: 0.18, c: 'rgba(56,189,248,0.36)' },
            { x: 0.68, y: 0.56, r: 0.11, c: 'rgba(253,186,116,0.42)' },
            { x: 0.28, y: 0.62, r: 0.16, c: 'rgba(14,165,233,0.25)' },
          ];
    orbs.forEach((o) => {
      const cy = h * o.y + shiftY * 0.5;
      const rg = ctx.createRadialGradient(w * o.x, cy, 0, w * o.x, cy, w * o.r);
      rg.addColorStop(0, o.c);
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg;
      ctx.beginPath();
      ctx.arc(w * o.x, cy, w * o.r, 0, Math.PI * 2);
      ctx.fill();
    });
    return;
  }

  if (style === 'mountain-mist') {
    const drawRidge = (baseY: number, amp: number, color: string, seed: number) => {
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (let x = 0; x <= w; x += Math.max(8, w / 40)) {
        const nx = x / w;
        const y =
          h * baseY +
          shiftY * 0.7 -
          Math.sin(nx * Math.PI * 2.2 + seed) * h * amp -
          Math.cos(nx * Math.PI * 5.1 + seed * 1.7) * h * (amp * 0.35);
        ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();
    };
    drawRidge(0.56, 0.08, 'rgba(148,163,184,0.45)', 0.5);
    drawRidge(0.68, 0.09, 'rgba(71,85,105,0.58)', 2.1);
    drawRidge(0.8, 0.06, 'rgba(30,41,59,0.72)', 4.2);
    const mist = ctx.createLinearGradient(0, h * 0.45, 0, h * 0.82);
    mist.addColorStop(0, 'rgba(255,255,255,0)');
    mist.addColorStop(0.5, 'rgba(241,245,249,0.38)');
    mist.addColorStop(1, 'rgba(241,245,249,0)');
    ctx.fillStyle = mist;
    ctx.fillRect(0, h * 0.45, w, h * 0.37);
    return;
  }

  if (style === 'beach-horizon') {
    const hLine = Math.max(h * 0.32, Math.min(h * 0.72, h * 0.54 + shiftY));
    const shoreLine = Math.min(h * 0.9, hLine + h * 0.2);

    const sky = ctx.createLinearGradient(0, 0, 0, hLine);
    sky.addColorStop(0, '#bae6fd');
    sky.addColorStop(1, '#f0f9ff');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, hLine);

    const sea = ctx.createLinearGradient(0, hLine, 0, shoreLine);
    sea.addColorStop(0, '#0284c7');
    sea.addColorStop(0.6, '#38bdf8');
    sea.addColorStop(1, '#a5f3fc');
    ctx.fillStyle = sea;
    ctx.fillRect(0, hLine, w, shoreLine - hLine);

    const sand = ctx.createLinearGradient(0, shoreLine, 0, h);
    sand.addColorStop(0, '#f5ebd6');
    sand.addColorStop(1, '#decba8');
    ctx.fillStyle = sand;
    ctx.fillRect(0, shoreLine, w, h - shoreLine);
  }
}

/**
 * Photorealistically composites an RGBA subject cutout onto a new background with:
 * - Perspective & horizon vertical alignment (horizonShift)
 * - Camera-distance matched depth-of-field background blur
 * - Two-zone (sky/key + ground bounce) directional relighting & skin-protected color matching
 * - Halo-free hair/clothing edge decontamination & ambient rim light wrap
 * - Physically grounded Ambient Occlusion contact shadow + perspective-flattened cast shadow
 *   (strictly anchored to the subject's footprint when grounded; no floating cutout halo on cropped busts)
 * - Exact 1:1 original subject position, size, and proportions preservation at subjectScale = 100%
 */
export async function compositeSubjectWithBackground(
  targetCtx: CanvasRenderingContext2D,
  w: number,
  h: number,
  cutoutImg: HTMLImageElement,
  bg: BackgroundState
): Promise<void> {
  targetCtx.clearRect(0, 0, w, h);

  const geo = measureCutoutGeometry(cutoutImg);

  if (bg.categoryId === 'transparent') {
    drawScaledSubject(targetCtx, cutoutImg, w, h, bg.blend.subjectScale, bg.blend.edgeRefine, geo);
    return;
  }

  const preset =
    BACKGROUND_PRESETS.find((p) => p.id === bg.categoryId) || BACKGROUND_PRESETS[0];

  const horizonShift = bg.blend.horizonShift ?? 0;
  const lightDir: LightingDirection =
    bg.blend.lightingDirection || preset.keyLightDirection || 'top-left';

  // 1. Render background onto offscreen canvas with perspective horizon alignment & DoF blur
  const bgCanvas = document.createElement('canvas');
  bgCanvas.width = w;
  bgCanvas.height = h;
  const bgCtx = bgCanvas.getContext('2d', { willReadFrequently: true });
  if (!bgCtx) return;

  const blurPx = Math.round((bg.blend.backgroundBlur / 100) * Math.max(w, h) * 0.018);

  if (blurPx > 0) {
    bgCtx.filter = `blur(${blurPx}px)`;
  }

  const bgImageUrl =
    bg.categoryId === 'custom-upload' && bg.customImageUrl
      ? bg.customImageUrl
      : preset.imageUrl;

  if (bgImageUrl) {
    try {
      const bgImg = await loadImage(bgImageUrl);
      // Add vertical overscan headroom proportional to horizonShift so vertical perspective alignment never exposes blank bars
      const shiftPx = (horizonShift / 100) * h * 0.45;
      const overscanX = blurPx > 0 ? blurPx * 2 : 0;
      const overscanY = Math.abs(shiftPx) + (blurPx > 0 ? blurPx * 2 : 0);
      const drawW = w + overscanX * 2;
      const drawH = h + overscanY * 2;
      const scale = Math.max(drawW / bgImg.naturalWidth, drawH / bgImg.naturalHeight);
      const sw = bgImg.naturalWidth * scale;
      const sh = bgImg.naturalHeight * scale;
      const drawX = (w - sw) / 2;
      const drawY = (h - sh) / 2 + shiftPx;
      bgCtx.drawImage(bgImg, drawX, drawY, sw, sh);
    } catch {
      bgCtx.filter = 'none';
      drawProceduralBackdrop(bgCtx, w, h, preset, bg.passportColor, horizonShift);
    }
  } else {
    drawProceduralBackdrop(bgCtx, w, h, preset, bg.passportColor, horizonShift);
  }
  bgCtx.filter = 'none';

  // Draw aligned background onto target
  targetCtx.drawImage(bgCanvas, 0, 0);

  // Sample two-zone ambient light (upper sky/key + lower ground bounce) from rendered background
  let ambR = preset.ambientTint[0];
  let ambG = preset.ambientTint[1];
  let ambB = preset.ambientTint[2];
  let ambLum = preset.ambientLuminance;
  let groundR = ambR * 0.85;
  let groundG = ambG * 0.85;
  let groundB = ambB * 0.85;

  try {
    const sampleCanvas = document.createElement('canvas');
    sampleCanvas.width = 24;
    sampleCanvas.height = 24;
    const sCtx = sampleCanvas.getContext('2d', { willReadFrequently: true });
    if (sCtx) {
      sCtx.drawImage(bgCanvas, 0, 0, 24, 24);
      const sData = sCtx.getImageData(0, 0, 24, 24).data;
      let tr = 0;
      let tg = 0;
      let tb = 0;
      let gr = 0;
      let gg = 0;
      let gb = 0;
      const halfN = 24 * 12;
      for (let y = 0; y < 24; y++) {
        for (let x = 0; x < 24; x++) {
          const i = (y * 24 + x) * 4;
          if (y < 12) {
            tr += sData[i];
            tg += sData[i + 1];
            tb += sData[i + 2];
          } else {
            gr += sData[i];
            gg += sData[i + 1];
            gb += sData[i + 2];
          }
        }
      }
      ambR = (tr * 0.65 + gr * 0.35) / halfN;
      ambG = (tg * 0.65 + gg * 0.35) / halfN;
      ambB = (tb * 0.65 + gb * 0.35) / halfN;
      groundR = gr / halfN;
      groundG = gg / halfN;
      groundB = gb / halfN;
      ambLum = (0.299 * ambR + 0.587 * ambG + 0.114 * ambB) / 255;
    }
  } catch {
    // keep preset defaults
  }

  // 2. Prepare subject cutout at exact preserved position & size for directional relighting & edge decontamination
  const subCanvas = document.createElement('canvas');
  subCanvas.width = w;
  subCanvas.height = h;
  const subCtx = subCanvas.getContext('2d', { willReadFrequently: true });
  if (!subCtx) return;

  drawScaledSubject(subCtx, cutoutImg, w, h, bg.blend.subjectScale, bg.blend.edgeRefine, geo);

  const lightStrength = bg.blend.lightMatch / 100;
  const colorStrength = bg.blend.colorMatch / 100;
  const edgeStrength = bg.blend.edgeRefine / 100;

  if (lightStrength > 0 || colorStrength > 0 || edgeStrength > 0) {
    const imgData = subCtx.getImageData(0, 0, w, h);
    const d = imgData.data;

    let subLumSum = 0;
    let subPixels = 0;
    for (let i = 0; i < d.length; i += 16) {
      if (d[i + 3] > 180) {
        subLumSum += (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) / 255;
        subPixels++;
      }
    }
    const subLum = subPixels > 0 ? subLumSum / subPixels : 0.5;
    // Bounded photographic exposure match (never blows highlights or crushes blacks)
    const baseLumRatio = Math.max(
      0.84,
      Math.min(1.18, 1 + (ambLum - subLum) * 0.42 * lightStrength)
    );

    // Directional key gradient vector across the subject
    const dirX =
      lightDir === 'left' || lightDir === 'top-left'
        ? -1
        : lightDir === 'right' || lightDir === 'top-right'
        ? 1
        : 0;
    const dirY = lightDir === 'top-left' || lightDir === 'top-right' ? -0.6 : 0;
    const isBacklit = lightDir === 'backlit';

    const tintR = (ambR - 128) * 0.14 * colorStrength;
    const tintG = (ambG - 128) * 0.14 * colorStrength;
    const tintB = (ambB - 128) * 0.14 * colorStrength;

    const subMinX = geo.minX * w;
    const subSpanX = Math.max(1, geo.widthRatio * w);
    const subMinY = geo.minY * h;
    const subSpanY = Math.max(1, geo.heightRatio * h);

    for (let y = 0; y < h; y++) {
      const ny = (y - subMinY) / subSpanY; // 0 (top) .. 1 (bottom)
      const groundBounceWeight = Math.max(0, Math.min(1, (ny - 0.55) / 0.45)) * 0.08 * colorStrength;

      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const a = d[i + 3];
        if (a === 0) continue;

        const nx = (x - subMinX) / subSpanX; // 0 (left) .. 1 (right)
        // Subtle directional shading so lit side matches background key light
        const directionalBias =
          ((nx - 0.5) * dirX * 0.085 + (ny - 0.5) * dirY * 0.05) * lightStrength;
        const lumRatio = baseLumRatio + directionalBias;

        let r = d[i] * lumRatio;
        let g = d[i + 1] * lumRatio;
        let b = d[i + 2] * lumRatio;

        // Protect natural skin tones from excessive cool/green background color cast
        const isSkin = r > 78 && g > 40 && b > 22 && r > g && r > b && r - Math.min(g, b) > 14;
        const castScale = isSkin ? 0.55 : 1.0;

        r += tintR * castScale + (groundR - 128) * groundBounceWeight;
        g += tintG * castScale + (groundG - 128) * groundBounceWeight;
        b += tintB * castScale + (groundB - 128) * groundBounceWeight;

        // Hair & clothing edge light-wrap + halo decontamination on semi-transparent fringe
        if (a < 238 && edgeStrength > 0) {
          const fringeNorm = 1 - a / 238;
          const wrapBoost = isBacklit ? 0.62 : 0.44;
          const fringe = fringeNorm * wrapBoost * edgeStrength;
          r = r * (1 - fringe) + ambR * fringe;
          g = g * (1 - fringe) + ambG * fringe;
          b = b * (1 - fringe) + ambB * fringe;

          // Trim faint residual bright/dark original-background halo pixels
          if (a < 42) {
            d[i + 3] = Math.round(a * (1 - edgeStrength * 0.48));
          }
        }

        d[i] = clamp255(r);
        d[i + 1] = clamp255(g);
        d[i + 2] = clamp255(b);
      }
    }
    subCtx.putImageData(imgData, 0, 0);
  }

  // 3. Physically grounded contact shadow & perspective cast shadow
  const shadowStrength = bg.blend.shadowDepth / 100;
  const scaleFactor = bg.blend.subjectScale / 100;

  if (shadowStrength > 0.02 && bg.categoryId !== 'passport-id') {
    const scaledGroundY = Math.min(h * 0.99, geo.maxY * h);
    const contactLeftX = geo.contactMinX * w;
    const contactRightX = geo.contactMaxX * w;
    const contactCenterX = (contactLeftX + contactRightX) / 2;
    const contactWidth = Math.max(w * 0.1, (contactRightX - contactLeftX) * scaleFactor);

    if (geo.isGroundedInFrame) {
      // A. Perspective-flattened directional cast shadow anchored strictly to ground plane (maxY)
      const castCanvas = document.createElement('canvas');
      castCanvas.width = w;
      castCanvas.height = h;
      const castCtx = castCanvas.getContext('2d');
      if (castCtx) {
        castCtx.drawImage(subCanvas, 0, 0);
        castCtx.globalCompositeOperation = 'source-in';
        // Tint shadow slightly toward cool dark ground ambient rather than pure pitch black
        const shR = Math.round(Math.max(10, groundR * 0.12));
        const shG = Math.round(Math.max(14, groundG * 0.14));
        const shB = Math.round(Math.max(22, groundB * 0.2));
        castCtx.fillStyle = `rgb(${shR}, ${shG}, ${shB})`;
        castCtx.fillRect(0, 0, w, h);

        // Cast shadow projects AWAY from key light direction
        const skewX =
          lightDir === 'left' || lightDir === 'top-left'
            ? 0.42
            : lightDir === 'right' || lightDir === 'top-right'
            ? -0.42
            : lightDir === 'backlit'
            ? 0
            : 0.14;
        const squashY = lightDir === 'backlit' ? 0.26 : 0.19;
        const castBlur = Math.max(4, Math.round(Math.max(w, h) * 0.016));

        targetCtx.save();
        targetCtx.globalAlpha = 0.28 * shadowStrength;
        targetCtx.filter = `blur(${castBlur}px)`;
        targetCtx.translate(contactCenterX, scaledGroundY);
        targetCtx.transform(1, 0, skewX, squashY, 0, 0);
        targetCtx.translate(-contactCenterX, -scaledGroundY);
        targetCtx.drawImage(castCanvas, 0, 0);
        targetCtx.restore();
      }

      // B. Tight Ambient Occlusion contact shadow directly beneath feet / seated base / object bottom
      targetCtx.save();
      const aoRx = contactWidth * 0.58;
      const aoRy = Math.max(6, Math.min(h * 0.055, contactWidth * 0.14));
      const aoOffsetX =
        lightDir === 'left' || lightDir === 'top-left'
          ? aoRx * 0.1
          : lightDir === 'right' || lightDir === 'top-right'
          ? -aoRx * 0.1
          : 0;

      targetCtx.translate(contactCenterX + aoOffsetX, scaledGroundY - aoRy * 0.1);
      targetCtx.scale(1, aoRy / Math.max(1, aoRx));
      const aoGrad = targetCtx.createRadialGradient(0, 0, aoRx * 0.08, 0, 0, aoRx);
      aoGrad.addColorStop(0, `rgba(12, 18, 30, ${(0.52 * shadowStrength).toFixed(3)})`);
      aoGrad.addColorStop(0.55, `rgba(15, 23, 42, ${(0.24 * shadowStrength).toFixed(3)})`);
      aoGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      targetCtx.fillStyle = aoGrad;
      targetCtx.beginPath();
      targetCtx.arc(0, 0, aoRx, 0, Math.PI * 2);
      targetCtx.fill();
      targetCtx.restore();
    } else if (shadowStrength > 0.18) {
      // Portrait cropped at chest/waist: NO floating cutout halo around hair/shoulders!
      // Apply only a gentle, wide studio depth falloff behind the lower torso to anchor depth naturally.
      targetCtx.save();
      const torsoCx = geo.centerX * w;
      const torsoCy = h * 0.78;
      const rad = Math.max(w, h) * 0.42;
      const depthGrad = targetCtx.createRadialGradient(torsoCx, torsoCy, rad * 0.05, torsoCx, torsoCy, rad);
      depthGrad.addColorStop(0, `rgba(15, 23, 42, ${(0.14 * shadowStrength).toFixed(3)})`);
      depthGrad.addColorStop(1, 'rgba(15, 23, 42, 0)');
      targetCtx.fillStyle = depthGrad;
      targetCtx.fillRect(0, 0, w, h);
      targetCtx.restore();
    }
  }

  // 4. Composite harmonized subject sharply over grounded shadows
  targetCtx.drawImage(subCanvas, 0, 0);
}

function drawScaledSubject(
  ctx: CanvasRenderingContext2D,
  cutoutImg: HTMLImageElement,
  w: number,
  h: number,
  subjectScalePct: number,
  edgeRefine: number,
  geo?: CutoutGeometry
): void {
  ctx.save();
  if (edgeRefine > 35) {
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
  }

  // At default 100% scale, preserve exact original subject position, size, and proportions 1:1
  if (Math.abs(subjectScalePct - 100) < 0.01) {
    ctx.drawImage(cutoutImg, 0, 0, w, h);
    ctx.restore();
    return;
  }

  const scale = subjectScalePct / 100;
  const dw = w * scale;
  const dh = h * scale;
  // Scale around the subject's real horizontal center & ground plane so it stays anchored
  const anchorX = geo ? geo.centerX * w : w / 2;
  const anchorY = geo ? geo.maxY * h : h;
  const dx = anchorX - anchorX * scale;
  const dy = anchorY - anchorY * scale;

  ctx.drawImage(cutoutImg, dx, dy, dw, dh);
  ctx.restore();
}

/**
 * Draws text and vector sticker layers onto a canvas context.
 */
async function drawOverlays(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  textLayers: TextLayer[],
  stickerLayers: StickerLayer[]
): Promise<void> {
  const refDim = Math.min(w, h);

  // Stickers
  for (const layer of stickerLayers) {
    const preset = STICKER_PRESETS.find((s) => s.id === layer.stickerId);
    if (!preset) continue;
    const svgUrl = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(preset.svg)}`;
    try {
      const img = await loadImage(svgUrl);
      const baseSize = refDim * 0.22 * layer.scale;
      const aspect = img.naturalWidth / Math.max(1, img.naturalHeight);
      const drawW = aspect >= 1 ? baseSize : baseSize * aspect;
      const drawH = aspect >= 1 ? baseSize / aspect : baseSize;
      const cx = (layer.x / 100) * w;
      const cy = (layer.y / 100) * h;

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate((layer.rotation * Math.PI) / 180);
      ctx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
      ctx.restore();
    } catch {
      // ignore failed sticker draw
    }
  }

  // Text layers
  for (const t of textLayers) {
    if (!t.text.trim()) continue;
    const fontPx = Math.max(12, Math.round((t.fontSize / 420) * refDim));
    const cx = (t.x / 100) * w;
    const cy = (t.y / 100) * h;

    ctx.save();
    ctx.font = `700 ${fontPx}px "${t.fontFamily}", sans-serif`;
    ctx.textAlign = t.align;
    ctx.textBaseline = 'middle';

    const lines = t.text.split('\n');
    const lineHeight = fontPx * 1.24;
    const maxLineW = Math.max(...lines.map((l) => ctx.measureText(l).width));
    const blockH = lines.length * lineHeight;

    if (t.bgStyle !== 'none') {
      const padX = fontPx * 0.55;
      const padY = fontPx * 0.32;
      let bx = cx - maxLineW / 2 - padX;
      if (t.align === 'left') bx = cx - padX;
      if (t.align === 'right') bx = cx - maxLineW - padX;
      const by = cy - blockH / 2 - padY;
      const bw = maxLineW + padX * 2;
      const bh = blockH + padY * 2;
      const r = Math.min(14, fontPx * 0.35);

      ctx.fillStyle = t.bgStyle === 'solid' ? 'rgba(15, 23, 42, 0.85)' : 'rgba(255, 255, 255, 0.72)';
      ctx.beginPath();
      ctx.roundRect(bx, by, bw, bh, r);
      ctx.fill();
    } else {
      ctx.shadowColor = 'rgba(15, 23, 42, 0.45)';
      ctx.shadowBlur = Math.max(4, fontPx * 0.22);
      ctx.shadowOffsetY = 2;
    }

    ctx.fillStyle = t.color;
    lines.forEach((line, idx) => {
      const ly = cy - ((lines.length - 1) * lineHeight) / 2 + idx * lineHeight;
      ctx.fillText(line, cx, ly);
    });
    ctx.restore();
  }
}

/**
 * Renders an entire EditorSnapshot (base or composited background + transform + 16 adjustments + style + overlays)
 * into a target canvas at either preview or full export resolution.
 */
export async function renderSnapshotToCanvas(
  canvas: HTMLCanvasElement,
  snapshot: EditorSnapshot,
  maxDimension?: number,
  includeOverlays = true
): Promise<{ width: number; height: number }> {
  const baseImg = await loadImage(snapshot.baseImageUrl);
  const srcW = baseImg.naturalWidth;
  const srcH = baseImg.naturalHeight;

  let workW = srcW;
  let workH = srcH;
  if (maxDimension && Math.max(srcW, srcH) > maxDimension) {
    const scale = maxDimension / Math.max(srcW, srcH);
    workW = Math.max(1, Math.round(srcW * scale));
    workH = Math.max(1, Math.round(srcH * scale));
  }

  // Step 1: Render base image OR cutout + replaced background in upright source space
  const workCanvas = document.createElement('canvas');
  workCanvas.width = workW;
  workCanvas.height = workH;
  const workCtx = workCanvas.getContext('2d', { willReadFrequently: true });
  if (!workCtx) throw new Error('Canvas context unavailable');

  const usesBackgroundReplacement =
    Boolean(snapshot.cutoutImageUrl) && snapshot.background.categoryId !== 'original';

  if (usesBackgroundReplacement && snapshot.cutoutImageUrl) {
    const cutoutImg = await loadImage(snapshot.cutoutImageUrl);
    await compositeSubjectWithBackground(workCtx, workW, workH, cutoutImg, snapshot.background);
  } else {
    workCtx.drawImage(baseImg, 0, 0, workW, workH);
  }

  // Step 2: Apply 16 adjustments merged with active Color Style
  const effectiveAdj = mergeAdjustmentsWithStyle(
    snapshot.adjustments,
    snapshot.styleId,
    snapshot.styleIntensity
  );
  const needsPixelPass = (Object.keys(DEFAULT_ADJUSTMENTS) as Array<keyof ColorAdjustments>).some(
    (k) => effectiveAdj[k] !== 0
  );
  if (needsPixelPass) {
    const imgData = workCtx.getImageData(0, 0, workW, workH);
    applyColorAdjustments(imgData, effectiveAdj);
    workCtx.putImageData(imgData, 0, 0);
  }

  // Step 3: Apply Rotation & Flip onto output canvas
  const rot = ((snapshot.transform.rotation % 360) + 360) % 360;
  const swapAxes = rot === 90 || rot === 270;
  const outW = swapAxes ? workH : workW;
  const outH = swapAxes ? workW : workH;

  canvas.width = outW;
  canvas.height = outH;
  const outCtx = canvas.getContext('2d');
  if (!outCtx) throw new Error('Output canvas context unavailable');

  outCtx.clearRect(0, 0, outW, outH);
  outCtx.save();
  outCtx.translate(outW / 2, outH / 2);
  outCtx.rotate((rot * Math.PI) / 180);
  outCtx.scale(snapshot.transform.flipH ? -1 : 1, snapshot.transform.flipV ? -1 : 1);
  outCtx.drawImage(workCanvas, -workW / 2, -workH / 2, workW, workH);
  outCtx.restore();

  // Step 4: Draw Text & Sticker Overlays
  if (includeOverlays && (snapshot.textLayers.length > 0 || snapshot.stickerLayers.length > 0)) {
    await drawOverlays(outCtx, outW, outH, snapshot.textLayers, snapshot.stickerLayers);
  }

  return { width: outW, height: outH };
}

/**
 * Crops an image URL using normalized [0..1] crop coordinates and returns a crisp PNG data URL.
 */
export async function applyCropToImageUrl(imageUrl: string, crop: CropRect): Promise<string> {
  const img = await loadImage(imageUrl);
  const sx = Math.max(0, Math.round(crop.x * img.naturalWidth));
  const sy = Math.max(0, Math.round(crop.y * img.naturalHeight));
  const sw = Math.max(16, Math.round(crop.width * img.naturalWidth));
  const sh = Math.max(16, Math.round(crop.height * img.naturalHeight));

  const c = document.createElement('canvas');
  c.width = sw;
  c.height = sh;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('Unable to crop image');
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
  return c.toDataURL('image/png');
}

/**
 * Real client-side brush Object Removal:
 * Multi-pass boundary-priority harmonic diffusion + micro-texture transfer inside the painted mask.
 */
export async function inpaintMaskedRegion(
  baseImageUrl: string,
  maskCanvas: HTMLCanvasElement
): Promise<string> {
  const img = await loadImage(baseImageUrl);
  const w = img.naturalWidth;
  const h = img.naturalHeight;

  const workCanvas = document.createElement('canvas');
  workCanvas.width = w;
  workCanvas.height = h;
  const ctx = workCanvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Canvas unavailable');
  ctx.drawImage(img, 0, 0, w, h);

  // Resample user's mask canvas to image resolution
  const scaledMask = document.createElement('canvas');
  scaledMask.width = w;
  scaledMask.height = h;
  const mCtx = scaledMask.getContext('2d', { willReadFrequently: true });
  if (!mCtx) throw new Error('Mask canvas unavailable');
  mCtx.drawImage(maskCanvas, 0, 0, w, h);

  const imgData = ctx.getImageData(0, 0, w, h);
  const maskData = mCtx.getImageData(0, 0, w, h).data;
  const data = imgData.data;

  // Build binary mask & bounding box of painted area for fast performance
  const mask = new Uint8Array(w * h);
  let minX = w;
  let minY = h;
  let maxX = 0;
  let maxY = 0;
  let maskedCount = 0;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = y * w + x;
      if (maskData[idx * 4 + 3] > 28) {
        mask[idx] = 1;
        maskedCount++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }

  if (maskedCount === 0) {
    return baseImageUrl;
  }

  // Pad bounding box slightly
  minX = Math.max(1, minX - 2);
  minY = Math.max(1, minY - 2);
  maxX = Math.min(w - 2, maxX + 2);
  maxY = Math.min(h - 2, maxY + 2);

  // Phase 1: Onion-peel inward fill from clean boundary pixels so large holes fill quickly
  const known = new Uint8Array(w * h);
  for (let i = 0; i < w * h; i++) {
    known[i] = mask[i] === 1 ? 0 : 1;
  }

  let remaining = maskedCount;
  const maxPeelSteps = Math.max(maxX - minX, maxY - minY) + 10;
  const nextKnown: number[] = [];

  for (let step = 0; step < maxPeelSteps && remaining > 0; step++) {
    nextKnown.length = 0;
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const idx = y * w + x;
        if (known[idx] === 1) continue;

        let sr = 0;
        let sg = 0;
        let sb = 0;
        let count = 0;

        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            if (dx === 0 && dy === 0) continue;
            const nIdx = (y + dy) * w + (x + dx);
            if (known[nIdx] === 1) {
              const weight = dx === 0 || dy === 0 ? 1.4 : 1.0;
              sr += data[nIdx * 4] * weight;
              sg += data[nIdx * 4 + 1] * weight;
              sb += data[nIdx * 4 + 2] * weight;
              count += weight;
            }
          }
        }

        if (count > 0) {
          data[idx * 4] = clamp255(sr / count);
          data[idx * 4 + 1] = clamp255(sg / count);
          data[idx * 4 + 2] = clamp255(sb / count);
          nextKnown.push(idx);
        }
      }
    }

    if (nextKnown.length === 0) break;
    for (let k = 0; k < nextKnown.length; k++) {
      known[nextKnown[k]] = 1;
    }
    remaining -= nextKnown.length;
  }

  // Phase 2: Iterative harmonic relaxation + subtle natural grain matching so filled area blends seamlessly
  const relaxIterations = 24;
  for (let iter = 0; iter < relaxIterations; iter++) {
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const idx = y * w + x;
        if (mask[idx] === 0) continue;
        const p = idx * 4;
        const up = (idx - w) * 4;
        const dn = (idx + w) * 4;
        const lf = (idx - 1) * 4;
        const rt = (idx + 1) * 4;

        data[p] = (data[up] + data[dn] + data[lf] + data[rt]) * 0.25;
        data[p + 1] = (data[up + 1] + data[dn + 1] + data[lf + 1] + data[rt + 1]) * 0.25;
        data[p + 2] = (data[up + 2] + data[dn + 2] + data[lf + 2] + data[rt + 2]) * 0.25;
      }
    }
  }

  // Phase 3: Estimate surrounding border noise variance and reintroduce organic micro-grain
  let grainAccum = 0;
  let grainSamples = 0;
  for (let y = minY; y <= maxY; y += 2) {
    for (let x = minX; x <= maxX; x += 2) {
      const idx = y * w + x;
      if (mask[idx] === 0) {
        const l1 = data[idx * 4];
        const l2 = data[(idx + 1) * 4];
        grainAccum += Math.abs(l1 - l2);
        grainSamples++;
      }
    }
  }
  const grainAmp = Math.min(7, (grainAccum / Math.max(1, grainSamples)) * 0.65);
  if (grainAmp > 0.8) {
    let seed = 1337;
    for (let y = minY; y <= maxY; y++) {
      for (let x = minX; x <= maxX; x++) {
        const idx = y * w + x;
        if (mask[idx] === 0) continue;
        seed = (seed * 16807) % 2147483647;
        const n = ((seed / 2147483647) * 2 - 1) * grainAmp;
        const p = idx * 4;
        data[p] = clamp255(data[p] + n);
        data[p + 1] = clamp255(data[p + 1] + n);
        data[p + 2] = clamp255(data[p + 2] + n);
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return workCanvas.toDataURL('image/png');
}

/**
 * Exports the full-resolution edited photo in JPG, PNG, or true Alpha-Transparent PNG.
 */
export async function exportSnapshotBlob(
  snapshot: EditorSnapshot,
  format: ExportFormat,
  qualityPct: number
): Promise<{ blob: Blob; width: number; height: number; mimeType: string; extension: string }> {
  const exportCanvas = document.createElement('canvas');

  // For Transparent PNG export, render cutout with transparent background
  const exportSnapshot: EditorSnapshot =
    format === 'transparent-png' && snapshot.cutoutImageUrl
      ? {
          ...snapshot,
          background: { ...snapshot.background, categoryId: 'transparent' },
        }
      : snapshot;

  const { width, height } = await renderSnapshotToCanvas(exportCanvas, exportSnapshot, undefined, true);

  const mimeType = format === 'image/jpeg' ? 'image/jpeg' : 'image/png';
  const extension = format === 'image/jpeg' ? 'jpg' : 'png';

  // If exporting JPG over a transparent canvas, flatten cleanly over white first
  if (mimeType === 'image/jpeg') {
    const flatCanvas = document.createElement('canvas');
    flatCanvas.width = width;
    flatCanvas.height = height;
    const fCtx = flatCanvas.getContext('2d');
    if (fCtx) {
      fCtx.fillStyle = '#FFFFFF';
      fCtx.fillRect(0, 0, width, height);
      fCtx.drawImage(exportCanvas, 0, 0);
      const blob = await new Promise<Blob>((resolve, reject) => {
        flatCanvas.toBlob(
          (b) => (b ? resolve(b) : reject(new Error('Failed to encode JPEG'))),
          'image/jpeg',
          Math.max(0.5, Math.min(1, qualityPct / 100))
        );
      });
      return { blob, width, height, mimeType, extension };
    }
  }

  const blob = await new Promise<Blob>((resolve, reject) => {
    exportCanvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Failed to encode PNG'))),
      'image/png'
    );
  });

  return { blob, width, height, mimeType, extension };
}
