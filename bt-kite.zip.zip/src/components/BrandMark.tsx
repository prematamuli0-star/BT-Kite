import React from 'react';

interface BrandMarkProps {
  className?: string;
}

export const BrandMark: React.FC<BrandMarkProps> = ({ className = 'w-8 h-8' }) => (
  <svg
    viewBox="0 0 40 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect width="40" height="40" rx="10" fill="#2563EB" />
    <path d="M20 7L31.5 18L20 33.5L8.5 18L20 7Z" fill="#FFFFFF" />
    <path d="M20 7L31.5 18L20 21V7Z" fill="#DBEAFE" />
    <path d="M20 21L31.5 18L20 33.5V21Z" fill="#BFDBFE" />
    <circle cx="20" cy="18" r="2.7" fill="#2563EB" />
  </svg>
);
