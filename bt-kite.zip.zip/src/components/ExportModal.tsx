import React, { useEffect, useState } from 'react';
import { Check, Download, Share2, X } from 'lucide-react';
import { exportSnapshotBlob } from '../lib/imageEngine';
import { EditorSnapshot, ExportFormat } from '../types/editor';

interface ExportModalProps {
  open: boolean;
  snapshot: EditorSnapshot;
  originalName: string;
  onClose: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  open,
  snapshot,
  originalName,
  onClose,
}) => {
  const hasCutout = Boolean(snapshot.cutoutImageUrl);
  const [format, setFormat] = useState<ExportFormat>(
    snapshot.background.categoryId === 'transparent' && hasCutout ? 'transparent-png' : 'image/jpeg'
  );
  const [quality, setQuality] = useState(92);
  const [rendering, setRendering] = useState(false);
  const [meta, setMeta] = useState<{
    width: number;
    height: number;
    size: number;
    blob: Blob | null;
    extension: string;
    mimeType: string;
  }>({
    width: 0,
    height: 0,
    size: 0,
    blob: null,
    extension: 'jpg',
    mimeType: 'image/jpeg',
  });
  const [statusNote, setStatusNote] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    if (snapshot.background.categoryId === 'transparent' && hasCutout) {
      setFormat('transparent-png');
    } else if (format === 'transparent-png' && !hasCutout) {
      setFormat('image/jpeg');
    }
  }, [open, hasCutout, snapshot.background.categoryId]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setRendering(true);
    setStatusNote(null);

    exportSnapshotBlob(snapshot, format, quality)
      .then((res) => {
        if (cancelled) return;
        setMeta({
          width: res.width,
          height: res.height,
          size: res.blob.size,
          blob: res.blob,
          extension: res.extension,
          mimeType: res.mimeType,
        });
      })
      .catch((err) => {
        if (!cancelled) {
          setStatusNote(err instanceof Error ? err.message : 'Export render failed');
        }
      })
      .finally(() => {
        if (!cancelled) setRendering(false);
      });

    return () => {
      cancelled = true;
    };
  }, [open, snapshot, format, quality]);

  if (!open) return null;

  const cleanBaseName = originalName.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_-]/g, '_') || 'bt_kite_edit';
  const fileName = `${cleanBaseName}_btkite.${meta.extension}`;

  const handleDownload = () => {
    if (!meta.blob) return;
    const url = URL.createObjectURL(meta.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatusNote(`Saved ${fileName} to your device.`);
  };

  const handleShare = async () => {
    if (!meta.blob) return;
    const file = new File([meta.blob], fileName, { type: meta.mimeType });
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({
          title: 'Edited with BT Kite',
          text: 'Photo edited in BT Kite by BT Media Studio',
          files: [file],
        });
        setStatusNote('Shared successfully.');
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        handleDownload();
      }
    } else {
      handleDownload();
      setStatusNote('Direct app share is not available in this browser — downloaded instead.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-sm sm:p-4">
      <div className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-bold text-slate-900">Export & Share</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Original photo remains untouched
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close export modal"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* Format Selection */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-2">
              Export Format
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setFormat('image/jpeg')}
                className={`min-h-[48px] px-3 py-2 rounded-xl border text-center transition cursor-pointer ${
                  format === 'image/jpeg'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-semibold'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="text-xs font-semibold">JPG</div>
                <div className="text-[11px] text-slate-500">Smallest file</div>
              </button>

              <button
                type="button"
                onClick={() => setFormat('image/png')}
                className={`min-h-[48px] px-3 py-2 rounded-xl border text-center transition cursor-pointer ${
                  format === 'image/png'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-semibold'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="text-xs font-semibold">PNG</div>
                <div className="text-[11px] text-slate-500">Lossless</div>
              </button>

              <button
                type="button"
                disabled={!hasCutout}
                onClick={() => setFormat('transparent-png')}
                className={`min-h-[48px] px-3 py-2 rounded-xl border text-center transition ${
                  !hasCutout
                    ? 'border-slate-100 bg-slate-50 text-slate-400 cursor-not-allowed'
                    : format === 'transparent-png'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-semibold cursor-pointer'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 cursor-pointer'
                }`}
              >
                <div className="text-xs font-semibold">Cutout PNG</div>
                <div className="text-[11px] text-slate-500">
                  {hasCutout ? 'Transparent' : 'Remove BG first'}
                </div>
              </button>
            </div>
          </div>

          {/* Quality Slider (for JPG) */}
          {format === 'image/jpeg' && (
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-semibold text-slate-700">Image Quality</span>
                <span className="font-mono tabular-nums font-medium text-blue-600">{quality}%</span>
              </div>
              <input
                type="range"
                min={60}
                max={100}
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full studio-slider"
              />
            </div>
          )}

          {/* Output Metadata Summary */}
          <div className="rounded-xl bg-slate-50 border border-slate-200/80 px-4 py-3 flex items-center justify-between text-xs">
            <div className="text-slate-600">
              <span>Resolution: </span>
              <span className="font-mono tabular-nums font-semibold text-slate-900">
                {rendering ? 'Preparing...' : `${meta.width} × ${meta.height} px`}
              </span>
            </div>
            <div className="font-mono tabular-nums text-slate-600">
              {rendering ? '...' : formatBytes(meta.size)}
            </div>
          </div>

          {statusNote && (
            <div className="flex items-center gap-2 text-xs font-medium text-blue-800 bg-blue-50 rounded-xl px-3.5 py-2.5">
              <Check className="w-4 h-4 text-blue-600 shrink-0" />
              <span>{statusNote}</span>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              disabled={rendering || !meta.blob}
              onClick={handleShare}
              className="inline-flex items-center justify-center gap-2 min-h-[48px] px-4 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm font-semibold hover:bg-slate-50 disabled:opacity-50 transition cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-blue-600" />
              <span>Share</span>
            </button>

            <button
              type="button"
              disabled={rendering || !meta.blob}
              onClick={handleDownload}
              className="inline-flex items-center justify-center gap-2 min-h-[48px] px-4 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 active:scale-[0.98] transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Save Photo</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
