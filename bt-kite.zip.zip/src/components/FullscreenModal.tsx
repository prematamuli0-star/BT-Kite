import React, { useEffect, useState } from 'react';
import { Columns2, X } from 'lucide-react';

interface FullscreenModalProps {
  open: boolean;
  originalUrl: string;
  editedUrl: string;
  hasTransparency: boolean;
  onClose: () => void;
}

export const FullscreenModal: React.FC<FullscreenModalProps> = ({
  open,
  originalUrl,
  editedUrl,
  hasTransparency,
  onClose,
}) => {
  const [compare, setCompare] = useState(false);
  const [splitPct, setSplitPct] = useState(50);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col">
      <div className="h-14 px-4 flex items-center justify-between border-b border-white/10">
        <span className="text-sm font-semibold text-white">Fullscreen Preview</span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCompare((v) => !v)}
            className={`inline-flex items-center gap-2 min-h-[40px] px-3.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              compare
                ? 'bg-blue-600 text-white'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <Columns2 className="w-4 h-4" />
            <span>Before / After</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Exit fullscreen preview"
            className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl text-white hover:bg-white/10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-4 sm:p-8 overflow-hidden">
        <div
          className={`relative max-w-full max-h-full select-none overflow-hidden rounded-2xl ${
            hasTransparency ? 'checkerboard-bg' : ''
          }`}
        >
          <img
            src={editedUrl}
            alt="Edited full-resolution preview"
            referrerPolicy="no-referrer"
            className="block max-h-[82vh] max-w-[92vw] object-contain"
          />
          {compare && (
            <>
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ clipPath: `inset(0 ${100 - splitPct}% 0 0)` }}
              >
                <img
                  src={originalUrl}
                  alt="Original photo preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              </div>
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg pointer-events-none"
                style={{ left: `${splitPct}%` }}
              />
              <input
                type="range"
                min={0}
                max={100}
                value={splitPct}
                onChange={(e) => setSplitPct(Number(e.target.value))}
                aria-label="Before and after comparison position"
                className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
              />
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-slate-950/75 text-white text-xs font-medium pointer-events-none">
                Before
              </span>
              <span className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-blue-600/90 text-white text-xs font-medium pointer-events-none">
                After
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
