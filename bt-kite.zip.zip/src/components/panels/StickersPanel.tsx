import React from 'react';
import { Trash2 } from 'lucide-react';
import { STICKER_PRESETS } from '../../data/presets';
import { StickerLayer } from '../../types/editor';

interface StickersPanelProps {
  layers: StickerLayer[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onAdd: (stickerId: string) => void;
  onUpdate: (id: string, patch: Partial<StickerLayer>, commit?: boolean) => void;
  onDelete: (id: string) => void;
}

export const StickersPanel: React.FC<StickersPanelProps> = ({
  layers,
  selectedId,
  onSelect,
  onAdd,
  onUpdate,
  onDelete,
}) => {
  const active = layers.find((l) => l.id === selectedId) || layers[layers.length - 1] || null;

  return (
    <div className="space-y-4">
      <div>
        <div className="text-xs font-bold text-slate-900 mb-2">Studio Stickers & Stamps</div>
        <div className="grid grid-cols-4 gap-2">
          {STICKER_PRESETS.map((st) => (
            <button
              key={st.id}
              type="button"
              onClick={() => onAdd(st.id)}
              title={`Add ${st.name}`}
              className="aspect-square rounded-xl border border-slate-200 bg-slate-50 hover:border-blue-400 hover:bg-blue-50/50 p-2 flex items-center justify-center transition active:scale-95 cursor-pointer"
            >
              <img
                src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(st.svg)}`}
                alt={st.name}
                className="w-full h-full object-contain"
              />
            </button>
          ))}
        </div>
      </div>

      {layers.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {layers.map((layer, idx) => (
            <button
              key={layer.id}
              type="button"
              onClick={() => onSelect(layer.id)}
              className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 border cursor-pointer ${
                active?.id === layer.id
                  ? 'border-blue-600 bg-blue-50 text-blue-900'
                  : 'border-slate-200 bg-white text-slate-600'
              }`}
            >
              Sticker {idx + 1}
            </button>
          ))}
        </div>
      )}

      {active && (
        <div className="space-y-3 rounded-2xl bg-slate-50 border border-slate-200 p-3.5">
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-semibold text-slate-700">Scale</span>
              <span className="font-mono tabular-nums text-blue-600 font-medium">
                {Math.round(active.scale * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={40}
              max={200}
              value={Math.round(active.scale * 100)}
              onChange={(e) => onUpdate(active.id, { scale: Number(e.target.value) / 100 }, false)}
              onMouseUp={(e) =>
                onUpdate(active.id, { scale: Number(e.currentTarget.value) / 100 }, true)
              }
              onTouchEnd={(e) =>
                onUpdate(active.id, { scale: Number(e.currentTarget.value) / 100 }, true)
              }
              className="w-full studio-slider"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-semibold text-slate-700">Rotation</span>
              <span className="font-mono tabular-nums text-blue-600 font-medium">
                {active.rotation}°
              </span>
            </div>
            <input
              type="range"
              min={-180}
              max={180}
              value={active.rotation}
              onChange={(e) => onUpdate(active.id, { rotation: Number(e.target.value) }, false)}
              onMouseUp={(e) => onUpdate(active.id, { rotation: Number(e.currentTarget.value) }, true)}
              onTouchEnd={(e) => onUpdate(active.id, { rotation: Number(e.currentTarget.value) }, true)}
              className="w-full studio-slider"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-500">Drag sticker directly on the photo</span>
            <button
              type="button"
              onClick={() => onDelete(active.id)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 hover:text-red-700 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Remove</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
