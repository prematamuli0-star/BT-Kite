import React, { useRef, useState } from 'react';
import {
  Check,
  Compass,
  Image as ImageIcon,
  KeyRound,
  RefreshCw,
  RotateCcw,
  ScanEye,
  Scissors,
  Sparkles,
  Sun,
  Upload,
  Wand2,
} from 'lucide-react';
import { BACKGROUND_PRESETS, PASSPORT_COLORS } from '../../data/presets';
import {
  AIStatus,
  BackgroundBlendSettings,
  BackgroundCategoryId,
  BackgroundState,
  LightingDirection,
  PhotoAnalysisResult,
} from '../../types/editor';

interface BackgroundPanelProps {
  background: BackgroundState;
  hasCutout: boolean;
  aiStatus: AIStatus;
  analysis: PhotoAnalysisResult | null;
  analyzingScene: boolean;
  onAnalyzePhoto: () => void;
  onAutoBackground: () => void;
  onRemoveToTransparent: () => void;
  onRestoreOriginalBg: () => void;
  onSelectCategory: (categoryId: BackgroundCategoryId) => void;
  onSelectPassportColor: (hex: string) => void;
  onUploadCustomBackdrop: (file: File) => void;
  onApplyPromptSmartMatch: (prompt: string) => void;
  onApplyPromptPaidGenerative: (prompt: string) => void;
  onUpdateBlend: <K extends keyof BackgroundBlendSettings>(
    key: K,
    value: BackgroundBlendSettings[K],
    commit?: boolean
  ) => void;
}

const LIGHT_DIRECTIONS: Array<{ id: LightingDirection; label: string }> = [
  { id: 'top-left', label: 'Top Left' },
  { id: 'top-right', label: 'Top Right' },
  { id: 'left', label: 'Left' },
  { id: 'right', label: 'Right' },
  { id: 'front-diffused', label: 'Diffused' },
  { id: 'backlit', label: 'Backlit' },
];

function formatLabel(value: string): string {
  return value
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, (m) => m.toUpperCase());
}

export const BackgroundPanel: React.FC<BackgroundPanelProps> = ({
  background,
  hasCutout,
  aiStatus,
  analysis,
  analyzingScene,
  onAnalyzePhoto,
  onAutoBackground,
  onRemoveToTransparent,
  onRestoreOriginalBg,
  onSelectCategory,
  onSelectPassportColor,
  onUploadCustomBackdrop,
  onApplyPromptSmartMatch,
  onApplyPromptPaidGenerative,
  onUpdateBlend,
}) => {
  const customInputRef = useRef<HTMLInputElement | null>(null);
  const [promptText, setPromptText] = useState(
    'Replace the background with a premium photography studio. Use soft lighting, realistic shadows, and a professional portrait photography style.'
  );

  const isReplaced =
    hasCutout && background.categoryId !== 'original' && background.categoryId !== 'transparent';

  const topPresetName = analysis
    ? BACKGROUND_PRESETS.find((p) => p.id === analysis.recommendedBackgroundId)?.name ||
      'Professional Studio'
    : null;

  return (
    <div className="space-y-4">
      {/* Primary One-Tap Auto Background Action */}
      <div className="space-y-2">
        <button
          type="button"
          onClick={onAutoBackground}
          className="w-full min-h-[50px] px-4 py-3 rounded-2xl bg-blue-600 text-white hover:bg-blue-700 active:scale-[0.99] transition shadow-sm shadow-blue-600/20 flex items-center justify-center gap-2 text-sm font-bold cursor-pointer"
        >
          <Wand2 className="w-4 h-4" />
          <span>Auto Background</span>
        </button>

        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={onRemoveToTransparent}
            className={`min-h-[42px] px-2.5 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              background.categoryId === 'transparent'
                ? 'border-blue-600 bg-blue-50 text-blue-900'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Scissors className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="truncate">Transparent</span>
          </button>

          <button
            type="button"
            onClick={() => customInputRef.current?.click()}
            className="min-h-[42px] px-2.5 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="truncate">My Photo</span>
          </button>

          <button
            type="button"
            disabled={background.categoryId === 'original'}
            onClick={onRestoreOriginalBg}
            className="min-h-[42px] px-2.5 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Original</span>
          </button>
        </div>

        <input
          ref={customInputRef}
          type="file"
          accept="image/*"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onUploadCustomBackdrop(f);
            e.target.value = '';
          }}
          className="hidden"
        />
      </div>

      {/* Intelligent Photo Analysis Preview Card */}
      <div className="rounded-2xl bg-slate-50 border border-slate-200/90 p-3.5 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <ScanEye className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="text-xs font-bold text-slate-900">Photo Analysis</span>
          </div>
          <button
            type="button"
            disabled={analyzingScene}
            onClick={onAnalyzePhoto}
            className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:text-blue-700 disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw className={`w-3 h-3 ${analyzingScene ? 'animate-spin' : ''}`} />
            <span>{analyzingScene ? 'Analyzing...' : 'Refresh'}</span>
          </button>
        </div>

        {analyzingScene && !analysis ? (
          <p className="text-xs text-slate-500 leading-relaxed">
            Detecting subject pose, camera perspective, lighting direction, and compatible scenes...
          </p>
        ) : analysis ? (
          <div className="space-y-1.5 text-xs">
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-slate-500 shrink-0">Subject</span>
              <span className="font-semibold text-slate-900 text-right">
                {analysis.subjectDescription} · {analysis.poseDetail}
              </span>
            </div>
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-slate-500 shrink-0">Position</span>
              <span className="font-medium text-slate-800 text-right">
                {formatLabel(analysis.subjectPosition)} · {formatLabel(analysis.cameraDistance)} ·{' '}
                {formatLabel(analysis.cameraAngle)}
              </span>
            </div>
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-slate-500 shrink-0">Lighting</span>
              <span className="font-medium text-slate-800 text-right">
                {formatLabel(analysis.lightingDirection)} · {analysis.lightingType}
              </span>
            </div>
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-slate-500 shrink-0">Photo Style</span>
              <span className="font-medium text-slate-800 text-right">
                {analysis.photoCategory}
              </span>
            </div>
            <div className="pt-1.5 mt-1.5 border-t border-slate-200/80 flex items-baseline justify-between gap-3">
              <span className="text-slate-500 shrink-0">Top Match</span>
              <span className="font-bold text-blue-700 text-right">{topPresetName}</span>
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-500">
            Tap Refresh or Auto Background to analyze pose, lighting, and perspective.
          </p>
        )}
      </div>

      {/* Top 5 AI-Recommended Backgrounds */}
      {analysis && analysis.recommendedBackgrounds.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">Recommended for This Photo</span>
            <span className="text-[11px] text-slate-500">Top 5 pose & perspective matches</span>
          </div>

          <div className="space-y-1.5">
            {analysis.recommendedBackgrounds.map((rec, idx) => {
              const preset = BACKGROUND_PRESETS.find((p) => p.id === rec.id);
              if (!preset) return null;
              const active = background.categoryId === preset.id;
              return (
                <button
                  key={rec.id}
                  type="button"
                  onClick={() => onSelectCategory(preset.id)}
                  className={`w-full p-2 rounded-xl border text-left flex items-center gap-2.5 transition cursor-pointer ${
                    active
                      ? 'border-blue-600 bg-blue-50/60 ring-1 ring-blue-600/20'
                      : 'border-slate-200 bg-white hover:border-blue-300 hover:bg-slate-50/70'
                  }`}
                >
                  <div
                    className="w-12 h-10 rounded-lg overflow-hidden shrink-0 relative border border-slate-200/60"
                    style={{
                      background: `linear-gradient(135deg, ${preset.gradientStops[0]}, ${preset.gradientStops[1]}, ${preset.gradientStops[2]})`,
                    }}
                  >
                    {preset.imageUrl && (
                      <img
                        src={preset.imageUrl}
                        alt={preset.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-900 truncate">
                        {idx + 1}. {preset.name}
                      </span>
                      <span className="text-[11px] font-mono tabular-nums font-semibold text-blue-600 shrink-0">
                        {rec.matchScore}%
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">{rec.reason}</p>
                  </div>
                  {active && (
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {background.categoryId === 'passport-id' && (
        <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3">
          <div className="text-xs font-bold text-slate-900 mb-2">Passport / ID Studio Color</div>
          <div className="flex items-center gap-2.5">
            {PASSPORT_COLORS.map((c) => (
              <button
                key={c.hex}
                type="button"
                onClick={() => onSelectPassportColor(c.hex)}
                title={c.name}
                aria-label={c.name}
                className={`w-9 h-9 rounded-xl border-2 flex items-center justify-center transition cursor-pointer ${
                  background.passportColor === c.hex
                    ? 'border-blue-600 scale-105'
                    : 'border-slate-300'
                }`}
                style={{ backgroundColor: c.hex }}
              >
                {background.passportColor === c.hex && (
                  <Check
                    className={`w-4 h-4 ${c.hex === '#2563EB' ? 'text-white' : 'text-blue-600'}`}
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Professional Perspective, Lighting & Blending Controls */}
      {isReplaced && (
        <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-3.5 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-900">Perspective & Blending</span>
            <span className="text-[11px] text-slate-500 flex items-center gap-1">
              <Compass className="w-3 h-3 text-blue-600" />
              Position preserved
            </span>
          </div>

          {(
            [
              {
                key: 'horizonShift',
                label: 'Perspective & Horizon Align',
                min: -35,
                max: 35,
                suffix: '%',
                signed: true,
              },
              {
                key: 'lightMatch',
                label: 'Lighting Match',
                min: 0,
                max: 100,
                suffix: '%',
                signed: false,
              },
              {
                key: 'colorMatch',
                label: 'Color Temperature Match',
                min: 0,
                max: 100,
                suffix: '%',
                signed: false,
              },
              {
                key: 'shadowDepth',
                label: 'Contact & Ground Shadow',
                min: 0,
                max: 100,
                suffix: '%',
                signed: false,
              },
              {
                key: 'backgroundBlur',
                label: 'Depth-of-Field Blur',
                min: 0,
                max: 100,
                suffix: '%',
                signed: false,
              },
              {
                key: 'edgeRefine',
                label: 'Hair & Edge Light Wrap',
                min: 0,
                max: 100,
                suffix: '%',
                signed: false,
              },
              {
                key: 'subjectScale',
                label: 'Subject Scale (100% = Original)',
                min: 75,
                max: 125,
                suffix: '%',
                signed: false,
              },
            ] as const
          ).map((ctrl) => {
            const val = background.blend[ctrl.key];
            const displayVal = ctrl.signed && val > 0 ? `+${val}` : `${val}`;
            return (
              <div key={ctrl.key}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-600 font-medium">{ctrl.label}</span>
                  <span className="font-mono tabular-nums text-blue-600 font-medium">
                    {displayVal}
                    {ctrl.suffix}
                  </span>
                </div>
                <input
                  type="range"
                  min={ctrl.min}
                  max={ctrl.max}
                  value={val}
                  onChange={(e) => onUpdateBlend(ctrl.key, Number(e.target.value), false)}
                  onMouseUp={(e) => onUpdateBlend(ctrl.key, Number(e.currentTarget.value), true)}
                  onTouchEnd={(e) => onUpdateBlend(ctrl.key, Number(e.currentTarget.value), true)}
                  className="w-full studio-slider"
                />
              </div>
            );
          })}

          <div className="pt-1.5 border-t border-slate-200/80 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
              <Sun className="w-3.5 h-3.5 text-blue-600" />
              <span>Key Light Direction</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {LIGHT_DIRECTIONS.map((dir) => {
                const active = background.blend.lightingDirection === dir.id;
                return (
                  <button
                    key={dir.id}
                    type="button"
                    onClick={() => onUpdateBlend('lightingDirection', dir.id, true)}
                    className={`min-h-[34px] px-2 rounded-lg border text-[11px] font-semibold transition cursor-pointer ${
                      active
                        ? 'border-blue-600 bg-blue-600 text-white'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-blue-300'
                    }`}
                  >
                    {dir.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Full Curated Background Library */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-900">All Studio Background Styles</span>
          <span className="text-[11px] text-slate-500">
            {BACKGROUND_PRESETS.length} curated + custom
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {BACKGROUND_PRESETS.map((preset) => {
            const active = background.categoryId === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onSelectCategory(preset.id)}
                className={`group rounded-xl border overflow-hidden text-left transition cursor-pointer ${
                  active
                    ? 'border-blue-600 ring-2 ring-blue-600/20'
                    : 'border-slate-200 hover:border-blue-300'
                }`}
              >
                <div
                  className="h-16 w-full relative overflow-hidden"
                  style={{
                    background: `linear-gradient(135deg, ${preset.gradientStops[0]}, ${preset.gradientStops[1]}, ${preset.gradientStops[2]})`,
                  }}
                >
                  {preset.imageUrl && (
                    <img
                      src={preset.imageUrl}
                      alt={preset.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  )}
                  {active && (
                    <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow">
                      <Check className="w-3 h-3" />
                    </span>
                  )}
                </div>
                <div className="px-2.5 py-2 bg-white">
                  <div className="text-xs font-semibold text-slate-900 truncate">{preset.name}</div>
                  <div className="text-[11px] text-slate-500 truncate">{preset.shortDesc}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom AI Background Prompt */}
      <div className="rounded-2xl bg-slate-50 border border-slate-200 p-3.5 space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-900">Custom AI Background Prompt</span>
          <ImageIcon className="w-3.5 h-3.5 text-blue-600 shrink-0" />
        </div>
        <textarea
          rows={3}
          value={promptText}
          onChange={(e) => setPromptText(e.target.value)}
          placeholder="Describe your ideal studio or location background..."
          className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 resize-none"
        />

        <div className="grid grid-cols-1 gap-2">
          <button
            type="button"
            disabled={!promptText.trim()}
            onClick={() => onApplyPromptSmartMatch(promptText)}
            className="w-full min-h-[42px] px-3.5 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 disabled:opacity-40 flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Match Studio Backdrop (Free)</span>
          </button>

          <button
            type="button"
            disabled={!promptText.trim()}
            onClick={() => onApplyPromptPaidGenerative(promptText)}
            className={`w-full min-h-[42px] px-3.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              aiStatus.paidGenerativeImageAvailable
                ? 'border-blue-300 bg-blue-50 text-blue-900 hover:bg-blue-100'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-100'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5 shrink-0" />
            <span>
              {aiStatus.paidGenerativeImageAvailable
                ? 'Generate Custom Scene (Gemini HD)'
                : 'Generative Scene Synthesis (Paid API Key)'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
