import React from 'react';
import { Check, FlipHorizontal2, FlipVertical2, RotateCcw, RotateCw } from 'lucide-react';
import { TransformState } from '../../types/editor';

export type AspectPresetId = 'free' | '1:1' | '4:5' | '3:4' | '4:3' | '16:9' | '9:16' | 'passport';

const ASPECT_PRESETS: Array<{ id: AspectPresetId; label: string; ratio: number | null }> = [
  { id: 'free', label: 'Free', ratio: null },
  { id: '1:1', label: '1:1', ratio: 1 },
  { id: '4:5', label: '4:5', ratio: 4 / 5 },
  { id: '3:4', label: '3:4', ratio: 3 / 4 },
  { id: '4:3', label: '4:3', ratio: 4 / 3 },
  { id: '16:9', label: '16:9', ratio: 16 / 9 },
  { id: '9:16', label: '9:16', ratio: 9 / 16 },
  { id: 'passport', label: 'ID 35×45', ratio: 35 / 45 },
];

interface CropPanelProps {
  transform: TransformState;
  selectedAspect: AspectPresetId;
  cropDirty: boolean;
  onSelectAspect: (id: AspectPresetId, ratio: number | null) => void;
  onRotate: (delta: number) => void;
  onFlipH: () => void;
  onFlipV: () => void;
  onApplyCrop: () => void;
  onResetCrop: () => void;
}

export const CropPanel: React.FC<CropPanelProps> = ({
  transform,
  selectedAspect,
  cropDirty,
  onSelectAspect,
  onRotate,
  onFlipH,
  onFlipV,
  onApplyCrop,
  onResetCrop,
}) => {
  return (
    <div className="space-y-4">
      <div>
        <div className="text-xs font-bold text-slate-900 mb-2">Rotate & Flip</div>
        <div className="grid grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => onRotate(-90)}
            className="min-h-[46px] rounded-xl border border-slate-200 bg-white hover:bg-slate-50 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold text-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-blue-600" />
            <span>-90°</span>
          </button>
          <button
            type="button"
            onClick={() => onRotate(90)}
            className="min-h-[46px] rounded-xl border border-slate-200 bg-white hover:bg-slate-50 flex flex-col items-center justify-center gap-1 text-[11px] font-semibold text-slate-700 cursor-pointer"
          >
            <RotateCw className="w-4 h-4 text-blue-600" />
            <span>+90°</span>
          </button>
          <button
            type="button"
            onClick={onFlipH}
            className={`min-h-[46px] rounded-xl border flex flex-col items-center justify-center gap-1 text-[11px] font-semibold cursor-pointer ${
              transform.flipH
                ? 'border-blue-600 bg-blue-50 text-blue-900'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            <FlipHorizontal2 className="w-4 h-4 text-blue-600" />
            <span>Flip H</span>
          </button>
          <button
            type="button"
            onClick={onFlipV}
            className={`min-h-[46px] rounded-xl border flex flex-col items-center justify-center gap-1 text-[11px] font-semibold cursor-pointer ${
              transform.flipV
                ? 'border-blue-600 bg-blue-50 text-blue-900'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            <FlipVertical2 className="w-4 h-4 text-blue-600" />
            <span>Flip V</span>
          </button>
        </div>
      </div>

      <div>
        <div className="text-xs font-bold text-slate-900 mb-2">Crop Aspect Ratio</div>
        <div className="grid grid-cols-4 gap-2">
          {ASPECT_PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => onSelectAspect(preset.id, preset.ratio)}
              className={`min-h-[40px] px-2 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                selectedAspect === preset.id
                  ? 'border-blue-600 bg-blue-50 text-blue-900'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      <p className="text-xs text-slate-500">
        Drag the corner handles directly on the photo preview to reframe your crop area.
      </p>

      <div className="grid grid-cols-2 gap-2.5 pt-1">
        <button
          type="button"
          onClick={onResetCrop}
          className="min-h-[44px] rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
        >
          Reset Frame
        </button>
        <button
          type="button"
          disabled={!cropDirty}
          onClick={onApplyCrop}
          className="inline-flex items-center justify-center gap-1.5 min-h-[44px] rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 disabled:opacity-40 cursor-pointer"
        >
          <Check className="w-4 h-4" />
          <span>Apply Crop</span>
        </button>
      </div>
    </div>
  );
};
