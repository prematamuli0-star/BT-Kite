import React from 'react';
import { AlignCenter, AlignLeft, AlignRight, Plus, Trash2 } from 'lucide-react';
import { TextLayer } from '../../types/editor';

const TEXT_COLORS = ['#FFFFFF', '#0F172A', '#2563EB', '#F59E0B', '#EF4444', '#10B981'];
const FONTS: Array<TextLayer['fontFamily']> = [
  'Plus Jakarta Sans',
  'DM Sans',
  'Georgia',
  'JetBrains Mono',
];

interface TextPanelProps {
  layers: TextLayer[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onAdd: () => void;
  onUpdate: (id: string, patch: Partial<TextLayer>, commit?: boolean) => void;
  onDelete: (id: string) => void;
}

export const TextPanel: React.FC<TextPanelProps> = ({
  layers,
  selectedId,
  onSelect,
  onAdd,
  onUpdate,
  onDelete,
}) => {
  const active = layers.find((l) => l.id === selectedId) || layers[layers.length - 1] || null;

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={onAdd}
        className="w-full min-h-[46px] px-4 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
      >
        <Plus className="w-4 h-4" />
        <span>Add Text Overlay</span>
      </button>

      {layers.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {layers.map((layer, idx) => (
            <button
              key={layer.id}
              type="button"
              onClick={() => onSelect(layer.id)}
              className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 border cursor-pointer ${
                active?.id === layer.id
                  ? 'border-blue-600 bg-blue-50 text-blue-900'
                  : 'border-slate-200 bg-white text-slate-600'
              }`}
            >
              {layer.text.trim().slice(0, 14) || `Text ${idx + 1}`}
            </button>
          ))}
        </div>
      )}

      {active ? (
        <div className="space-y-3.5 rounded-2xl bg-slate-50 border border-slate-200 p-3.5">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1.5">
              Text Content
            </label>
            <textarea
              rows={2}
              value={active.text}
              onChange={(e) => onUpdate(active.id, { text: e.target.value }, true)}
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-blue-500 resize-none"
            />
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-semibold text-slate-700">Size</span>
              <span className="font-mono tabular-nums text-blue-600 font-medium">
                {active.fontSize}px
              </span>
            </div>
            <input
              type="range"
              min={14}
              max={68}
              value={active.fontSize}
              onChange={(e) => onUpdate(active.id, { fontSize: Number(e.target.value) }, false)}
              onMouseUp={(e) => onUpdate(active.id, { fontSize: Number(e.currentTarget.value) }, true)}
              onTouchEnd={(e) => onUpdate(active.id, { fontSize: Number(e.currentTarget.value) }, true)}
              className="w-full studio-slider"
            />
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-700 block mb-1.5">Font</span>
            <div className="grid grid-cols-2 gap-1.5">
              {FONTS.map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => onUpdate(active.id, { fontFamily: f }, true)}
                  style={{ fontFamily: f }}
                  className={`min-h-[36px] px-2.5 rounded-lg border text-xs font-medium truncate cursor-pointer ${
                    active.fontFamily === f
                      ? 'border-blue-600 bg-blue-50 text-blue-900'
                      : 'border-slate-200 bg-white text-slate-700'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-3">
            <div>
              <span className="text-xs font-semibold text-slate-700 block mb-1.5">Color</span>
              <div className="flex items-center gap-1.5">
                {TEXT_COLORS.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    aria-label={`Text color ${hex}`}
                    onClick={() => onUpdate(active.id, { color: hex }, true)}
                    className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                      active.color === hex ? 'border-blue-600 scale-110' : 'border-slate-300'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-700 block mb-1.5">Align</span>
              <div className="flex items-center gap-1">
                {(
                  [
                    { id: 'left', icon: AlignLeft },
                    { id: 'center', icon: AlignCenter },
                    { id: 'right', icon: AlignRight },
                  ] as const
                ).map(({ id, icon: Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => onUpdate(active.id, { align: id }, true)}
                    aria-label={`Align ${id}`}
                    className={`w-8 h-8 rounded-lg border flex items-center justify-center cursor-pointer ${
                      active.align === id
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-slate-200 bg-white text-slate-600'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-700 block mb-1.5">Backdrop</span>
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  { id: 'none', label: 'None' },
                  { id: 'solid', label: 'Dark Box' },
                  { id: 'glass', label: 'Light Box' },
                ] as const
              ).map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => onUpdate(active.id, { bgStyle: b.id }, true)}
                  className={`min-h-[34px] rounded-lg border text-xs font-semibold cursor-pointer ${
                    active.bgStyle === b.id
                      ? 'border-blue-600 bg-blue-50 text-blue-900'
                      : 'border-slate-200 bg-white text-slate-700'
                  }`}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-500">Drag text directly on the photo</span>
            <button
              type="button"
              onClick={() => onDelete(active.id)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-red-600 hover:text-red-700 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete</span>
            </button>
          </div>
        </div>
      ) : (
        <p className="text-xs text-slate-500 text-center py-4">
          Tap Add Text Overlay to place titles, captions, or studio credits directly on your photo.
        </p>
      )}
    </div>
  );
};
