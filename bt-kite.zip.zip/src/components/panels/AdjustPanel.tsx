import React, { useState } from 'react';
import { Palette, RotateCcw } from 'lucide-react';
import { ADJUSTMENT_CONTROLS } from '../../data/presets';
import { ColorAdjustments, DEFAULT_ADJUSTMENTS } from '../../types/editor';

interface AdjustPanelProps {
  adjustments: ColorAdjustments;
  onChange: (key: keyof ColorAdjustments, value: number, commit?: boolean) => void;
  onResetAll: () => void;
  onAIColorTune: () => void;
}

export const AdjustPanel: React.FC<AdjustPanelProps> = ({
  adjustments,
  onChange,
  onResetAll,
  onAIColorTune,
}) => {
  const [group, setGroup] = useState<'All' | 'Light' | 'Color' | 'Detail'>('All');

  const controls =
    group === 'All'
      ? ADJUSTMENT_CONTROLS
      : ADJUSTMENT_CONTROLS.filter((c) => c.group === group);

  const hasChanges = (Object.keys(DEFAULT_ADJUSTMENTS) as Array<keyof ColorAdjustments>).some(
    (k) => adjustments[k] !== 0
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onAIColorTune}
          className="flex-1 min-h-[46px] px-3.5 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <Palette className="w-4 h-4" />
          <span>AI Color Tune</span>
        </button>

        <button
          type="button"
          disabled={!hasChanges}
          onClick={onResetAll}
          className="min-h-[46px] px-3.5 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 disabled:opacity-40 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100">
        {(['All', 'Light', 'Color', 'Detail'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setGroup(tab)}
            className={`min-h-[34px] rounded-lg text-xs font-semibold transition cursor-pointer ${
              group === tab
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="space-y-3.5">
        {controls.map((ctrl) => {
          const val = adjustments[ctrl.key];
          return (
            <div key={ctrl.key}>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <button
                  type="button"
                  onDoubleClick={() => onChange(ctrl.key, 0, true)}
                  title="Double-click to reset slider"
                  className="font-medium text-slate-700 hover:text-blue-600 cursor-pointer"
                >
                  {ctrl.label}
                </button>
                <span
                  className={`font-mono tabular-nums font-medium ${
                    val !== 0 ? 'text-blue-600' : 'text-slate-400'
                  }`}
                >
                  {val > 0 ? `+${val}` : val}
                </span>
              </div>
              <input
                type="range"
                min={ctrl.min}
                max={ctrl.max}
                value={val}
                onChange={(e) => onChange(ctrl.key, Number(e.target.value), false)}
                onMouseUp={(e) => onChange(ctrl.key, Number(e.currentTarget.value), true)}
                onTouchEnd={(e) => onChange(ctrl.key, Number(e.currentTarget.value), true)}
                className="w-full studio-slider"
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
