import React from 'react';
import { Check } from 'lucide-react';
import { COLOR_STYLE_PRESETS } from '../../data/presets';
import { ColorStyleId } from '../../types/editor';

interface FiltersPanelProps {
  styleId: ColorStyleId;
  intensity: number;
  onSelectStyle: (id: ColorStyleId) => void;
  onChangeIntensity: (value: number, commit?: boolean) => void;
}

export const FiltersPanel: React.FC<FiltersPanelProps> = ({
  styleId,
  intensity,
  onSelectStyle,
  onChangeIntensity,
}) => {
  return (
    <div className="space-y-4">
      {styleId !== 'none' && (
        <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-3.5">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-slate-700">Style Strength</span>
            <span className="font-mono tabular-nums font-medium text-blue-600">{intensity}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={intensity}
            onChange={(e) => onChangeIntensity(Number(e.target.value), false)}
            onMouseUp={(e) => onChangeIntensity(Number(e.currentTarget.value), true)}
            onTouchEnd={(e) => onChangeIntensity(Number(e.currentTarget.value), true)}
            className="w-full studio-slider"
          />
        </div>
      )}

      <div className="grid grid-cols-2 gap-2">
        {COLOR_STYLE_PRESETS.map((preset) => {
          const active = styleId === preset.id;
          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => onSelectStyle(preset.id)}
              className={`rounded-xl border p-2.5 text-left transition flex items-center gap-2.5 cursor-pointer ${
                active
                  ? 'border-blue-600 bg-blue-50/70'
                  : 'border-slate-200 bg-white hover:border-blue-300'
              }`}
            >
              <div
                className="w-9 h-9 rounded-lg shrink-0 flex items-center justify-center border border-slate-200/70"
                style={{
                  background: `linear-gradient(135deg, ${preset.swatch[0]}, ${preset.swatch[1]})`,
                }}
              >
                {active && <Check className="w-4 h-4 text-white drop-shadow" />}
              </div>
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate">{preset.name}</div>
                <div className="text-[11px] text-slate-500 truncate">{preset.tagline}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
