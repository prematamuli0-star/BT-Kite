import React from 'react';
import {
  Check,
  Eraser,
  ImagePlus,
  KeyRound,
  Palette,
  RotateCcw,
  Sparkles,
  UserCheck,
  Wand2,
} from 'lucide-react';
import { AIStatus, PhotoAnalysisResult } from '../../types/editor';

interface AIPanelProps {
  aiStatus: AIStatus;
  qualityMode: 'fast' | 'studio_hd';
  onChangeQualityMode: (mode: 'fast' | 'studio_hd') => void;
  analysis: PhotoAnalysisResult | null;
  brushActive: boolean;
  brushSize: number;
  hasBrushStrokes: boolean;
  onAutoBackground: () => void;
  onAIColorTune: () => void;
  onAIEnhance: () => void;
  onPortraitEnhance: () => void;
  onOpenBackgroundGenerator: () => void;
  onToggleBrushMode: (active: boolean) => void;
  onBrushSizeChange: (size: number) => void;
  onClearBrush: () => void;
  onApplyObjectRemoval: () => void;
}

export const AIPanel: React.FC<AIPanelProps> = ({
  aiStatus,
  qualityMode,
  onChangeQualityMode,
  analysis,
  brushActive,
  brushSize,
  hasBrushStrokes,
  onAutoBackground,
  onAIColorTune,
  onAIEnhance,
  onPortraitEnhance,
  onOpenBackgroundGenerator,
  onToggleBrushMode,
  onBrushSizeChange,
  onClearBrush,
  onApplyObjectRemoval,
}) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-2.5">
        <button
          type="button"
          onClick={onAutoBackground}
          className="w-full min-h-[56px] px-4 py-3.5 rounded-2xl bg-blue-600 text-white hover:bg-blue-700 active:scale-[0.99] transition shadow-sm shadow-blue-600/20 flex items-center justify-between gap-3 cursor-pointer text-left"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <Wand2 className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold leading-tight">Auto Background</div>
              <div className="text-xs text-blue-100 truncate mt-0.5">
                One-tap subject cutout, best backdrop & lighting match
              </div>
            </div>
          </div>
          <span className="text-xs font-semibold text-blue-100 whitespace-nowrap shrink-0">
            1-Tap
          </span>
        </button>

        <button
          type="button"
          onClick={onAIColorTune}
          className="w-full min-h-[54px] px-4 py-3 rounded-2xl bg-blue-50 text-blue-950 border border-blue-200 hover:bg-blue-100/80 active:scale-[0.99] transition flex items-center justify-between gap-3 cursor-pointer text-left"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Palette className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold leading-tight">AI Color Tune</div>
              <div className="text-xs text-blue-800/80 truncate mt-0.5">
                Analyze scene & auto-set all 16 live color sliders
              </div>
            </div>
          </div>
          <span className="text-xs font-semibold text-blue-700 whitespace-nowrap shrink-0">
            Auto
          </span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={onAIEnhance}
          className="min-h-[68px] p-3 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 hover:bg-slate-50 active:scale-[0.98] transition text-left flex flex-col justify-between cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-blue-600" />
          <div className="mt-2">
            <div className="text-xs font-bold text-slate-900">AI Enhance</div>
            <div className="text-[11px] text-slate-500">Clarity, light & denoise</div>
          </div>
        </button>

        <button
          type="button"
          onClick={onPortraitEnhance}
          className="min-h-[68px] p-3 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 hover:bg-slate-50 active:scale-[0.98] transition text-left flex flex-col justify-between cursor-pointer"
        >
          <UserCheck className="w-4 h-4 text-blue-600" />
          <div className="mt-2">
            <div className="text-xs font-bold text-slate-900">Portrait Enhance</div>
            <div className="text-[11px] text-slate-500">Natural skin & face lift</div>
          </div>
        </button>

        <button
          type="button"
          onClick={() => onToggleBrushMode(!brushActive)}
          className={`min-h-[68px] p-3 rounded-2xl border active:scale-[0.98] transition text-left flex flex-col justify-between cursor-pointer ${
            brushActive
              ? 'bg-blue-50 border-blue-600 text-blue-950'
              : 'bg-white border-slate-200 hover:border-blue-300 hover:bg-slate-50'
          }`}
        >
          <Eraser className="w-4 h-4 text-blue-600" />
          <div className="mt-2">
            <div className="text-xs font-bold text-slate-900">Object Removal</div>
            <div className="text-[11px] text-slate-500">
              {brushActive ? 'Brush active on photo' : 'Paint to heal distractions'}
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={onOpenBackgroundGenerator}
          className="min-h-[68px] p-3 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 hover:bg-slate-50 active:scale-[0.98] transition text-left flex flex-col justify-between cursor-pointer"
        >
          <ImagePlus className="w-4 h-4 text-blue-600" />
          <div className="mt-2">
            <div className="text-xs font-bold text-slate-900">AI BG Generator</div>
            <div className="text-[11px] text-slate-500">15 styles & custom prompt</div>
          </div>
        </button>
      </div>

      {brushActive && (
        <div className="rounded-2xl bg-slate-50 border border-blue-200 p-3.5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">Object Removal Brush</span>
            <button
              type="button"
              onClick={() => onToggleBrushMode(false)}
              className="text-xs font-medium text-slate-500 hover:text-slate-800 cursor-pointer"
            >
              Done
            </button>
          </div>
          <p className="text-xs text-slate-600">
            Paint directly over blemishes, wires, or small unwanted objects on the photo, then tap
            Remove Object.
          </p>
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-slate-600 font-medium">Brush Size</span>
              <span className="font-mono tabular-nums text-blue-600 font-medium">{brushSize}px</span>
            </div>
            <input
              type="range"
              min={8}
              max={64}
              value={brushSize}
              onChange={(e) => onBrushSizeChange(Number(e.target.value))}
              className="w-full studio-slider"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              disabled={!hasBrushStrokes}
              onClick={onClearBrush}
              className="inline-flex items-center justify-center gap-1.5 min-h-[42px] px-3 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear Mask</span>
            </button>
            <button
              type="button"
              disabled={!hasBrushStrokes}
              onClick={onApplyObjectRemoval}
              className="inline-flex items-center justify-center gap-1.5 min-h-[42px] px-3 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 disabled:opacity-40 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Remove Object</span>
            </button>
          </div>
        </div>
      )}

      {analysis && (
        <div className="rounded-2xl bg-slate-50 border border-slate-200/80 p-3.5 space-y-2">
          <div className="flex items-center justify-between gap-2 text-xs">
            <span className="font-bold text-slate-900">Photo Analysis</span>
            <span className="text-slate-500">
              {analysis.photoCategory} ·{' '}
              {analysis.engine === 'gemini-vision' ? 'Gemini Vision' : 'Local Vision'}
            </span>
          </div>
          <div className="space-y-1 text-xs text-slate-700">
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-slate-500 shrink-0">Subject & Pose</span>
              <span className="font-semibold text-slate-900 text-right truncate">
                {analysis.subjectDescription} · {analysis.poseDetail}
              </span>
            </div>
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-slate-500 shrink-0">Position & Light</span>
              <span className="font-medium text-slate-800 text-right truncate">
                {analysis.subjectPosition.replace('-', ' ')} ·{' '}
                {analysis.lightingDirection.replace('-', ' ')} light
              </span>
            </div>
          </div>
          <p className="text-[11px] text-slate-600 leading-relaxed">{analysis.lightingDiagnosis}</p>
          {analysis.recommendedBackgrounds.length > 0 && (
            <button
              type="button"
              onClick={onOpenBackgroundGenerator}
              className="w-full min-h-[36px] mt-1 px-3 rounded-xl bg-white border border-slate-200 hover:border-blue-300 text-xs font-semibold text-blue-700 flex items-center justify-between transition cursor-pointer"
            >
              <span className="truncate">
                Top Match: {analysis.recommendedBackgrounds[0].name}
              </span>
              <span className="text-[11px] text-slate-500 shrink-0 ml-2">View 5 Matches</span>
            </button>
          )}
        </div>
      )}

      <div className="rounded-2xl border border-slate-200 p-3.5 space-y-2.5 bg-white">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-900">AI Quality Mode</span>
          <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => onChangeQualityMode('fast')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition cursor-pointer ${
                qualityMode === 'fast'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Fast
            </button>
            <button
              type="button"
              onClick={() => onChangeQualityMode('studio_hd')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition cursor-pointer ${
                qualityMode === 'studio_hd'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Studio HD
            </button>
          </div>
        </div>
        <div className="flex items-start gap-2 text-[11px] text-slate-500 leading-relaxed">
          <KeyRound className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
          <span>
            {aiStatus.paidGenerativeImageAvailable
              ? `Optional Paid Gemini Image API active (${
                  qualityMode === 'studio_hd' ? '2K Studio HD' : 'Fast'
                }).`
              : 'Free local Neural AI & Vision active. Paid Gemini Image API is optional and only needed for generative text-to-scene synthesis.'}
          </span>
        </div>
      </div>
    </div>
  );
};
