import React, { useRef, useState } from 'react';
import {
  Camera,
  CheckCircle2,
  KeyRound,
  Layers,
  SlidersHorizontal,
  Sparkles,
  Upload,
} from 'lucide-react';
import { SAMPLE_PHOTOS } from '../data/presets';
import { AIStatus } from '../types/editor';
import { BrandMark } from './BrandMark';
import { PWAInstallButton } from './PWAInstallButton';

interface HomeHubProps {
  aiStatus: AIStatus;
  onSelectFile: (file: File) => void;
  onOpenCamera: () => void;
  onSelectSample: (url: string, title: string) => void;
}

export const HomeHub: React.FC<HomeHubProps> = ({
  aiStatus,
  onSelectFile,
  onOpenCamera,
  onSelectSample,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onSelectFile(file);
    }
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith('image/')) {
      onSelectFile(file);
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col">
      {/* Clean 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
          <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
            <BrandMark className="w-8 h-8 shrink-0" />
            <span className="text-lg font-extrabold tracking-tight text-slate-900">BT Kite</span>
          </div>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            <a href="#samples" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Sample Studio
            </a>
            <a href="#capabilities" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              AI Tools
            </a>
            <a href="#engines" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Engine Setup
            </a>
          </nav>

          <div className="flex items-center gap-2.5 shrink-0">
            <PWAInstallButton />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 active:scale-[0.98] transition whitespace-nowrap shrink-0 cursor-pointer"
            >
              Open Photo
            </button>
          </div>
        </div>
      </header>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      <main className="flex-1">
        {/* Hero Split */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-8 pb-12 lg:pt-14 lg:pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
            {/* Left Intake & Value Column */}
            <div className="lg:col-span-7 flex flex-col justify-between">
              <div>
                <p className="text-xs font-medium text-blue-600 tracking-wide">
                  BT Media Studio · Free On-Device AI Photo Editor
                </p>
                <h1 className="mt-3 text-3xl sm:text-4xl lg:text-[2.85rem] font-extrabold tracking-tight text-slate-900 leading-[1.12] [text-wrap:balance]">
                  Turn everyday snapshots into studio photography in one tap.
                </h1>
                <p className="mt-4 text-base text-slate-600 max-w-xl leading-relaxed">
                  Automatically remove backgrounds with on-device neural AI, blend subjects into 15
                  commercial backdrops with matched lighting and shadows, and dial in expert color
                  grading across 16 live controls.
                </p>

                {/* Primary Dropzone & Action Buttons */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  className={`mt-7 rounded-2xl border-2 border-dashed p-5 sm:p-6 transition-colors ${
                    isDragging
                      ? 'border-blue-600 bg-blue-50/70'
                      : 'border-slate-200 bg-slate-50/70 hover:border-blue-300'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex-1 inline-flex items-center justify-center gap-2.5 min-h-[50px] px-5 py-3 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 active:scale-[0.98] transition shadow-sm shadow-blue-600/20 cursor-pointer whitespace-nowrap"
                    >
                      <Upload className="w-4 h-4 shrink-0" />
                      <span>Upload Photo</span>
                    </button>

                    <button
                      type="button"
                      onClick={onOpenCamera}
                      className="inline-flex items-center justify-center gap-2.5 min-h-[50px] px-5 py-3 rounded-xl bg-white text-slate-900 border border-slate-200 text-sm font-semibold hover:bg-slate-50 active:scale-[0.98] transition cursor-pointer whitespace-nowrap"
                    >
                      <Camera className="w-4 h-4 text-blue-600 shrink-0" />
                      <span>Take Photo</span>
                    </button>
                  </div>

                  <p className="mt-3 text-xs text-slate-500 text-center sm:text-left">
                    Supports JPG, PNG, and WebP · Original image is always preserved · Drag and drop
                    anywhere here
                  </p>
                </div>
              </div>

              {/* Clean unboxed workflow metadata row */}
              <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-3 gap-4">
                <div>
                  <div className="text-sm font-bold text-slate-900">15 Backdrops</div>
                  <div className="text-xs text-slate-500 mt-0.5">Studio, ID, Office & more</div>
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900">16 Live Sliders</div>
                  <div className="text-xs text-slate-500 mt-0.5">AI-set & fully editable</div>
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900">Transparent PNG</div>
                  <div className="text-xs text-slate-500 mt-0.5">Full-resolution export</div>
                </div>
              </div>
            </div>

            {/* Right Showcase Card */}
            <div className="lg:col-span-5 flex flex-col">
              <div className="relative flex-1 min-h-[300px] rounded-3xl overflow-hidden bg-slate-100 border border-slate-200/80 shadow-sm group">
                <img
                  src={SAMPLE_PHOTOS[0].url}
                  alt="BT Kite portrait transformation preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex flex-col justify-end p-6">
                  <div className="text-xs font-medium text-blue-200">
                    One-Tap Demo · Portrait Studio
                  </div>
                  <h2 className="mt-1 text-xl font-bold text-white">
                    Test Auto Background & AI Color Tune instantly
                  </h2>
                  <div className="mt-4 flex flex-wrap gap-2.5">
                    <button
                      type="button"
                      onClick={() => onSelectSample(SAMPLE_PHOTOS[0].url, SAMPLE_PHOTOS[0].title)}
                      className="inline-flex items-center gap-2 min-h-[44px] px-4 py-2 rounded-xl bg-white text-slate-900 text-sm font-semibold hover:bg-blue-50 active:scale-[0.98] transition cursor-pointer whitespace-nowrap"
                    >
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <span>Try This Portrait</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Sample Studio Photos Section */}
        <section id="samples" className="border-t border-slate-100 bg-slate-50/60 py-10 sm:py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 mb-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                  Start with a sample photo
                </h2>
                <p className="text-sm text-slate-600 mt-1">
                  Tap any test image below to launch the BT Kite editor immediately.
                </p>
              </div>
              <span className="text-xs text-slate-500">3 curated test photos</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {SAMPLE_PHOTOS.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => onSelectSample(sample.url, sample.title)}
                  className="text-left rounded-2xl bg-white border border-slate-200 overflow-hidden hover:border-blue-400 hover:shadow-md transition group cursor-pointer flex flex-col"
                >
                  <div className="aspect-[4/3] w-full bg-slate-100 overflow-hidden">
                    <img
                      src={sample.url}
                      alt={sample.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-[1.03] transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="text-xs text-blue-600 font-medium">{sample.category}</div>
                      <h3 className="mt-0.5 text-base font-bold text-slate-900">{sample.title}</h3>
                      <p className="mt-1 text-xs text-slate-500">{sample.subtitle}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Core Capabilities */}
        <section id="capabilities" className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="mt-4 text-base font-bold text-slate-900">
                Automatic AI Background Changer
              </h3>
              <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">
                Free on-device neural segmentation isolates people, hair, clothes, and products,
                then automatically blends lighting, color temperature, and soft shadows into 15
                studio categories or your own backdrop.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <SlidersHorizontal className="w-5 h-5" />
              </div>
              <h3 className="mt-4 text-base font-bold text-slate-900">
                Professional AI Color Tuning
              </h3>
              <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">
                Analyzes lighting, dynamic range, white balance, and skin tones to dial in natural
                values across 16 live sliders and 15 color styles with real-time Before/After
                comparison.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="mt-4 text-base font-bold text-slate-900">
                Complete Local Studio & Export
              </h3>
              <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">
                Includes brush-based Object Removal, Portrait Enhance, Crop & Rotate, Text,
                Stickers, unlimited Undo/Redo, and JPG, PNG, or true alpha-transparent PNG export.
              </p>
            </div>
          </div>
        </section>

        {/* Transparent Modular AI Engine Status */}
        <section id="engines" className="border-t border-slate-100 bg-slate-50/50 py-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    Modular AI Engine Architecture
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Every core tool runs free right now — optional paid generative APIs never block
                    the app.
                  </p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-900">Neural Background AI</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Free on-device ISNet model · Ready
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-semibold text-slate-900">Color Tune & Brush Removal</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      Free local CV & healing engine · Ready
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  {aiStatus.geminiVisionAvailable ? (
                    <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  ) : (
                    <KeyRound className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                  )}
                  <div>
                    <div className="font-semibold text-slate-900">Gemini Vision Analysis</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {aiStatus.geminiVisionAvailable
                        ? `Connected (${aiStatus.visionModel})`
                        : 'Optional free-tier key · Using Local Vision'}
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  {aiStatus.paidGenerativeImageAvailable ? (
                    <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                  ) : (
                    <KeyRound className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                  )}
                  <div>
                    <div className="font-semibold text-slate-900">Custom Text-to-Scene HD</div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {aiStatus.paidGenerativeImageAvailable
                        ? 'Paid Gemini Image API active'
                        : 'Requires paid Gemini Image key (optional)'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-100 py-5 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
          <span>BT Kite · Developed by BT Media Studio</span>
          <span>Original photos stay private and untouched on your device</span>
        </div>
      </footer>
    </div>
  );
};
