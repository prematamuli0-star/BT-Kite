import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  Columns2,
  Crop,
  Download,
  Image as ImageIcon,
  Maximize2,
  Palette,
  Redo2,
  SlidersHorizontal,
  Sparkles,
  Sticker,
  Type,
  Undo2,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  BACKGROUND_PRESETS,
  computeAutoBlendForScene,
  matchPromptToBackgroundPreset,
} from '../data/presets';
import {
  analyzePhotoSmart,
  refineAnalysisWithCutout,
  requestPaidGenerativeEdit,
} from '../lib/aiService';
import { removeBackgroundNeural } from '../lib/backgroundRemoval';
import {
  applyCropToImageUrl,
  computeAIEnhanceAdjustments,
  computePortraitEnhanceAdjustments,
  inpaintMaskedRegion,
  renderSnapshotToCanvas,
} from '../lib/imageEngine';
import {
  AIStatus,
  BackgroundBlendSettings,
  BackgroundCategoryId,
  ColorAdjustments,
  ColorStyleId,
  CropRect,
  DEFAULT_ADJUSTMENTS,
  DEFAULT_BACKGROUND,
  DEFAULT_TRANSFORM,
  EditorSnapshot,
  PhotoAnalysisResult,
  ProcessingState,
  SourcePhoto,
  StickerLayer,
  TextLayer,
  ToolTab,
} from '../types/editor';
import { ExportModal } from './ExportModal';
import { FullscreenModal } from './FullscreenModal';
import { AdjustPanel } from './panels/AdjustPanel';
import { AIPanel } from './panels/AIPanel';
import { BackgroundPanel } from './panels/BackgroundPanel';
import { AspectPresetId, CropPanel } from './panels/CropPanel';
import { FiltersPanel } from './panels/FiltersPanel';
import { StickersPanel } from './panels/StickersPanel';
import { TextPanel } from './panels/TextPanel';

interface EditorWorkspaceProps {
  sourcePhoto: SourcePhoto;
  aiStatus: AIStatus;
  onBack: () => void;
}

const TOOL_TABS: Array<{ id: ToolTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'ai', label: 'AI', icon: Sparkles },
  { id: 'background', label: 'Background', icon: ImageIcon },
  { id: 'adjust', label: 'Adjust', icon: SlidersHorizontal },
  { id: 'filters', label: 'Filters', icon: Palette },
  { id: 'crop', label: 'Crop', icon: Crop },
  { id: 'text', label: 'Text', icon: Type },
  { id: 'stickers', label: 'Stickers', icon: Sticker },
];

const INITIAL_CROP: CropRect = { x: 0, y: 0, width: 1, height: 1 };

function makeInitialSnapshot(source: SourcePhoto): EditorSnapshot {
  return {
    baseImageUrl: source.dataUrl,
    cutoutImageUrl: null,
    background: {
      ...DEFAULT_BACKGROUND,
      blend: { ...DEFAULT_BACKGROUND.blend },
    },
    adjustments: { ...DEFAULT_ADJUSTMENTS },
    styleId: 'none',
    styleIntensity: 85,
    transform: { ...DEFAULT_TRANSFORM },
    textLayers: [],
    stickerLayers: [],
    label: 'Original',
  };
}

export const EditorWorkspace: React.FC<EditorWorkspaceProps> = ({
  sourcePhoto,
  aiStatus,
  onBack,
}) => {
  // Undo / Redo History State
  const [past, setPast] = useState<EditorSnapshot[]>([]);
  const [present, setPresent] = useState<EditorSnapshot>(() => makeInitialSnapshot(sourcePhoto));
  const [future, setFuture] = useState<EditorSnapshot[]>([]);
  const pendingBaseRef = useRef<EditorSnapshot | null>(null);

  // Active Tool & UI Modes
  const [activeTab, setActiveTab] = useState<ToolTab>('ai');
  const [compareMode, setCompareMode] = useState(false);
  const [compareSplit, setCompareSplit] = useState(50);
  const [zoom, setZoom] = useState(1);
  const [qualityMode, setQualityMode] = useState<'fast' | 'studio_hd'>('fast');
  const [showExport, setShowExport] = useState(false);
  const [showFullscreen, setShowFullscreen] = useState(false);
  const [showLeaveConfirm, setShowLeaveConfirm] = useState(false);
  const [mobileSheetOpen, setMobileSheetOpen] = useState(true);

  // Feedback & Processing
  const [processing, setProcessing] = useState<ProcessingState>({
    active: false,
    title: '',
    detail: '',
    progress: 0,
    cancellable: true,
  });
  const abortControllerRef = useRef<AbortController | null>(null);
  const [banner, setBanner] = useState<{ type: 'info' | 'error'; text: string } | null>(null);
  const [analysis, setAnalysis] = useState<PhotoAnalysisResult | null>(null);
  const [analyzingScene, setAnalyzingScene] = useState(false);

  // Preview Canvas & Rendered Preview URL (for Fullscreen / Before-After)
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageBoxRef = useRef<HTMLDivElement | null>(null);
  const [previewDataUrl, setPreviewDataUrl] = useState<string>(sourcePhoto.dataUrl);
  const [canvasDisplaySize, setCanvasDisplaySize] = useState({ width: sourcePhoto.width, height: sourcePhoto.height });

  // Crop State
  const [cropRect, setCropRect] = useState<CropRect>(INITIAL_CROP);
  const [selectedAspect, setSelectedAspect] = useState<AspectPresetId>('free');
  const [aspectRatioValue, setAspectRatioValue] = useState<number | null>(null);
  const cropDragRef = useRef<{
    mode: 'move' | 'nw' | 'ne' | 'sw' | 'se';
    startX: number;
    startY: number;
    startRect: CropRect;
  } | null>(null);

  // Object Removal Brush State
  const [brushActive, setBrushActive] = useState(false);
  const [brushSize, setBrushSize] = useState(28);
  const [hasBrushStrokes, setHasBrushStrokes] = useState(false);
  const brushCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const isPaintingRef = useRef(false);
  const lastBrushPtRef = useRef<{ x: number; y: number } | null>(null);

  // Overlay Selection & Dragging State
  const [selectedTextId, setSelectedTextId] = useState<string | null>(null);
  const [selectedStickerId, setSelectedStickerId] = useState<string | null>(null);
  const overlayDragRef = useRef<{
    kind: 'text' | 'sticker';
    id: string;
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
  } | null>(null);

  // Commit a new snapshot into undoable history
  const commitSnapshot = useCallback((next: EditorSnapshot) => {
    setPresent((curr) => {
      setPast((p) => [...p.slice(-29), curr]);
      setFuture([]);
      return next;
    });
    pendingBaseRef.current = null;
  }, []);

  // Live preview update without pushing history until pointer release
  const updateLiveOrCommit = useCallback(
    (updater: (curr: EditorSnapshot) => EditorSnapshot, commit: boolean) => {
      if (commit) {
        const baseForHistory = pendingBaseRef.current;
        setPresent((curr) => {
          const next = updater(curr);
          const prevToSave = baseForHistory ?? curr;
          setPast((p) => [...p.slice(-29), prevToSave]);
          setFuture([]);
          pendingBaseRef.current = null;
          return next;
        });
      } else {
        setPresent((curr) => {
          if (!pendingBaseRef.current) {
            pendingBaseRef.current = curr;
          }
          return updater(curr);
        });
      }
    },
    []
  );

  const handleUndo = useCallback(() => {
    if (past.length === 0) return;
    const previous = past[past.length - 1];
    setPast((p) => p.slice(0, -1));
    setFuture((f) => [present, ...f.slice(0, 29)]);
    setPresent(previous);
    pendingBaseRef.current = null;
  }, [past, present]);

  const handleRedo = useCallback(() => {
    if (future.length === 0) return;
    const next = future[0];
    setFuture((f) => f.slice(1));
    setPast((p) => [...p, present]);
    setPresent(next);
    pendingBaseRef.current = null;
  }, [future, present]);

  // Keyboard shortcuts for Undo / Redo
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleUndo, handleRedo]);

  // Render live canvas whenever `present` changes
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    let cancelled = false;

    const timer = window.setTimeout(() => {
      renderSnapshotToCanvas(canvas, present, 1280, true)
        .then(({ width, height }) => {
          if (cancelled) return;
          setCanvasDisplaySize({ width, height });
          setPreviewDataUrl(canvas.toDataURL('image/png'));
        })
        .catch(() => {
          // ignore transient render error
        });
    }, 12);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [present]);

  // Keep brush overlay canvas sized cleanly
  useEffect(() => {
    const bCanvas = brushCanvasRef.current;
    if (!bCanvas) return;
    if (bCanvas.width !== canvasDisplaySize.width || bCanvas.height !== canvasDisplaySize.height) {
      bCanvas.width = canvasDisplaySize.width;
      bCanvas.height = canvasDisplaySize.height;
      setHasBrushStrokes(false);
    }
  }, [canvasDisplaySize, brushActive]);

  const showToast = useCallback((type: 'info' | 'error', text: string) => {
    setBanner({ type, text });
  }, []);

  useEffect(() => {
    if (!banner || banner.type === 'error') return;
    const t = window.setTimeout(() => setBanner(null), 4500);
    return () => window.clearTimeout(t);
  }, [banner]);

  const cancelProcessing = useCallback(() => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    showToast('info', 'Operation cancelled. Your photo was not changed.');
  }, [showToast]);

  // Run lightweight intelligent scene understanding automatically so Photo Analysis & Top 5 Matches are ready immediately
  const runSceneAnalysis = useCallback(
    async (imageUrl: string, cutoutUrl?: string | null) => {
      setAnalyzingScene(true);
      try {
        const res = await analyzePhotoSmart(
          imageUrl,
          aiStatus.geminiVisionAvailable,
          undefined,
          cutoutUrl
        );
        setAnalysis(res);
      } catch {
        // Non-blocking preview analysis; user can retry via Refresh or Auto Background
      } finally {
        setAnalyzingScene(false);
      }
    },
    [aiStatus.geminiVisionAvailable]
  );

  useEffect(() => {
    let active = true;
    setAnalyzingScene(true);
    analyzePhotoSmart(sourcePhoto.dataUrl, aiStatus.geminiVisionAvailable)
      .then((res) => {
        if (active) setAnalysis(res);
      })
      .catch(() => {
        // ignore transient error
      })
      .finally(() => {
        if (active) setAnalyzingScene(false);
      });
    return () => {
      active = false;
    };
  }, [sourcePhoto.id, sourcePhoto.dataUrl, aiStatus.geminiVisionAvailable]);

  // Ensure neural subject cutout exists for the current baseImageUrl
  const ensureSubjectCutout = useCallback(
    async (signal: AbortSignal): Promise<string> => {
      if (present.cutoutImageUrl) {
        return present.cutoutImageUrl;
      }
      return removeBackgroundNeural(
        present.baseImageUrl,
        (u) => {
          setProcessing((prev) => ({
            ...prev,
            detail: u.stage,
            progress: Math.max(prev.progress, u.progress),
          }));
        },
        signal
      );
    },
    [present.baseImageUrl, present.cutoutImageUrl]
  );

  // FEATURE 1: INTELLIGENT ONE-TAP AUTO BACKGROUND
  const handleAutoBackground = useCallback(async () => {
    const controller = new AbortController();
    abortControllerRef.current = controller;
    setBrushActive(false);
    setBanner(null);

    setProcessing({
      active: true,
      title: 'Auto Background',
      detail: 'Understanding subject pose, position, camera angle & lighting direction...',
      progress: 8,
      cancellable: true,
    });

    try {
      // Step 1: Analyze photo composition, pose, perspective, and lighting
      let sceneAnalysis =
        analysis ||
        (await analyzePhotoSmart(
          present.baseImageUrl,
          aiStatus.geminiVisionAvailable,
          controller.signal
        ));
      if (controller.signal.aborted) return;
      setAnalysis(sceneAnalysis);

      const recommendedPreset =
        BACKGROUND_PRESETS.find((b) => b.id === sceneAnalysis.recommendedBackgroundId) ||
        BACKGROUND_PRESETS[0];

      setProcessing((prev) => ({
        ...prev,
        detail: `Matched ${recommendedPreset.name} for ${sceneAnalysis.poseDetail.toLowerCase()} · Isolating subject...`,
        progress: 24,
      }));

      // Step 2: Free on-device neural segmentation to isolate subject with hair/clothing detail
      const cutoutUrl = await ensureSubjectCutout(controller.signal);
      if (controller.signal.aborted) return;

      setProcessing((prev) => ({
        ...prev,
        detail: 'Measuring subject footprint, aligning perspective horizon & blending shadows...',
        progress: 92,
      }));

      // Step 3: Refine scene geometry with pixel-exact cutout footprint & compute perspective-matched blend
      sceneAnalysis = await refineAnalysisWithCutout(sceneAnalysis, cutoutUrl);
      if (controller.signal.aborted) return;
      setAnalysis(sceneAnalysis);

      const autoBlend = computeAutoBlendForScene({
        preset: recommendedPreset,
        cameraDistance: sceneAnalysis.cameraDistance,
        groundLevelY: sceneAnalysis.groundLevelY,
        horizonY: sceneAnalysis.horizonY,
        lightingDirection: sceneAnalysis.lightingDirection,
      });

      commitSnapshot({
        ...present,
        cutoutImageUrl: cutoutUrl,
        background: {
          ...present.background,
          categoryId: recommendedPreset.id,
          blend: {
            lightMatch: 72,
            colorMatch: 60,
            shadowDepth: autoBlend.shadowDepth,
            backgroundBlur: autoBlend.backgroundBlur,
            edgeRefine: 52,
            subjectScale: 100, // Strictly preserve exact original subject position, size & proportions
            horizonShift: autoBlend.horizonShift,
            lightingDirection: autoBlend.lightingDirection,
          },
        },
        label: `Auto BG: ${recommendedPreset.name}`,
      });

      setCompareMode(true);
      setCompareSplit(50);
      setActiveTab('background');
      showToast(
        'info',
        `Auto Background matched ${recommendedPreset.name} (${sceneAnalysis.poseDetail}) with aligned perspective & lighting.`
      );
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      showToast(
        'error',
        err instanceof Error
          ? `Background removal could not complete: ${err.message}`
          : 'Background removal failed. Please check your connection for first-time model download.'
      );
    } finally {
      abortControllerRef.current = null;
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  }, [
    present,
    analysis,
    aiStatus.geminiVisionAvailable,
    ensureSubjectCutout,
    commitSnapshot,
    showToast,
  ]);

  // Select any Recommended or Studio Background Category (preserves subject position & auto-aligns horizon/DoF)
  const handleSelectBackgroundCategory = useCallback(
    async (categoryId: BackgroundCategoryId) => {
      const preset = BACKGROUND_PRESETS.find((b) => b.id === categoryId) || BACKGROUND_PRESETS[0];

      const buildSceneBlend = (scene: PhotoAnalysisResult | null) =>
        computeAutoBlendForScene({
          preset,
          cameraDistance: scene?.cameraDistance || 'medium-shot',
          groundLevelY: scene?.groundLevelY ?? 0.96,
          horizonY: scene?.horizonY ?? 0.52,
          lightingDirection: scene?.lightingDirection || preset.keyLightDirection,
        });

      if (present.cutoutImageUrl) {
        const refinedScene = analysis
          ? await refineAnalysisWithCutout(analysis, present.cutoutImageUrl)
          : null;
        if (refinedScene) setAnalysis(refinedScene);
        const autoBlend = buildSceneBlend(refinedScene);

        commitSnapshot({
          ...present,
          background: {
            ...present.background,
            categoryId,
            blend: {
              ...present.background.blend,
              backgroundBlur: autoBlend.backgroundBlur,
              shadowDepth: autoBlend.shadowDepth,
              horizonShift: autoBlend.horizonShift,
              lightingDirection: autoBlend.lightingDirection,
              subjectScale: 100,
            },
          },
          label: `BG: ${preset.name}`,
        });
        return;
      }

      const controller = new AbortController();
      abortControllerRef.current = controller;
      setBanner(null);
      setProcessing({
        active: true,
        title: `Applying ${preset.name}`,
        detail: 'Isolating subject and measuring position & perspective...',
        progress: 10,
        cancellable: true,
      });

      try {
        const cutoutUrl = await ensureSubjectCutout(controller.signal);
        if (controller.signal.aborted) return;

        let sceneAnalysis = analysis;
        if (!sceneAnalysis) {
          sceneAnalysis = await analyzePhotoSmart(
            present.baseImageUrl,
            aiStatus.geminiVisionAvailable,
            controller.signal,
            cutoutUrl
          );
        } else {
          sceneAnalysis = await refineAnalysisWithCutout(sceneAnalysis, cutoutUrl);
        }
        if (controller.signal.aborted) return;
        setAnalysis(sceneAnalysis);

        const autoBlend = buildSceneBlend(sceneAnalysis);

        commitSnapshot({
          ...present,
          cutoutImageUrl: cutoutUrl,
          background: {
            ...present.background,
            categoryId,
            blend: {
              lightMatch: 72,
              colorMatch: 58,
              shadowDepth: autoBlend.shadowDepth,
              backgroundBlur: autoBlend.backgroundBlur,
              edgeRefine: 50,
              subjectScale: 100,
              horizonShift: autoBlend.horizonShift,
              lightingDirection: autoBlend.lightingDirection,
            },
          },
          label: `BG: ${preset.name}`,
        });
        showToast(
          'info',
          `Blended into ${preset.name} while preserving exact subject position & lighting.`
        );
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        showToast(
          'error',
          err instanceof Error
            ? err.message
            : 'Unable to isolate subject for background replacement.'
        );
      } finally {
        abortControllerRef.current = null;
        setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
      }
    },
    [
      present,
      analysis,
      aiStatus.geminiVisionAvailable,
      ensureSubjectCutout,
      commitSnapshot,
      showToast,
    ]
  );

  const handleRemoveToTransparent = useCallback(async () => {
    if (present.cutoutImageUrl) {
      commitSnapshot({
        ...present,
        background: { ...present.background, categoryId: 'transparent' },
        label: 'Transparent Cutout',
      });
      showToast('info', 'Transparent background active. Export as Cutout PNG anytime.');
      return;
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;
    setBanner(null);
    setProcessing({
      active: true,
      title: 'Removing Background',
      detail: 'Detecting subject, hair, and fine edges...',
      progress: 12,
      cancellable: true,
    });

    try {
      const cutoutUrl = await ensureSubjectCutout(controller.signal);
      if (controller.signal.aborted) return;
      commitSnapshot({
        ...present,
        cutoutImageUrl: cutoutUrl,
        background: { ...present.background, categoryId: 'transparent' },
        label: 'Transparent Cutout',
      });
      showToast('info', 'Background removed cleanly. Ready for transparent PNG export.');
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      showToast(
        'error',
        err instanceof Error ? err.message : 'Background removal could not complete.'
      );
    } finally {
      abortControllerRef.current = null;
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  }, [present, ensureSubjectCutout, commitSnapshot, showToast]);

  const handleUploadCustomBackdrop = useCallback(
    async (file: File) => {
      const reader = new FileReader();
      const customUrl = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('Failed to read custom backdrop'));
        reader.readAsDataURL(file);
      });

      if (present.cutoutImageUrl) {
        commitSnapshot({
          ...present,
          background: {
            ...present.background,
            categoryId: 'custom-upload',
            customImageUrl: customUrl,
          },
          label: 'Custom Backdrop',
        });
        showToast('info', 'Applied your custom background photo.');
        return;
      }

      const controller = new AbortController();
      abortControllerRef.current = controller;
      setProcessing({
        active: true,
        title: 'Applying Custom Backdrop',
        detail: 'Isolating subject before blending onto your backdrop...',
        progress: 12,
        cancellable: true,
      });

      try {
        const cutoutUrl = await ensureSubjectCutout(controller.signal);
        if (controller.signal.aborted) return;
        commitSnapshot({
          ...present,
          cutoutImageUrl: cutoutUrl,
          background: {
            ...present.background,
            categoryId: 'custom-upload',
            customImageUrl: customUrl,
          },
          label: 'Custom Backdrop',
        });
        showToast('info', 'Blended subject onto your custom background photo.');
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        showToast('error', err instanceof Error ? err.message : 'Custom background failed.');
      } finally {
        abortControllerRef.current = null;
        setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
      }
    },
    [present, ensureSubjectCutout, commitSnapshot, showToast]
  );

  const handlePromptSmartMatch = useCallback(
    async (prompt: string) => {
      const matched = matchPromptToBackgroundPreset(prompt);
      await handleSelectBackgroundCategory(matched.id);
      showToast(
        'info',
        `Matched "${matched.name}" studio backdrop to your prompt (free on-device mode).`
      );
    },
    [handleSelectBackgroundCategory, showToast]
  );

  const handlePromptPaidGenerative = useCallback(
    async (prompt: string) => {
      const controller = new AbortController();
      abortControllerRef.current = controller;
      setBanner(null);
      setProcessing({
        active: true,
        title: 'Generative AI Background',
        detail: 'Connecting to optional Gemini Image API...',
        progress: 35,
        cancellable: true,
      });
      try {
        const result = await requestPaidGenerativeEdit(
          present.baseImageUrl,
          prompt,
          qualityMode,
          controller.signal
        );
        if (controller.signal.aborted) return;
        commitSnapshot({
          ...present,
          baseImageUrl: result.imageUrl,
          cutoutImageUrl: null,
          background: { ...DEFAULT_BACKGROUND, blend: { ...DEFAULT_BACKGROUND.blend } },
          label: 'Gemini Generative BG',
        });
        showToast('info', `Generated custom scene using ${result.model}.`);
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        showToast(
          'error',
          err instanceof Error
            ? err.message
            : 'Generative scene synthesis requires a paid Gemini Image API key.'
        );
      } finally {
        abortControllerRef.current = null;
        setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
      }
    },
    [present, qualityMode, commitSnapshot, showToast]
  );

  // FEATURE 2: ONE-TAP AI COLOR TUNE
  const handleAIColorTune = useCallback(async () => {
    const controller = new AbortController();
    abortControllerRef.current = controller;
    setBanner(null);

    setProcessing({
      active: true,
      title: 'AI Color Tune',
      detail: 'Analyzing lighting, exposure, white balance, and skin tones...',
      progress: 30,
      cancellable: true,
    });

    try {
      const res = await analyzePhotoSmart(
        present.baseImageUrl,
        aiStatus.geminiVisionAvailable,
        controller.signal
      );
      if (controller.signal.aborted) return;
      setAnalysis(res);

      setProcessing((prev) => ({
        ...prev,
        detail: `Applying natural ${res.photoCategory} color grading...`,
        progress: 90,
      }));

      commitSnapshot({
        ...present,
        adjustments: { ...res.adjustments },
        styleId: res.recommendedStyleId,
        styleIntensity: 45,
        label: `AI Color Tune (${res.photoCategory})`,
      });

      setCompareMode(true);
      setCompareSplit(50);
      showToast(
        'info',
        `AI Color Tune applied (${res.photoCategory} · ${
          res.engine === 'gemini-vision' ? 'Gemini Vision' : 'Local Smart Vision'
        }).`
      );
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') return;
      showToast('error', err instanceof Error ? err.message : 'AI Color Tune failed.');
    } finally {
      abortControllerRef.current = null;
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  }, [present, aiStatus.geminiVisionAvailable, commitSnapshot, showToast]);

  // ONE-CLICK AI ENHANCE
  const handleAIEnhance = useCallback(async () => {
    setProcessing({
      active: true,
      title: 'AI Enhance',
      detail: 'Enhancing clarity, dynamic range, and natural detail...',
      progress: 55,
      cancellable: false,
    });
    try {
      const enhancedAdj = await computeAIEnhanceAdjustments(present.baseImageUrl);
      commitSnapshot({
        ...present,
        adjustments: enhancedAdj,
        label: 'AI Enhance',
      });
      setCompareMode(true);
      setCompareSplit(50);
      showToast('info', 'AI Enhance applied. Fine-tune any slider in Adjust.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'AI Enhance failed.');
    } finally {
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  }, [present, commitSnapshot, showToast]);

  // PORTRAIT ENHANCE
  const handlePortraitEnhance = useCallback(async () => {
    setProcessing({
      active: true,
      title: 'Portrait Enhance',
      detail: 'Balancing skin tones, lifting shadows, and sharpening facial detail...',
      progress: 55,
      cancellable: false,
    });
    try {
      const portraitAdj = await computePortraitEnhanceAdjustments(present.baseImageUrl);
      commitSnapshot({
        ...present,
        adjustments: portraitAdj,
        styleId: 'professional-portrait',
        styleIntensity: 45,
        label: 'Portrait Enhance',
      });
      setCompareMode(true);
      setCompareSplit(50);
      showToast('info', 'Portrait Enhance applied with natural skin-tone preservation.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Portrait Enhance failed.');
    } finally {
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  }, [present, commitSnapshot, showToast]);

  // INTERACTIVE BRUSH OBJECT REMOVAL
  const clearBrushCanvas = useCallback(() => {
    const bCanvas = brushCanvasRef.current;
    if (!bCanvas) return;
    const ctx = bCanvas.getContext('2d');
    ctx?.clearRect(0, 0, bCanvas.width, bCanvas.height);
    setHasBrushStrokes(false);
  }, []);

  const handleApplyObjectRemoval = useCallback(async () => {
    const bCanvas = brushCanvasRef.current;
    if (!bCanvas || !hasBrushStrokes) return;

    setProcessing({
      active: true,
      title: 'Removing Object',
      detail: 'Reconstructing surrounding texture inside brushed region...',
      progress: 60,
      cancellable: false,
    });

    try {
      const healedUrl = await inpaintMaskedRegion(present.baseImageUrl, bCanvas);
      commitSnapshot({
        ...present,
        baseImageUrl: healedUrl,
        cutoutImageUrl: null,
        label: 'Object Removal',
      });
      clearBrushCanvas();
      setBrushActive(false);
      showToast('info', 'Brushed object removed cleanly.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Object removal failed.');
    } finally {
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  }, [present, hasBrushStrokes, commitSnapshot, clearBrushCanvas, showToast]);

  // Brush pointer painting handlers
  const getCanvasPoint = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = brushCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / Math.max(1, rect.width);
    const scaleY = canvas.height / Math.max(1, rect.height);
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const handleBrushPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!brushActive) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    isPaintingRef.current = true;
    const pt = getCanvasPoint(e);
    lastBrushPtRef.current = pt;
    const ctx = e.currentTarget.getContext('2d');
    if (!ctx) return;
    const scaledRadius = (brushSize * e.currentTarget.width) / Math.max(320, e.currentTarget.getBoundingClientRect().width);
    ctx.fillStyle = 'rgba(37, 99, 235, 0.55)';
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, scaledRadius / 2, 0, Math.PI * 2);
    ctx.fill();
    setHasBrushStrokes(true);
  };

  const handleBrushPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!brushActive || !isPaintingRef.current) return;
    const pt = getCanvasPoint(e);
    const prev = lastBrushPtRef.current ?? pt;
    const ctx = e.currentTarget.getContext('2d');
    if (!ctx) return;
    const scaledWidth = (brushSize * e.currentTarget.width) / Math.max(320, e.currentTarget.getBoundingClientRect().width);
    ctx.strokeStyle = 'rgba(37, 99, 235, 0.55)';
    ctx.lineWidth = scaledWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(prev.x, prev.y);
    ctx.lineTo(pt.x, pt.y);
    ctx.stroke();
    lastBrushPtRef.current = pt;
  };

  const handleBrushPointerUp = () => {
    isPaintingRef.current = false;
    lastBrushPtRef.current = null;
  };

  // Crop Logic
  const cropDirty = useMemo(
    () =>
      cropRect.x > 0.005 ||
      cropRect.y > 0.005 ||
      cropRect.width < 0.995 ||
      cropRect.height < 0.995,
    [cropRect]
  );

  const handleSelectAspect = (id: AspectPresetId, ratio: number | null) => {
    setSelectedAspect(id);
    setAspectRatioValue(ratio);
    if (!ratio) {
      setCropRect(INITIAL_CROP);
      return;
    }
    const imgAspect = canvasDisplaySize.width / Math.max(1, canvasDisplaySize.height);
    let w = 1;
    let h = 1;
    if (ratio > imgAspect) {
      w = 0.92;
      h = (w * imgAspect) / ratio;
    } else {
      h = 0.92;
      w = (h * ratio) / imgAspect;
    }
    w = Math.min(1, w);
    h = Math.min(1, h);
    setCropRect({ x: (1 - w) / 2, y: (1 - h) / 2, width: w, height: h });
  };

  const handleApplyCrop = async () => {
    if (!cropDirty) return;
    setProcessing({
      active: true,
      title: 'Cropping Photo',
      detail: 'Applying lossless crop...',
      progress: 65,
      cancellable: false,
    });
    try {
      const croppedBase = await applyCropToImageUrl(present.baseImageUrl, cropRect);
      const croppedCutout = present.cutoutImageUrl
        ? await applyCropToImageUrl(present.cutoutImageUrl, cropRect)
        : null;
      commitSnapshot({
        ...present,
        baseImageUrl: croppedBase,
        cutoutImageUrl: croppedCutout,
        label: 'Cropped Photo',
      });
      setCropRect(INITIAL_CROP);
      setSelectedAspect('free');
      setAspectRatioValue(null);
      showToast('info', 'Crop applied.');
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Crop failed.');
    } finally {
      setProcessing({ active: false, title: '', detail: '', progress: 0, cancellable: true });
    }
  };

  const handleCropPointerDown = (
    e: React.PointerEvent,
    mode: 'move' | 'nw' | 'ne' | 'sw' | 'se'
  ) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    cropDragRef.current = {
      mode,
      startX: e.clientX,
      startY: e.clientY,
      startRect: { ...cropRect },
    };
  };

  const handleCropPointerMove = (e: React.PointerEvent) => {
    const drag = cropDragRef.current;
    const box = stageBoxRef.current;
    if (!drag || !box) return;
    const rect = box.getBoundingClientRect();
    const dx = (e.clientX - drag.startX) / Math.max(1, rect.width);
    const dy = (e.clientY - drag.startY) / Math.max(1, rect.height);
    const s = drag.startRect;
    const minSize = 0.14;

    if (drag.mode === 'move') {
      const nx = Math.max(0, Math.min(1 - s.width, s.x + dx));
      const ny = Math.max(0, Math.min(1 - s.height, s.y + dy));
      setCropRect({ ...s, x: nx, y: ny });
      return;
    }

    let x = s.x;
    let y = s.y;
    let w = s.width;
    let h = s.height;

    if (drag.mode.includes('e')) {
      w = Math.max(minSize, Math.min(1 - x, s.width + dx));
    }
    if (drag.mode.includes('s')) {
      h = Math.max(minSize, Math.min(1 - y, s.height + dy));
    }
    if (drag.mode.includes('w')) {
      const nextX = Math.max(0, Math.min(s.x + s.width - minSize, s.x + dx));
      w = s.width + (s.x - nextX);
      x = nextX;
    }
    if (drag.mode.includes('n')) {
      const nextY = Math.max(0, Math.min(s.y + s.height - minSize, s.y + dy));
      h = s.height + (s.y - nextY);
      y = nextY;
    }

    if (aspectRatioValue) {
      const imgAspect = canvasDisplaySize.width / Math.max(1, canvasDisplaySize.height);
      const targetH = (w * imgAspect) / aspectRatioValue;
      if (y + targetH <= 1 && targetH >= minSize) {
        h = targetH;
      } else {
        w = (h * aspectRatioValue) / imgAspect;
      }
    }

    setCropRect({
      x: Math.max(0, x),
      y: Math.max(0, y),
      width: Math.min(1 - Math.max(0, x), w),
      height: Math.min(1 - Math.max(0, y), h),
    });
  };

  const handleCropPointerUp = () => {
    cropDragRef.current = null;
  };

  // Overlay Drag Handlers (Text & Stickers)
  const startOverlayDrag = (
    e: React.PointerEvent,
    kind: 'text' | 'sticker',
    id: string,
    origX: number,
    origY: number
  ) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    if (kind === 'text') setSelectedTextId(id);
    else setSelectedStickerId(id);
    overlayDragRef.current = {
      kind,
      id,
      startClientX: e.clientX,
      startClientY: e.clientY,
      origX,
      origY,
    };
  };

  const moveOverlayDrag = (e: React.PointerEvent) => {
    const drag = overlayDragRef.current;
    const box = stageBoxRef.current;
    if (!drag || !box) return;
    const rect = box.getBoundingClientRect();
    const dxPct = ((e.clientX - drag.startClientX) / Math.max(1, rect.width)) * 100;
    const dyPct = ((e.clientY - drag.startClientY) / Math.max(1, rect.height)) * 100;
    const nx = Math.max(5, Math.min(95, Math.round(drag.origX + dxPct)));
    const ny = Math.max(5, Math.min(95, Math.round(drag.origY + dyPct)));

    if (drag.kind === 'text') {
      updateLiveOrCommit(
        (curr) => ({
          ...curr,
          textLayers: curr.textLayers.map((l) => (l.id === drag.id ? { ...l, x: nx, y: ny } : l)),
        }),
        false
      );
    } else {
      updateLiveOrCommit(
        (curr) => ({
          ...curr,
          stickerLayers: curr.stickerLayers.map((l) =>
            l.id === drag.id ? { ...l, x: nx, y: ny } : l
          ),
        }),
        false
      );
    }
  };

  const endOverlayDrag = () => {
    if (!overlayDragRef.current) return;
    overlayDragRef.current = null;
    updateLiveOrCommit((curr) => curr, true);
  };

  const hasTransparency =
    Boolean(present.cutoutImageUrl) && present.background.categoryId === 'transparent';

  const handleBackClick = () => {
    if (past.length > 0) {
      setShowLeaveConfirm(true);
    } else {
      onBack();
    }
  };

  const renderActivePanel = () => {
    switch (activeTab) {
      case 'ai':
        return (
          <AIPanel
            aiStatus={aiStatus}
            qualityMode={qualityMode}
            onChangeQualityMode={setQualityMode}
            analysis={analysis}
            brushActive={brushActive}
            brushSize={brushSize}
            hasBrushStrokes={hasBrushStrokes}
            onAutoBackground={handleAutoBackground}
            onAIColorTune={handleAIColorTune}
            onAIEnhance={handleAIEnhance}
            onPortraitEnhance={handlePortraitEnhance}
            onOpenBackgroundGenerator={() => {
              setBrushActive(false);
              setActiveTab('background');
            }}
            onToggleBrushMode={(active) => {
              setBrushActive(active);
              if (active) setCompareMode(false);
            }}
            onBrushSizeChange={setBrushSize}
            onClearBrush={clearBrushCanvas}
            onApplyObjectRemoval={handleApplyObjectRemoval}
          />
        );
      case 'background':
        return (
          <BackgroundPanel
            background={present.background}
            hasCutout={Boolean(present.cutoutImageUrl)}
            aiStatus={aiStatus}
            analysis={analysis}
            analyzingScene={analyzingScene}
            onAnalyzePhoto={() => runSceneAnalysis(present.baseImageUrl, present.cutoutImageUrl)}
            onAutoBackground={handleAutoBackground}
            onRemoveToTransparent={handleRemoveToTransparent}
            onRestoreOriginalBg={() =>
              commitSnapshot({
                ...present,
                background: { ...present.background, categoryId: 'original' },
                label: 'Restore Background',
              })
            }
            onSelectCategory={handleSelectBackgroundCategory}
            onSelectPassportColor={(hex) =>
              commitSnapshot({
                ...present,
                background: { ...present.background, passportColor: hex },
                label: 'Passport Color',
              })
            }
            onUploadCustomBackdrop={handleUploadCustomBackdrop}
            onApplyPromptSmartMatch={handlePromptSmartMatch}
            onApplyPromptPaidGenerative={handlePromptPaidGenerative}
            onUpdateBlend={<K extends keyof BackgroundBlendSettings>(
              key: K,
              value: BackgroundBlendSettings[K],
              commit = false
            ) =>
              updateLiveOrCommit(
                (curr) => ({
                  ...curr,
                  background: {
                    ...curr.background,
                    blend: { ...curr.background.blend, [key]: value },
                  },
                }),
                commit
              )
            }
          />
        );
      case 'adjust':
        return (
          <AdjustPanel
            adjustments={present.adjustments}
            onAIColorTune={handleAIColorTune}
            onChange={(key: keyof ColorAdjustments, value: number, commit = false) =>
              updateLiveOrCommit(
                (curr) => ({
                  ...curr,
                  adjustments: { ...curr.adjustments, [key]: value },
                }),
                commit
              )
            }
            onResetAll={() =>
              commitSnapshot({
                ...present,
                adjustments: { ...DEFAULT_ADJUSTMENTS },
                label: 'Reset Adjustments',
              })
            }
          />
        );
      case 'filters':
        return (
          <FiltersPanel
            styleId={present.styleId}
            intensity={present.styleIntensity}
            onSelectStyle={(id: ColorStyleId) =>
              commitSnapshot({
                ...present,
                styleId: id,
                styleIntensity: id === 'none' ? 0 : present.styleIntensity || 85,
                label: `Style: ${id}`,
              })
            }
            onChangeIntensity={(val, commit = false) =>
              updateLiveOrCommit((curr) => ({ ...curr, styleIntensity: val }), commit)
            }
          />
        );
      case 'crop':
        return (
          <CropPanel
            transform={present.transform}
            selectedAspect={selectedAspect}
            cropDirty={cropDirty}
            onSelectAspect={handleSelectAspect}
            onRotate={(delta) =>
              commitSnapshot({
                ...present,
                transform: {
                  ...present.transform,
                  rotation: (present.transform.rotation + delta + 360) % 360,
                },
                label: 'Rotate',
              })
            }
            onFlipH={() =>
              commitSnapshot({
                ...present,
                transform: { ...present.transform, flipH: !present.transform.flipH },
                label: 'Flip Horizontal',
              })
            }
            onFlipV={() =>
              commitSnapshot({
                ...present,
                transform: { ...present.transform, flipV: !present.transform.flipV },
                label: 'Flip Vertical',
              })
            }
            onApplyCrop={handleApplyCrop}
            onResetCrop={() => {
              setCropRect(INITIAL_CROP);
              setSelectedAspect('free');
              setAspectRatioValue(null);
            }}
          />
        );
      case 'text':
        return (
          <TextPanel
            layers={present.textLayers}
            selectedId={selectedTextId}
            onSelect={setSelectedTextId}
            onAdd={() => {
              const id = `txt_${Date.now()}`;
              const newLayer: TextLayer = {
                id,
                text: 'BT Kite Studio',
                x: 50,
                y: 82,
                fontSize: 28,
                color: '#FFFFFF',
                fontFamily: 'Plus Jakarta Sans',
                align: 'center',
                bgStyle: 'solid',
              };
              setSelectedTextId(id);
              commitSnapshot({
                ...present,
                textLayers: [...present.textLayers, newLayer],
                label: 'Add Text',
              });
            }}
            onUpdate={(id, patch, commit = false) =>
              updateLiveOrCommit(
                (curr) => ({
                  ...curr,
                  textLayers: curr.textLayers.map((l) => (l.id === id ? { ...l, ...patch } : l)),
                }),
                commit
              )
            }
            onDelete={(id) => {
              commitSnapshot({
                ...present,
                textLayers: present.textLayers.filter((l) => l.id !== id),
                label: 'Delete Text',
              });
              setSelectedTextId(null);
            }}
          />
        );
      case 'stickers':
        return (
          <StickersPanel
            layers={present.stickerLayers}
            selectedId={selectedStickerId}
            onSelect={setSelectedStickerId}
            onAdd={(stickerId) => {
              const id = `stk_${Date.now()}`;
              const newLayer: StickerLayer = {
                id,
                stickerId,
                x: 50,
                y: 26,
                scale: 1,
                rotation: 0,
              };
              setSelectedStickerId(id);
              commitSnapshot({
                ...present,
                stickerLayers: [...present.stickerLayers, newLayer],
                label: 'Add Sticker',
              });
            }}
            onUpdate={(id, patch, commit = false) =>
              updateLiveOrCommit(
                (curr) => ({
                  ...curr,
                  stickerLayers: curr.stickerLayers.map((l) =>
                    l.id === id ? { ...l, ...patch } : l
                  ),
                }),
                commit
              )
            }
            onDelete={(id) => {
              commitSnapshot({
                ...present,
                stickerLayers: present.stickerLayers.filter((l) => l.id !== id),
                label: 'Delete Sticker',
              });
              setSelectedStickerId(null);
            }}
          />
        );
    }
  };

  return (
    <div className="h-[100dvh] w-full flex flex-col bg-slate-50 text-slate-900 overflow-hidden select-none">
      {/* Compact Top Editor Bar (52px) */}
      <header className="h-[52px] shrink-0 bg-white border-b border-slate-200 px-2.5 sm:px-4 flex items-center justify-between gap-2 z-30">
        <div className="flex items-center gap-1 sm:gap-1.5">
          <button
            type="button"
            onClick={handleBackClick}
            aria-label="Back to Home"
            className="min-w-[40px] min-h-[40px] px-2 rounded-xl text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 text-sm font-semibold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back</span>
          </button>

          <div className="h-5 w-px bg-slate-200 mx-0.5" aria-hidden="true" />

          <button
            type="button"
            disabled={past.length === 0}
            onClick={handleUndo}
            aria-label="Undo"
            title="Undo (Ctrl+Z)"
            className="min-w-[40px] min-h-[40px] rounded-xl text-slate-700 hover:bg-slate-100 disabled:opacity-35 flex items-center justify-center cursor-pointer"
          >
            <Undo2 className="w-4 h-4" />
          </button>

          <button
            type="button"
            disabled={future.length === 0}
            onClick={handleRedo}
            aria-label="Redo"
            title="Redo (Ctrl+Shift+Z)"
            className="min-w-[40px] min-h-[40px] rounded-xl text-slate-700 hover:bg-slate-100 disabled:opacity-35 flex items-center justify-center cursor-pointer"
          >
            <Redo2 className="w-4 h-4" />
          </button>
        </div>

        <div className="hidden md:flex items-center gap-2 text-xs text-slate-500 truncate">
          <span className="font-bold text-slate-900">BT Kite</span>
          <span aria-hidden="true">·</span>
          <span className="truncate max-w-[180px]">{sourcePhoto.name}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">
            {canvasDisplaySize.width}×{canvasDisplaySize.height}
          </span>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            type="button"
            onClick={() => {
              setBrushActive(false);
              setCompareMode((v) => !v);
            }}
            className={`inline-flex items-center gap-1.5 min-h-[38px] px-3 rounded-xl text-xs font-semibold border transition cursor-pointer whitespace-nowrap ${
              compareMode
                ? 'bg-blue-50 border-blue-600 text-blue-800'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Columns2 className="w-3.5 h-3.5" />
            <span className="hidden xs:inline sm:inline">Compare</span>
          </button>

          <button
            type="button"
            onClick={() => setShowExport(true)}
            className="inline-flex items-center gap-1.5 min-h-[38px] px-3.5 sm:px-4 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 active:scale-[0.98] transition cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Save</span>
          </button>
        </div>
      </header>

      {/* Main Responsive Workspace: Central Stage + Right Inspector (Desktop) / Bottom Tray (Mobile) */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Photo Canvas Stage */}
        <section className="relative flex-1 min-h-0 bg-slate-100/90 flex items-center justify-center p-3 sm:p-6 overflow-hidden">
          {/* Notification Banner */}
          {banner && (
            <div
              role="status"
              className={`absolute top-3 left-1/2 -translate-x-1/2 z-30 max-w-[92%] sm:max-w-lg rounded-2xl px-4 py-2.5 shadow-lg border flex items-center gap-2.5 text-xs font-medium ${
                banner.type === 'error'
                  ? 'bg-white border-red-200 text-red-800'
                  : 'bg-white border-blue-200 text-slate-800'
              }`}
            >
              {banner.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
              )}
              <span className="leading-snug">{banner.text}</span>
              <button
                type="button"
                onClick={() => setBanner(null)}
                aria-label="Dismiss notice"
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Scalable Photo Stage Wrapper */}
          <div
            className="relative flex items-center justify-center max-w-full max-h-full transition-transform duration-150"
            style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
          >
            <div
              ref={stageBoxRef}
              className={`relative rounded-xl overflow-hidden shadow-md border border-slate-200/80 ${
                hasTransparency ? 'checkerboard-bg' : 'bg-white'
              }`}
            >
              {/* Live Rendered Canvas */}
              <canvas
                ref={previewCanvasRef}
                className="block max-h-[42dvh] sm:max-h-[52dvh] lg:max-h-[78dvh] max-w-[92vw] lg:max-w-[calc(100vw-430px)] w-auto h-auto"
              />

              {/* Before / After Comparison Slider */}
              {compareMode && !brushActive && activeTab !== 'crop' && (
                <>
                  <div
                    className="absolute inset-0 overflow-hidden pointer-events-none"
                    style={{ clipPath: `inset(0 ${100 - compareSplit}% 0 0)` }}
                  >
                    <img
                      src={sourcePhoto.dataUrl}
                      alt="Original before photo"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-fill"
                    />
                  </div>
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_8px_rgba(15,23,42,0.5)] pointer-events-none"
                    style={{ left: `${compareSplit}%` }}
                  >
                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-9 h-9 rounded-full bg-white border-2 border-blue-600 shadow-lg flex items-center justify-center text-blue-600">
                      <Columns2 className="w-4 h-4" />
                    </div>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={compareSplit}
                    onChange={(e) => setCompareSplit(Number(e.target.value))}
                    aria-label="Drag to compare original and edited photo"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
                  />
                  <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-slate-900/75 text-white text-[11px] font-semibold pointer-events-none">
                    Before
                  </span>
                  <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-blue-600/90 text-white text-[11px] font-semibold pointer-events-none">
                    After
                  </span>
                </>
              )}

              {/* Interactive Object Removal Brush Canvas */}
              {brushActive && (
                <canvas
                  ref={brushCanvasRef}
                  onPointerDown={handleBrushPointerDown}
                  onPointerMove={handleBrushPointerMove}
                  onPointerUp={handleBrushPointerUp}
                  onPointerCancel={handleBrushPointerUp}
                  className="absolute inset-0 w-full h-full touch-none cursor-crosshair z-20"
                />
              )}

              {/* Interactive Crop Frame Overlay */}
              {activeTab === 'crop' && (
                <div
                  className="absolute inset-0 z-20 touch-none"
                  onPointerMove={handleCropPointerMove}
                  onPointerUp={handleCropPointerUp}
                  onPointerCancel={handleCropPointerUp}
                >
                  <div className="absolute inset-0 bg-slate-950/45 pointer-events-none" />
                  <div
                    onPointerDown={(e) => handleCropPointerDown(e, 'move')}
                    style={{
                      left: `${cropRect.x * 100}%`,
                      top: `${cropRect.y * 100}%`,
                      width: `${cropRect.width * 100}%`,
                      height: `${cropRect.height * 100}%`,
                    }}
                    className="absolute border-2 border-white shadow-[0_0_0_9999px_rgba(15,23,42,0.45)] cursor-move"
                  >
                    {/* Rule of thirds lines */}
                    <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                      <div className="border-r border-b border-white/35" />
                      <div className="border-r border-b border-white/35" />
                      <div className="border-b border-white/35" />
                      <div className="border-r border-b border-white/35" />
                      <div className="border-r border-b border-white/35" />
                      <div className="border-b border-white/35" />
                      <div className="border-r border-white/35" />
                      <div className="border-r border-white/35" />
                      <div />
                    </div>
                    {(
                      [
                        { corner: 'nw', cls: '-top-2 -left-2 cursor-nwse-resize' },
                        { corner: 'ne', cls: '-top-2 -right-2 cursor-nesw-resize' },
                        { corner: 'sw', cls: '-bottom-2 -left-2 cursor-nesw-resize' },
                        { corner: 'se', cls: '-bottom-2 -right-2 cursor-nwse-resize' },
                      ] as const
                    ).map(({ corner, cls }) => (
                      <div
                        key={corner}
                        onPointerDown={(e) => handleCropPointerDown(e, corner)}
                        className={`absolute w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow ${cls}`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Direct Drag Handles for Text & Sticker Layers */}
              {(activeTab === 'text' || activeTab === 'stickers') && !compareMode && (
                <div
                  className="absolute inset-0 z-10 touch-none"
                  onPointerMove={moveOverlayDrag}
                  onPointerUp={endOverlayDrag}
                  onPointerCancel={endOverlayDrag}
                >
                  {activeTab === 'text' &&
                    present.textLayers.map((layer) => (
                      <div
                        key={layer.id}
                        onPointerDown={(e) => startOverlayDrag(e, 'text', layer.id, layer.x, layer.y)}
                        style={{ left: `${layer.x}%`, top: `${layer.y}%` }}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg border-2 cursor-grab active:cursor-grabbing ${
                          selectedTextId === layer.id
                            ? 'border-blue-500 bg-blue-500/15'
                            : 'border-dashed border-white/70 hover:border-blue-400'
                        }`}
                      >
                        <span className="text-[10px] font-bold text-white drop-shadow">Drag</span>
                      </div>
                    ))}

                  {activeTab === 'stickers' &&
                    present.stickerLayers.map((layer) => (
                      <div
                        key={layer.id}
                        onPointerDown={(e) =>
                          startOverlayDrag(e, 'sticker', layer.id, layer.x, layer.y)
                        }
                        style={{ left: `${layer.x}%`, top: `${layer.y}%` }}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full border-2 cursor-grab active:cursor-grabbing ${
                          selectedStickerId === layer.id
                            ? 'border-blue-500 bg-blue-500/15'
                            : 'border-dashed border-white/70 hover:border-blue-400'
                        }`}
                      />
                    ))}
                </div>
              )}

              {/* Cancellable AI Processing Overlay */}
              {processing.active && (
                <div className="absolute inset-0 z-30 bg-slate-950/60 backdrop-blur-[2px] flex flex-col items-center justify-center p-5 text-center overflow-hidden">
                  <div className="ai-scan-line absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-transparent via-blue-400/35 to-transparent pointer-events-none" />
                  <div className="relative z-10 w-full max-w-xs rounded-2xl bg-white/95 backdrop-blur-md p-4 shadow-xl border border-blue-100">
                    <div className="text-sm font-bold text-slate-900">{processing.title}</div>
                    <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                      {processing.detail}
                    </p>
                    <div className="mt-3 h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded-full transition-all duration-300"
                        style={{ width: `${Math.max(8, processing.progress)}%` }}
                      />
                    </div>
                    {processing.cancellable && (
                      <button
                        type="button"
                        onClick={cancelProcessing}
                        className="mt-3 w-full min-h-[36px] rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-50 cursor-pointer"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Floating Zoom & Fullscreen Controls */}
          <div className="absolute bottom-3 right-3 z-20 flex items-center gap-1 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200 p-1 shadow-sm">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.5, Number((z - 0.25).toFixed(2))))}
              aria-label="Zoom out"
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setZoom(1)}
              title="Reset zoom"
              className="px-2 h-8 rounded-lg font-mono tabular-nums text-[11px] font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              {Math.round(zoom * 100)}%
            </button>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(3, Number((z + 0.25).toFixed(2))))}
              aria-label="Zoom in"
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <div className="w-px h-4 bg-slate-200 mx-0.5" aria-hidden="true" />
            <button
              type="button"
              onClick={() => setShowFullscreen(true)}
              aria-label="Fullscreen preview"
              title="Fullscreen preview"
              className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </section>

        {/* Studio Tool Inspector (Right Panel on Desktop / Slide-Up Tray on Mobile) */}
        <aside className="lg:w-[370px] xl:w-[390px] shrink-0 bg-white border-t lg:border-t-0 lg:border-l border-slate-200 flex flex-col min-h-0">
          {/* Desktop Tool Rail */}
          <div className="hidden lg:grid grid-cols-7 gap-1 p-2 border-b border-slate-200 bg-slate-50/70 shrink-0">
            {TOOL_TABS.map(({ id, label, icon: Icon }) => {
              const active = activeTab === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    setActiveTab(id);
                    if (id !== 'ai') setBrushActive(false);
                  }}
                  className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                    active
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-white hover:text-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="text-[10px] font-semibold leading-none truncate max-w-full">
                    {label}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Mobile Collapsible Tool Tray Handle */}
          <div className="lg:hidden flex items-center justify-between px-4 py-2 border-b border-slate-100 bg-white shrink-0">
            <span className="text-xs font-bold text-slate-900">
              {TOOL_TABS.find((t) => t.id === activeTab)?.label} Tools
            </span>
            <button
              type="button"
              onClick={() => setMobileSheetOpen((v) => !v)}
              className="text-xs font-semibold text-blue-600 px-2 py-1 rounded-lg hover:bg-blue-50 cursor-pointer"
            >
              {mobileSheetOpen ? 'Hide Panel' : 'Expand Panel'}
            </button>
          </div>

          {/* Scrollable Active Panel Controls */}
          <div
            className={`overflow-y-auto p-4 transition-all ${
              mobileSheetOpen ? 'max-h-[36dvh] lg:max-h-none lg:flex-1' : 'hidden lg:block lg:flex-1'
            }`}
          >
            {renderActivePanel()}
          </div>

          {/* Mobile Ergonomic Bottom Toolbar (All 7 Required Tools) */}
          <nav
            aria-label="Editor tools"
            className="lg:hidden shrink-0 border-t border-slate-200 bg-white px-1.5 py-1.5 flex items-center justify-between gap-1 overflow-x-auto no-scrollbar"
          >
            {TOOL_TABS.map(({ id, label, icon: Icon }) => {
              const active = activeTab === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    setActiveTab(id);
                    setMobileSheetOpen(true);
                    if (id !== 'ai') setBrushActive(false);
                  }}
                  className={`flex-1 min-w-[50px] min-h-[46px] px-1.5 rounded-xl flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                    active ? 'bg-blue-50 text-blue-600' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Icon className="w-[18px] h-[18px] shrink-0" />
                  <span className="text-[10px] font-semibold leading-none whitespace-nowrap">
                    {label}
                  </span>
                </button>
              );
            })}
          </nav>
        </aside>
      </div>

      {/* Unsaved Edits Confirmation Modal */}
      {showLeaveConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900">Leave current edit?</h3>
            <p className="mt-1.5 text-sm text-slate-600">
              Your original photo is safe, but unsaved edits in this session will be cleared if you
              return home.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setShowLeaveConfirm(false)}
                className="min-h-[44px] rounded-xl border border-slate-200 bg-white text-slate-800 text-sm font-semibold hover:bg-slate-50 cursor-pointer"
              >
                Keep Editing
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLeaveConfirm(false);
                  onBack();
                }}
                className="min-h-[44px] rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 cursor-pointer"
              >
                Return Home
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      <ExportModal
        open={showExport}
        snapshot={present}
        originalName={sourcePhoto.name}
        onClose={() => setShowExport(false)}
      />

      {/* Fullscreen Lightbox */}
      <FullscreenModal
        open={showFullscreen}
        originalUrl={sourcePhoto.dataUrl}
        editedUrl={previewDataUrl}
        hasTransparency={hasTransparency}
        onClose={() => setShowFullscreen(false)}
      />
    </div>
  );
};
