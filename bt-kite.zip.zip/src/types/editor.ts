export interface ColorAdjustments {
  exposure: number; // -100 to 100
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  highlights: number; // -100 to 100
  shadows: number; // -100 to 100
  whites: number; // -100 to 100
  blacks: number; // -100 to 100
  saturation: number; // -100 to 100
  vibrance: number; // -100 to 100
  temperature: number; // -100 to 100
  tint: number; // -100 to 100
  sharpness: number; // 0 to 100
  clarity: number; // -100 to 100
  colorBalance: number; // -100 to 100
  skinTone: number; // -100 to 100
  noiseReduction: number; // 0 to 100
}

export type ColorStyleId =
  | 'none'
  | 'natural'
  | 'cinematic'
  | 'professional-portrait'
  | 'hdr'
  | 'warm'
  | 'cool'
  | 'luxury'
  | 'wedding'
  | 'film'
  | 'vintage'
  | 'modern'
  | 'vibrant'
  | 'moody'
  | 'soft'
  | 'golden-hour';

export type BackgroundCategoryId =
  | 'original'
  | 'transparent'
  | 'professional-studio'
  | 'passport-id'
  | 'office'
  | 'wedding'
  | 'luxury'
  | 'nature'
  | 'mountains'
  | 'beach'
  | 'sunset'
  | 'city'
  | 'cinematic'
  | 'fashion'
  | 'business-portrait'
  | 'product-photography'
  | 'luxury-terrace'
  | 'architectural-stairs'
  | 'custom-upload'
  | 'custom-ai';

export type SubjectPose =
  | 'standing'
  | 'sitting'
  | 'walking'
  | 'lying_down'
  | 'leaning'
  | 'posing'
  | 'object_still_life';

export type SubjectPosition = 'left' | 'center-left' | 'center' | 'center-right' | 'right';

export type CameraAngle = 'eye-level' | 'slightly-elevated' | 'low-angle' | 'overhead';

export type CameraDistance = 'close-up' | 'medium-shot' | 'full-body' | 'wide-shot';

export type LightingDirection =
  | 'left'
  | 'right'
  | 'top-left'
  | 'top-right'
  | 'front-diffused'
  | 'backlit';

export interface CutoutGeometry {
  minX: number; // 0..1
  maxX: number; // 0..1
  minY: number; // 0..1
  maxY: number; // 0..1 (ground contact line)
  centerX: number; // 0..1
  widthRatio: number; // 0..1
  heightRatio: number; // 0..1
  contactMinX: number; // 0..1 footprint at bottom 7%
  contactMaxX: number; // 0..1
  isGroundedInFrame: boolean; // true when feet/base stop inside the frame (not cropped at bottom)
}

export interface RecommendedBackgroundItem {
  id: BackgroundCategoryId;
  name: string;
  reason: string;
  matchScore: number; // 0..100
}

export interface BackgroundBlendSettings {
  lightMatch: number; // 0 to 100
  colorMatch: number; // 0 to 100
  shadowDepth: number; // 0 to 100
  backgroundBlur: number; // 0 to 100
  edgeRefine: number; // 0 to 100
  subjectScale: number; // 75 to 125 (%) — default 100 preserves exact original size & position
  horizonShift: number; // -35 to +35 (%) vertical perspective/ground alignment
  lightingDirection: LightingDirection;
}

export interface BackgroundState {
  categoryId: BackgroundCategoryId;
  customImageUrl: string | null;
  passportColor: string;
  blend: BackgroundBlendSettings;
}

export interface TransformState {
  rotation: number; // 0, 90, 180, 270
  flipH: boolean;
  flipV: boolean;
}

export interface CropRect {
  x: number; // 0 to 1 normalized
  y: number; // 0 to 1 normalized
  width: number; // 0 to 1 normalized
  height: number; // 0 to 1 normalized
}

export interface TextLayer {
  id: string;
  text: string;
  x: number; // 0 to 100 (%)
  y: number; // 0 to 100 (%)
  fontSize: number; // 14 to 72
  color: string;
  fontFamily: 'Plus Jakarta Sans' | 'DM Sans' | 'Georgia' | 'JetBrains Mono';
  align: 'left' | 'center' | 'right';
  bgStyle: 'none' | 'solid' | 'glass';
}

export interface StickerLayer {
  id: string;
  stickerId: string;
  x: number; // 0 to 100 (%)
  y: number; // 0 to 100 (%)
  scale: number; // 0.4 to 2.2
  rotation: number; // -180 to 180
}

export interface EditorSnapshot {
  baseImageUrl: string;
  cutoutImageUrl: string | null;
  background: BackgroundState;
  adjustments: ColorAdjustments;
  styleId: ColorStyleId;
  styleIntensity: number; // 0 to 100
  transform: TransformState;
  textLayers: TextLayer[];
  stickerLayers: StickerLayer[];
  label: string;
}

export interface SourcePhoto {
  id: string;
  name: string;
  dataUrl: string;
  width: number;
  height: number;
  mimeType: string;
}

export interface PhotoAnalysisResult {
  engine: 'gemini-vision' | 'local-vision';
  photoCategory: string;
  subjectDescription: string;
  pose: SubjectPose;
  poseDetail: string;
  subjectPosition: SubjectPosition;
  cameraAngle: CameraAngle;
  cameraDistance: CameraDistance;
  lightingDirection: LightingDirection;
  lightingType: string;
  originalEnvironment: string;
  horizonY: number; // 0.2 to 0.8
  groundLevelY: number; // 0.55 to 1.0
  lightingDiagnosis: string;
  recommendedBackgroundId: BackgroundCategoryId;
  backgroundReason: string;
  recommendedBackgrounds: RecommendedBackgroundItem[];
  recommendedStyleId: ColorStyleId;
  adjustments: ColorAdjustments;
}

export interface AIStatus {
  localNeuralBgRemoval: boolean;
  localColorAndEnhance: boolean;
  localBrushObjectRemoval: boolean;
  geminiVisionAvailable: boolean;
  paidGenerativeImageAvailable: boolean;
  visionModel: string | null;
  generativeModels: { fast: string; studioHd: string } | null;
}

export interface ProcessingState {
  active: boolean;
  title: string;
  detail: string;
  progress: number; // 0 to 100
  cancellable: boolean;
}

export type ToolTab = 'ai' | 'background' | 'adjust' | 'filters' | 'crop' | 'text' | 'stickers';

export type ExportFormat = 'image/jpeg' | 'image/png' | 'transparent-png';

export const DEFAULT_ADJUSTMENTS: ColorAdjustments = {
  exposure: 0,
  brightness: 0,
  contrast: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  saturation: 0,
  vibrance: 0,
  temperature: 0,
  tint: 0,
  sharpness: 0,
  clarity: 0,
  colorBalance: 0,
  skinTone: 0,
  noiseReduction: 0,
};

export const DEFAULT_BLEND: BackgroundBlendSettings = {
  lightMatch: 68,
  colorMatch: 58,
  shadowDepth: 52,
  backgroundBlur: 18,
  edgeRefine: 46,
  subjectScale: 100,
  horizonShift: 0,
  lightingDirection: 'top-left',
};

export const DEFAULT_BACKGROUND: BackgroundState = {
  categoryId: 'original',
  customImageUrl: null,
  passportColor: '#FFFFFF',
  blend: { ...DEFAULT_BLEND },
};

export const DEFAULT_TRANSFORM: TransformState = {
  rotation: 0,
  flipH: false,
  flipV: false,
};
