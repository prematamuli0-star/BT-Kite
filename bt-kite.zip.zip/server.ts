import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

function getValidApiKey(): string | null {
  const key = process.env.GEMINI_API_KEY?.trim();
  if (!key || key === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return key;
}

function getGenAIClient(): GoogleGenAI | null {
  const apiKey = getValidApiKey();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function isPaidImageApiEnabled(): boolean {
  return Boolean(getValidApiKey() && process.env.BT_KITE_ENABLE_PAID_IMAGE_API === 'true');
}

const VALID_BACKGROUND_IDS = [
  'professional-studio',
  'mountains',
  'luxury-terrace',
  'architectural-stairs',
  'passport-id',
  'office',
  'wedding',
  'luxury',
  'nature',
  'beach',
  'sunset',
  'city',
  'cinematic',
  'fashion',
  'business-portrait',
  'product-photography',
];

const VALID_POSES = [
  'standing',
  'sitting',
  'walking',
  'lying_down',
  'leaning',
  'posing',
  'object_still_life',
];

const VALID_POSITIONS = ['left', 'center-left', 'center', 'center-right', 'right'];
const VALID_ANGLES = ['eye-level', 'slightly-elevated', 'low-angle', 'overhead'];
const VALID_DISTANCES = ['close-up', 'medium-shot', 'full-body', 'wide-shot'];
const VALID_LIGHT_DIRS = ['left', 'right', 'top-left', 'top-right', 'front-diffused', 'backlit'];

const VALID_COLOR_STYLE_IDS = [
  'natural',
  'cinematic',
  'professional-portrait',
  'hdr',
  'warm',
  'cool',
  'luxury',
  'wedding',
  'film',
  'vintage',
  'modern',
  'vibrant',
  'moody',
  'soft',
  'golden-hour',
];

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '30mb' }));

  // Modular AI Capability Status Endpoint
  app.get('/api/ai/status', (_req, res) => {
    const hasKey = Boolean(getValidApiKey());
    const paidImageEnabled = isPaidImageApiEnabled();
    res.json({
      localNeuralBgRemoval: true,
      localColorAndEnhance: true,
      localBrushObjectRemoval: true,
      geminiVisionAvailable: hasKey,
      paidGenerativeImageAvailable: paidImageEnabled,
      visionModel: hasKey ? 'gemini-4-hydrogen' : null,
      generativeModels: paidImageEnabled
        ? { fast: 'gemini-3.1-flash-lite-image', studioHd: 'gemini-nano-banana-2.1' }
        : null,
    });
  });

  // Free-Tier Gemini Vision Analysis for Intelligent Photo Understanding, Background Matching & AI Color Tune
  app.post('/api/ai/analyze-tune', async (req, res) => {
    const ai = getGenAIClient();
    if (!ai) {
      return res.status(503).json({
        fallbackToLocal: true,
        error: 'Gemini Vision API key is not configured. Using BT Kite Local Smart Vision engine.',
      });
    }

    try {
      const { imageBase64, mimeType } = req.body as {
        imageBase64?: string;
        mimeType?: string;
      };

      if (!imageBase64 || typeof imageBase64 !== 'string') {
        return res.status(400).json({ error: 'Missing imageBase64 payload.' });
      }

      const safeMime = mimeType && mimeType.startsWith('image/') ? mimeType : 'image/jpeg';

      const prompt = [
        'You are an expert commercial photographer, retoucher, and colorist inside BT Kite by BT Media Studio.',
        'Inspect this photo in detail BEFORE any background replacement or color edit:',
        '1. Identify the main subject (subjectDescription, e.g. "Person sitting", "Woman standing", "Wireless headphones").',
        `2. Detect the exact pose from: ${VALID_POSES.join(', ')} AND give a concise poseDetail (e.g. "Sitting on stairs", "Standing casual portrait", "Leaning on railing", "Resting on wooden desk").`,
        `3. Detect subjectPosition from: ${VALID_POSITIONS.join(', ')}.`,
        `4. Determine cameraAngle from: ${VALID_ANGLES.join(', ')}.`,
        `5. Determine cameraDistance from: ${VALID_DISTANCES.join(', ')}.`,
        `6. Detect lightingDirection from: ${VALID_LIGHT_DIRS.join(', ')} and concise lightingType (e.g. "Natural daylight", "Overcast diffused", "Golden hour", "Indoor warm light").`,
        '7. Estimate normalized horizonY (20 to 80 representing % from top) and groundLevelY (55 to 100 representing % from top where subject feet/seat/base rest; use 100 if subject is cropped at the bottom frame edge).',
        '8. Describe originalEnvironment concisely (e.g. "Outdoor stone stairs", "Busy city sidewalk", "Home desk").',
        '9. Classify photoCategory from: Portrait, Landscape, Travel, Wedding, Fashion, Casual, Professional, Outdoor, Product, Street, Food, Night.',
        `10. Rank the TOP 5 most realistic, perspective-appropriate backgrounds from: ${VALID_BACKGROUND_IDS.join(', ')}.`,
        '    - If the subject is sitting or on stairs/steps, prioritize backgrounds with natural seating, steps, or elevated viewpoints (architectural-stairs, luxury-terrace, mountains, sunset).',
        '    - If the subject is a standing portrait or headshot, prioritize professional-studio, business-portrait, office, fashion, city.',
        '    - If it is a product/object, prioritize product-photography, luxury, professional-studio.',
        `11. Pick the single best recommendedStyleId from: ${VALID_COLOR_STYLE_IDS.join(', ')}.`,
        '12. Compute subtle, natural integer color adjustments (0 = unchanged, never over-saturated or unnatural):',
        '    exposure (-40..40), brightness (-35..35), contrast (-30..40), highlights (-50..35), shadows (-35..50), whites (-35..35), blacks (-35..35), saturation (-25..30), vibrance (-20..35), temperature (-35..35), tint (-25..25), sharpness (0..45), clarity (-15..35), colorBalance (-25..25), skinTone (-25..25), noiseReduction (0..40).',
      ].join('\n');

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: safeMime,
                data: imageBase64,
              },
            },
            { text: prompt },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              photoCategory: { type: Type.STRING },
              subjectDescription: { type: Type.STRING },
              pose: { type: Type.STRING },
              poseDetail: { type: Type.STRING },
              subjectPosition: { type: Type.STRING },
              cameraAngle: { type: Type.STRING },
              cameraDistance: { type: Type.STRING },
              lightingDirection: { type: Type.STRING },
              lightingType: { type: Type.STRING },
              originalEnvironment: { type: Type.STRING },
              horizonYPct: { type: Type.INTEGER },
              groundLevelYPct: { type: Type.INTEGER },
              lightingDiagnosis: { type: Type.STRING },
              recommendedBackgrounds: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    reason: { type: Type.STRING },
                    matchScore: { type: Type.INTEGER },
                  },
                  required: ['id', 'reason', 'matchScore'],
                },
              },
              recommendedStyleId: { type: Type.STRING },
              adjustments: {
                type: Type.OBJECT,
                properties: {
                  exposure: { type: Type.INTEGER },
                  brightness: { type: Type.INTEGER },
                  contrast: { type: Type.INTEGER },
                  highlights: { type: Type.INTEGER },
                  shadows: { type: Type.INTEGER },
                  whites: { type: Type.INTEGER },
                  blacks: { type: Type.INTEGER },
                  saturation: { type: Type.INTEGER },
                  vibrance: { type: Type.INTEGER },
                  temperature: { type: Type.INTEGER },
                  tint: { type: Type.INTEGER },
                  sharpness: { type: Type.INTEGER },
                  clarity: { type: Type.INTEGER },
                  colorBalance: { type: Type.INTEGER },
                  skinTone: { type: Type.INTEGER },
                  noiseReduction: { type: Type.INTEGER },
                },
                required: [
                  'exposure',
                  'brightness',
                  'contrast',
                  'highlights',
                  'shadows',
                  'whites',
                  'blacks',
                  'saturation',
                  'vibrance',
                  'temperature',
                  'tint',
                  'sharpness',
                  'clarity',
                  'colorBalance',
                  'skinTone',
                  'noiseReduction',
                ],
              },
            },
            required: [
              'photoCategory',
              'subjectDescription',
              'pose',
              'poseDetail',
              'subjectPosition',
              'cameraAngle',
              'cameraDistance',
              'lightingDirection',
              'lightingType',
              'originalEnvironment',
              'horizonYPct',
              'groundLevelYPct',
              'lightingDiagnosis',
              'recommendedBackgrounds',
              'recommendedStyleId',
              'adjustments',
            ],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        return res.status(502).json({
          fallbackToLocal: true,
          error: 'Empty analysis response from Gemini Vision.',
        });
      }

      const parsed = JSON.parse(rawText);
      const clamp = (v: unknown, min: number, max: number) =>
        Math.max(min, Math.min(max, Math.round(Number(v) || 0)));

      const rawRecs = Array.isArray(parsed.recommendedBackgrounds)
        ? parsed.recommendedBackgrounds
        : [];
      const seen = new Set<string>();
      const validRecs = rawRecs
        .filter((r: { id?: string }) => r?.id && VALID_BACKGROUND_IDS.includes(r.id) && !seen.has(r.id) && (seen.add(r.id), true))
        .slice(0, 5)
        .map((r: { id: string; reason?: string; matchScore?: number }, idx: number) => ({
          id: r.id,
          name: r.id,
          reason: String(r.reason || 'Matches subject composition, perspective, and lighting.'),
          matchScore: clamp(r.matchScore ?? 96 - idx * 4, 65, 99),
        }));

      const topBgId = validRecs[0]?.id || 'professional-studio';
      const styleId = VALID_COLOR_STYLE_IDS.includes(parsed.recommendedStyleId)
        ? parsed.recommendedStyleId
        : 'natural';

      const a = parsed.adjustments || {};

      return res.json({
        engine: 'gemini-vision',
        photoCategory: String(parsed.photoCategory || 'Portrait'),
        subjectDescription: String(parsed.subjectDescription || 'Main subject'),
        pose: VALID_POSES.includes(parsed.pose) ? parsed.pose : 'standing',
        poseDetail: String(parsed.poseDetail || 'Natural pose'),
        subjectPosition: VALID_POSITIONS.includes(parsed.subjectPosition)
          ? parsed.subjectPosition
          : 'center',
        cameraAngle: VALID_ANGLES.includes(parsed.cameraAngle)
          ? parsed.cameraAngle
          : 'eye-level',
        cameraDistance: VALID_DISTANCES.includes(parsed.cameraDistance)
          ? parsed.cameraDistance
          : 'medium-shot',
        lightingDirection: VALID_LIGHT_DIRS.includes(parsed.lightingDirection)
          ? parsed.lightingDirection
          : 'top-left',
        lightingType: String(parsed.lightingType || 'Natural daylight'),
        originalEnvironment: String(parsed.originalEnvironment || 'Original scene'),
        horizonY: clamp(parsed.horizonYPct ?? 50, 20, 80) / 100,
        groundLevelY: clamp(parsed.groundLevelYPct ?? 92, 55, 100) / 100,
        lightingDiagnosis: String(
          parsed.lightingDiagnosis || 'Balanced exposure, tonal range, and natural color harmony.'
        ),
        recommendedBackgroundId: topBgId,
        backgroundReason:
          validRecs[0]?.reason || 'Matches subject pose, perspective, and lighting direction.',
        recommendedBackgrounds: validRecs,
        recommendedStyleId: styleId,
        adjustments: {
          exposure: clamp(a.exposure, -40, 40),
          brightness: clamp(a.brightness, -35, 35),
          contrast: clamp(a.contrast, -30, 40),
          highlights: clamp(a.highlights, -50, 35),
          shadows: clamp(a.shadows, -35, 50),
          whites: clamp(a.whites, -35, 35),
          blacks: clamp(a.blacks, -35, 35),
          saturation: clamp(a.saturation, -25, 30),
          vibrance: clamp(a.vibrance, -20, 35),
          temperature: clamp(a.temperature, -35, 35),
          tint: clamp(a.tint, -25, 25),
          sharpness: clamp(a.sharpness, 0, 45),
          clarity: clamp(a.clarity, -15, 35),
          colorBalance: clamp(a.colorBalance, -25, 25),
          skinTone: clamp(a.skinTone, -25, 25),
          noiseReduction: clamp(a.noiseReduction, 0, 40),
        },
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Gemini analysis failed';
      return res.status(503).json({
        fallbackToLocal: true,
        error: `Gemini Vision unavailable (${message}). Falling back to local analysis.`,
      });
    }
  });

  // Modular Optional Paid Gemini Generative Image Editing Endpoint
  app.post('/api/ai/generative-edit', async (req, res) => {
    if (!isPaidImageApiEnabled()) {
      return res.status(402).json({
        requiresPaidApiKey: true,
        error:
          'Custom generative image synthesis requires a billing-enabled GEMINI_API_KEY and BT_KITE_ENABLE_PAID_IMAGE_API=true on the server. Use our free Neural Background Replacement, Studio Backdrop Match, or Custom Backdrop Upload anytime.',
      });
    }

    const ai = getGenAIClient();
    if (!ai) {
      return res.status(402).json({
        requiresPaidApiKey: true,
        error: 'No Gemini API key configured on the server.',
      });
    }

    try {
      const { imageBase64, mimeType, prompt, qualityMode } = req.body as {
        imageBase64?: string;
        mimeType?: string;
        prompt?: string;
        qualityMode?: 'fast' | 'studio_hd';
      };

      if (!imageBase64 || !prompt) {
        return res.status(400).json({ error: 'imageBase64 and prompt are required.' });
      }

      const model =
        qualityMode === 'studio_hd' ? 'gemini-nano-banana-2.1' : 'gemini-3.1-flash-lite-image';

      const response = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                data: imageBase64,
                mimeType: mimeType && mimeType.startsWith('image/') ? mimeType : 'image/jpeg',
              },
            },
            { text: prompt },
          ],
        },
        config:
          qualityMode === 'studio_hd'
            ? { imageConfig: { imageSize: '2K' } }
            : undefined,
      });

      let imageUrl: string | null = null;
      for (const part of response.candidates?.[0]?.content?.parts ?? []) {
        if (part.inlineData?.data) {
          const outMime = part.inlineData.mimeType ?? 'image/png';
          imageUrl = `data:${outMime};base64,${part.inlineData.data}`;
          break;
        }
      }

      if (!imageUrl) {
        return res.status(502).json({ error: 'Model did not return an edited image.' });
      }

      return res.json({ imageUrl, model });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Generative edit failed';
      return res.status(500).json({ error: message });
    }
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distDir, 'index.html');
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(404).send('Build output not found. Run npm run build.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BT Kite server listening on http://0.0.0.0:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start BT Kite server:', err);
  process.exit(1);
});
