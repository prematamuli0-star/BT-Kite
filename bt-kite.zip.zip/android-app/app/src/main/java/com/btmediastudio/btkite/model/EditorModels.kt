package com.btmediastudio.btkite.model

import android.graphics.Bitmap

data class ColorAdjustments(
    val exposure: Int = 0,       // -100..100
    val brightness: Int = 0,     // -100..100
    val contrast: Int = 0,       // -100..100
    val highlights: Int = 0,     // -100..100
    val shadows: Int = 0,        // -100..100
    val whites: Int = 0,         // -100..100
    val blacks: Int = 0,         // -100..100
    val saturation: Int = 0,     // -100..100
    val vibrance: Int = 0,       // -100..100
    val temperature: Int = 0,    // -100..100
    val tint: Int = 0,           // -100..100
    val sharpness: Int = 0,      // 0..100
    val clarity: Int = 0,        // -100..100
    val colorBalance: Int = 0,   // -100..100
    val skinTone: Int = 0,       // -100..100
    val noiseReduction: Int = 0, // 0..100
) {
    fun hasAnyEffect(): Boolean =
        exposure != 0 || brightness != 0 || contrast != 0 || highlights != 0 ||
            shadows != 0 || whites != 0 || blacks != 0 || saturation != 0 ||
            vibrance != 0 || temperature != 0 || tint != 0 || sharpness != 0 ||
            clarity != 0 || colorBalance != 0 || skinTone != 0 || noiseReduction != 0
}

enum class ColorStyleId(val displayName: String, val tagline: String) {
    NONE("Original", "No style overlay"),
    NATURAL("Natural", "True-to-life balanced tone"),
    CINEMATIC("Cinematic", "Filmic contrast & cool depth"),
    PROFESSIONAL_PORTRAIT("Pro Portrait", "Flattering skin & soft lift"),
    HDR("HDR", "Expanded dynamic range"),
    WARM("Warm", "Inviting sunlit amber"),
    COOL("Cool", "Crisp Nordic azure"),
    LUXURY("Luxury", "Rich editorial champagne"),
    WEDDING("Wedding", "Airy luminous highlights"),
    FILM("Film", "Analog 35mm tonal curve"),
    VINTAGE("Vintage", "Warm faded emulsion"),
    MODERN("Modern", "Clean commercial contrast"),
    VIBRANT("Vibrant", "Lively color pop"),
    MOODY("Moody", "Deep dramatic shadows"),
    SOFT("Soft", "Gentle diffused glow"),
    GOLDEN_HOUR("Golden Hour", "Luminous sunset glow"),
}

enum class BackgroundCategoryId(val id: String) {
    ORIGINAL("original"),
    TRANSPARENT("transparent"),
    PROFESSIONAL_STUDIO("professional-studio"),
    MOUNTAINS("mountains"),
    LUXURY_TERRACE("luxury-terrace"),
    ARCHITECTURAL_STAIRS("architectural-stairs"),
    OFFICE("office"),
    SUNSET("sunset"),
    CITY("city"),
    WEDDING("wedding"),
    PASSPORT_ID("passport-id"),
    LUXURY("luxury"),
    NATURE("nature"),
    BEACH("beach"),
    CINEMATIC("cinematic"),
    FASHION("fashion"),
    BUSINESS_PORTRAIT("business-portrait"),
    PRODUCT_PHOTOGRAPHY("product-photography"),
    CUSTOM_UPLOAD("custom-upload");

    companion object {
        fun fromId(raw: String): BackgroundCategoryId =
            entries.firstOrNull { it.id == raw } ?: PROFESSIONAL_STUDIO
    }
}

enum class SubjectPose(val label: String) {
    STANDING("Standing"),
    SITTING("Sitting"),
    WALKING("Walking"),
    LYING_DOWN("Lying Down"),
    LEANING("Leaning"),
    POSING("Posing"),
    OBJECT_STILL_LIFE("Object / Product");

    companion object {
        fun fromRaw(raw: String): SubjectPose = when (raw.lowercase()) {
            "sitting" -> SITTING
            "walking" -> WALKING
            "lying_down" -> LYING_DOWN
            "leaning" -> LEANING
            "posing" -> POSING
            "object_still_life" -> OBJECT_STILL_LIFE
            else -> STANDING
        }
    }
}

enum class SubjectPosition(val label: String) {
    LEFT("Left"),
    CENTER_LEFT("Center Left"),
    CENTER("Center"),
    CENTER_RIGHT("Center Right"),
    RIGHT("Right");

    companion object {
        fun fromRaw(raw: String): SubjectPosition = when (raw.lowercase()) {
            "left" -> LEFT
            "center-left" -> CENTER_LEFT
            "center-right" -> CENTER_RIGHT
            "right" -> RIGHT
            else -> CENTER
        }
    }
}

enum class CameraAngle(val label: String) {
    EYE_LEVEL("Eye Level"),
    SLIGHTLY_ELEVATED("Slightly Elevated"),
    LOW_ANGLE("Low Angle"),
    OVERHEAD("Overhead");

    companion object {
        fun fromRaw(raw: String): CameraAngle = when (raw.lowercase()) {
            "slightly-elevated" -> SLIGHTLY_ELEVATED
            "low-angle" -> LOW_ANGLE
            "overhead" -> OVERHEAD
            else -> EYE_LEVEL
        }
    }
}

enum class CameraDistance(val label: String) {
    CLOSE_UP("Close-Up"),
    MEDIUM_SHOT("Medium Shot"),
    FULL_BODY("Full Body"),
    WIDE_SHOT("Wide Shot");

    companion object {
        fun fromRaw(raw: String): CameraDistance = when (raw.lowercase()) {
            "close-up" -> CLOSE_UP
            "full-body" -> FULL_BODY
            "wide-shot" -> WIDE_SHOT
            else -> MEDIUM_SHOT
        }
    }
}

enum class LightingDirection(val label: String) {
    TOP_LEFT("Top Left"),
    TOP_RIGHT("Top Right"),
    LEFT("Left"),
    RIGHT("Right"),
    FRONT_DIFFUSED("Diffused"),
    BACKLIT("Backlit");

    companion object {
        fun fromRaw(raw: String): LightingDirection = when (raw.lowercase()) {
            "top-right" -> TOP_RIGHT
            "left" -> LEFT
            "right" -> RIGHT
            "front-diffused" -> FRONT_DIFFUSED
            "backlit" -> BACKLIT
            else -> TOP_LEFT
        }
    }
}

data class CutoutGeometry(
    val minX: Float,
    val maxX: Float,
    val minY: Float,
    val maxY: Float,
    val centerX: Float,
    val widthRatio: Float,
    val heightRatio: Float,
    val contactMinX: Float,
    val contactMaxX: Float,
    val isGroundedInFrame: Boolean,
)

data class RecommendedBackgroundItem(
    val categoryId: BackgroundCategoryId,
    val name: String,
    val reason: String,
    val matchScore: Int,
)

data class BackgroundBlendSettings(
    val lightMatch: Int = 70,
    val colorMatch: Int = 58,
    val shadowDepth: Int = 52,
    val backgroundBlur: Int = 18,
    val edgeRefine: Int = 50,
    val subjectScale: Int = 100, // 75..125 — 100 preserves exact original position & size
    val horizonShift: Int = 0,   // -35..+35 vertical perspective & horizon alignment
    val lightingDirection: LightingDirection = LightingDirection.TOP_LEFT,
)

data class BackgroundState(
    val categoryId: BackgroundCategoryId = BackgroundCategoryId.ORIGINAL,
    val customBackdropBitmap: Bitmap? = null,
    val passportColorArgb: Int = 0xFFFFFFFF.toInt(),
    val blend: BackgroundBlendSettings = BackgroundBlendSettings(),
)

data class TransformState(
    val rotationDegrees: Int = 0, // 0, 90, 180, 270
    val flipH: Boolean = false,
    val flipV: Boolean = false,
)

data class CropRect(
    val x: Float = 0f,
    val y: Float = 0f,
    val width: Float = 1f,
    val height: Float = 1f,
) {
    val isDirty: Boolean
        get() = x > 0.005f || y > 0.005f || width < 0.995f || height < 0.995f
}

enum class TextBgStyle(val label: String) {
    NONE("Shadow"),
    SOLID("Solid Dark"),
    GLASS("Frosted"),
}

data class TextLayer(
    val id: String,
    val text: String,
    val xPct: Float = 50f,
    val yPct: Float = 82f,
    val fontSizeSp: Float = 28f,
    val colorArgb: Int = 0xFFFFFFFF.toInt(),
    val bgStyle: TextBgStyle = TextBgStyle.SOLID,
)

data class StickerLayer(
    val id: String,
    val stickerId: String,
    val xPct: Float = 50f,
    val yPct: Float = 26f,
    val scale: Float = 1f,
    val rotationDeg: Float = 0f,
)

data class PhotoAnalysisResult(
    val engineLabel: String,
    val photoCategory: String,
    val subjectDescription: String,
    val pose: SubjectPose,
    val poseDetail: String,
    val subjectPosition: SubjectPosition,
    val cameraAngle: CameraAngle,
    val cameraDistance: CameraDistance,
    val lightingDirection: LightingDirection,
    val lightingType: String,
    val originalEnvironment: String,
    val horizonY: Float,
    val groundLevelY: Float,
    val lightingDiagnosis: String,
    val recommendedBackgroundId: BackgroundCategoryId,
    val recommendedBackgrounds: List<RecommendedBackgroundItem>,
    val recommendedStyleId: ColorStyleId,
    val adjustments: ColorAdjustments,
)

data class EditorSnapshot(
    val baseBitmap: Bitmap,
    val cutoutBitmap: Bitmap? = null,
    val background: BackgroundState = BackgroundState(),
    val adjustments: ColorAdjustments = ColorAdjustments(),
    val styleId: ColorStyleId = ColorStyleId.NONE,
    val styleIntensity: Int = 85,
    val transform: TransformState = TransformState(),
    val textLayers: List<TextLayer> = emptyList(),
    val stickerLayers: List<StickerLayer> = emptyList(),
    val label: String = "Original",
)

enum class ToolTab(val label: String) {
    AI("AI"),
    BACKGROUND("Background"),
    ADJUST("Adjust"),
    FILTERS("Filters"),
    CROP("Crop"),
    TEXT("Text"),
    STICKERS("Stickers"),
}

enum class ExportFormat(val label: String, val extension: String, val mimeType: String) {
    JPEG("High-Res JPG", "jpg", "image/jpeg"),
    PNG("Lossless PNG", "png", "image/png"),
    TRANSPARENT_PNG("Cutout Transparent PNG", "png", "image/png"),
}

data class ProcessingStatus(
    val active: Boolean = false,
    val title: String = "",
    val detail: String = "",
    val progress: Float = 0f,
)
