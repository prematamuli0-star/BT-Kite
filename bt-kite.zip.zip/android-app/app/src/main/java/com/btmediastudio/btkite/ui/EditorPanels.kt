package com.btmediastudio.btkite.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FaceRetouchingNatural
import androidx.compose.material.icons.rounded.Flip
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Rotate90DegreesCcw
import androidx.compose.material.icons.rounded.Rotate90DegreesCw
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btmediastudio.btkite.data.BackgroundPreset
import com.btmediastudio.btkite.data.StudioPresets
import com.btmediastudio.btkite.engine.ImageEngine
import com.btmediastudio.btkite.model.BackgroundBlendSettings
import com.btmediastudio.btkite.model.BackgroundCategoryId
import com.btmediastudio.btkite.model.BackgroundState
import com.btmediastudio.btkite.model.ColorAdjustments
import com.btmediastudio.btkite.model.ColorStyleId
import com.btmediastudio.btkite.model.LightingDirection
import com.btmediastudio.btkite.model.PhotoAnalysisResult
import com.btmediastudio.btkite.model.StickerLayer
import com.btmediastudio.btkite.model.TextBgStyle
import com.btmediastudio.btkite.model.TextLayer
import com.btmediastudio.btkite.ui.theme.InkMuted
import com.btmediastudio.btkite.ui.theme.InkPrimary
import com.btmediastudio.btkite.ui.theme.InkSecondary
import com.btmediastudio.btkite.ui.theme.KiteBlue
import com.btmediastudio.btkite.ui.theme.KiteBlueBorder
import com.btmediastudio.btkite.ui.theme.KiteBlueSoft
import com.btmediastudio.btkite.ui.theme.StudioBorder
import com.btmediastudio.btkite.ui.theme.StudioCanvasBg
import com.btmediastudio.btkite.ui.theme.StudioWhite
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun StudioSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    suffix: String = "",
    signed: Boolean = false,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
) {
    val intVal = value.roundToInt()
    val formatted = buildString {
        if (signed && intVal > 0) append("+")
        append(intVal)
        append(suffix)
    }
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = InkSecondary)
            Text(
                text = formatted,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = KiteBlue,
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = onValueChangeFinished,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = KiteBlue,
                activeTrackColor = KiteBlue,
                inactiveTrackColor = StudioBorder,
            ),
        )
    }
}

@Composable
fun AIPanelContent(
    analysis: PhotoAnalysisResult?,
    brushActive: Boolean,
    brushSizePx: Float,
    hasBrushStrokes: Boolean,
    onAutoBackground: () -> Unit,
    onAIColorTune: () -> Unit,
    onAIEnhance: () -> Unit,
    onPortraitEnhance: () -> Unit,
    onOpenBackgrounds: () -> Unit,
    onToggleBrush: (Boolean) -> Unit,
    onBrushSizeChange: (Float) -> Unit,
    onClearBrush: () -> Unit,
    onApplyBrushRemoval: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = onAutoBackground,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
        ) {
            Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Auto Background (1-Tap)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        OutlinedButton(
            onClick = onAIColorTune,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, KiteBlueBorder),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = KiteBlueSoft, contentColor = KiteBlue),
        ) {
            Icon(Icons.Rounded.Palette, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("AI Color Tune (Auto 16 Sliders)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StudioActionTile(
                modifier = Modifier.weight(1f),
                title = "AI Enhance",
                subtitle = "Clarity & denoise",
                icon = Icons.Rounded.Tune,
                active = false,
                onClick = onAIEnhance,
            )
            StudioActionTile(
                modifier = Modifier.weight(1f),
                title = "Portrait Enhance",
                subtitle = "Natural skin lift",
                icon = Icons.Rounded.FaceRetouchingNatural,
                active = false,
                onClick = onPortraitEnhance,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StudioActionTile(
                modifier = Modifier.weight(1f),
                title = "Object Removal",
                subtitle = if (brushActive) "Paint on photo" else "Brush to heal",
                icon = Icons.Rounded.Brush,
                active = brushActive,
                onClick = { onToggleBrush(!brushActive) },
            )
            StudioActionTile(
                modifier = Modifier.weight(1f),
                title = "AI BG Styles",
                subtitle = "16 scenes + matches",
                icon = Icons.Rounded.ContentCut,
                active = false,
                onClick = onOpenBackgrounds,
            )
        }

        if (brushActive) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = StudioCanvasBg,
                border = BorderStroke(1.dp, KiteBlueBorder),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Object Removal Brush", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                        TextButton(onClick = { onToggleBrush(false) }) { Text("Done", fontSize = 12.sp) }
                    }
                    Text(
                        "Paint over unwanted objects directly on the photo, then tap Remove Object.",
                        fontSize = 11.sp,
                        color = InkSecondary,
                    )
                    StudioSliderRow(
                        label = "Brush Size",
                        value = brushSizePx,
                        range = 14f..72f,
                        suffix = "px",
                        onValueChange = onBrushSizeChange,
                        onValueChangeFinished = {},
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onClearBrush,
                            enabled = hasBrushStrokes,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text("Clear", fontSize = 12.sp)
                        }
                        Button(
                            onClick = onApplyBrushRemoval,
                            enabled = hasBrushStrokes,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
                        ) {
                            Text("Remove Object", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (analysis != null) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = StudioCanvasBg,
                border = BorderStroke(1.dp, StudioBorder),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Photo Analysis", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                        Text("${analysis.photoCategory} · ${analysis.engineLabel}", fontSize = 11.sp, color = InkMuted)
                    }
                    Text(
                        "${analysis.subjectDescription} · ${analysis.poseDetail}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = InkPrimary,
                    )
                    Text(
                        "${analysis.subjectPosition.label} · ${analysis.cameraDistance.label} · ${analysis.lightingDirection.label} light",
                        fontSize = 11.sp,
                        color = InkSecondary,
                    )
                    Text(analysis.lightingDiagnosis, fontSize = 11.sp, color = InkMuted)
                }
            }
        }
    }
}

@Composable
private fun StudioActionTile(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (active) KiteBlueSoft else StudioWhite,
        border = BorderStroke(1.dp, if (active) KiteBlue else StudioBorder),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = KiteBlue, modifier = Modifier.size(18.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
            Text(subtitle, fontSize = 11.sp, color = InkMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackgroundPanelContent(
    background: BackgroundState,
    hasCutout: Boolean,
    analysis: PhotoAnalysisResult?,
    analyzingScene: Boolean,
    onRefreshAnalysis: () -> Unit,
    onAutoBackground: () -> Unit,
    onSelectCategory: (BackgroundCategoryId) -> Unit,
    onPickCustomBackdrop: () -> Unit,
    onSelectPassportColor: (Int) -> Unit,
    onApplyPromptMatch: (String) -> Unit,
    onUpdateBlend: (Boolean, (BackgroundBlendSettings) -> BackgroundBlendSettings) -> Unit,
) {
    var promptText by remember {
        mutableStateOf("Replace with a professional studio or scenic outdoor backdrop with soft lighting and natural shadows.")
    }
    val isReplaced = hasCutout &&
        background.categoryId != BackgroundCategoryId.ORIGINAL &&
        background.categoryId != BackgroundCategoryId.TRANSPARENT

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = onAutoBackground,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
        ) {
            Icon(Icons.Rounded.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Auto Background", fontWeight = FontWeight.Bold)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { onSelectCategory(BackgroundCategoryId.TRANSPARENT) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
            ) {
                Text("Transparent", fontSize = 11.sp, maxLines = 1)
            }
            OutlinedButton(
                onClick = onPickCustomBackdrop,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
            ) {
                Icon(Icons.Rounded.Upload, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("My Photo", fontSize = 11.sp, maxLines = 1)
            }
            OutlinedButton(
                onClick = { onSelectCategory(BackgroundCategoryId.ORIGINAL) },
                enabled = background.categoryId != BackgroundCategoryId.ORIGINAL,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
            ) {
                Text("Original", fontSize = 11.sp, maxLines = 1)
            }
        }

        // Photo Analysis Preview Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = StudioCanvasBg,
            border = BorderStroke(1.dp, StudioBorder),
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Photo Analysis", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    TextButton(
                        onClick = onRefreshAnalysis,
                        enabled = !analyzingScene,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (analyzingScene) "Analyzing..." else "Refresh", fontSize = 11.sp)
                    }
                }
                if (analysis != null) {
                    AnalysisKvRow("Subject", "${analysis.subjectDescription} · ${analysis.poseDetail}")
                    AnalysisKvRow("Position", "${analysis.subjectPosition.label} · ${analysis.cameraDistance.label} · ${analysis.cameraAngle.label}")
                    AnalysisKvRow("Lighting", "${analysis.lightingDirection.label} · ${analysis.lightingType}")
                    AnalysisKvRow("Photo Style", analysis.photoCategory)
                    HorizontalDivider(color = StudioBorder)
                    AnalysisKvRow(
                        label = "Top Match",
                        value = StudioPresets.presetFor(analysis.recommendedBackgroundId).name,
                        highlight = true,
                    )
                } else {
                    Text("Analyzing pose, perspective, and lighting direction...", fontSize = 11.sp, color = InkMuted)
                }
            }
        }

        // Top 5 AI Recommended Backgrounds
        if (analysis != null && analysis.recommendedBackgrounds.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Recommended for This Photo", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    Text("Top 5 matches", fontSize = 11.sp, color = InkMuted)
                }
                analysis.recommendedBackgrounds.forEachIndexed { idx, rec ->
                    val preset = StudioPresets.presetFor(rec.categoryId)
                    val selected = background.categoryId == rec.categoryId
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (selected) KiteBlueSoft else StudioWhite,
                        border = BorderStroke(1.dp, if (selected) KiteBlue else StudioBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectCategory(rec.categoryId) },
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            BackdropThumb(preset = preset, modifier = Modifier.size(width = 52.dp, height = 40.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        "${idx + 1}. ${preset.name}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = InkPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Text(
                                        "${rec.matchScore}%",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = KiteBlue,
                                    )
                                }
                                Text(rec.reason, fontSize = 11.sp, color = InkMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }

        // Passport Color Swatches
        if (background.categoryId == BackgroundCategoryId.PASSPORT_ID) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = StudioCanvasBg,
                border = BorderStroke(1.dp, StudioBorder),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Passport / ID Color", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StudioPresets.passportColors.forEach { (_, hex) ->
                            val active = background.passportColorArgb == hex
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(hex))
                                    .border(
                                        width = if (active) 2.dp else 1.dp,
                                        color = if (active) KiteBlue else StudioBorder,
                                        shape = RoundedCornerShape(10.dp),
                                    )
                                    .clickable { onSelectPassportColor(hex) },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (active) {
                                    Icon(
                                        Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = if (hex == 0xFF2563EB.toInt()) Color.White else KiteBlue,
                                        modifier = Modifier.size(16.dp),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Perspective, Lighting & Grounded Shadow Controls
        if (isReplaced) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = StudioCanvasBg,
                border = BorderStroke(1.dp, StudioBorder),
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text("Perspective & Blending", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                        Text("Position preserved", fontSize = 11.sp, color = KiteBlue)
                    }
                    StudioSliderRow(
                        label = "Perspective & Horizon Align",
                        value = background.blend.horizonShift.toFloat(),
                        range = -35f..35f,
                        suffix = "%",
                        signed = true,
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(horizonShift = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )
                    StudioSliderRow(
                        label = "Lighting Match",
                        value = background.blend.lightMatch.toFloat(),
                        range = 0f..100f,
                        suffix = "%",
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(lightMatch = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )
                    StudioSliderRow(
                        label = "Color Temperature Match",
                        value = background.blend.colorMatch.toFloat(),
                        range = 0f..100f,
                        suffix = "%",
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(colorMatch = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )
                    StudioSliderRow(
                        label = "Contact & Ground Shadow",
                        value = background.blend.shadowDepth.toFloat(),
                        range = 0f..100f,
                        suffix = "%",
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(shadowDepth = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )
                    StudioSliderRow(
                        label = "Depth-of-Field Blur",
                        value = background.blend.backgroundBlur.toFloat(),
                        range = 0f..100f,
                        suffix = "%",
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(backgroundBlur = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )
                    StudioSliderRow(
                        label = "Hair & Edge Light Wrap",
                        value = background.blend.edgeRefine.toFloat(),
                        range = 0f..100f,
                        suffix = "%",
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(edgeRefine = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )
                    StudioSliderRow(
                        label = "Subject Scale (100% = Original)",
                        value = background.blend.subjectScale.toFloat(),
                        range = 75f..125f,
                        suffix = "%",
                        onValueChange = { v -> onUpdateBlend(false) { it.copy(subjectScale = v.roundToInt()) } },
                        onValueChangeFinished = { onUpdateBlend(true) { it } },
                    )

                    Text("Key Light Direction", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = InkSecondary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        LightingDirection.entries.forEach { dir ->
                            val active = background.blend.lightingDirection == dir
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (active) KiteBlue else StudioWhite,
                                border = BorderStroke(1.dp, if (active) KiteBlue else StudioBorder),
                                modifier = Modifier.clickable {
                                    onUpdateBlend(true) { it.copy(lightingDirection = dir) }
                                },
                            ) {
                                Text(
                                    text = dir.label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (active) Color.White else InkSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                        }
                    }
                }
            }
        }

        // Full 16 Curated Studio Background Styles
        Text("All Studio Background Styles (${StudioPresets.backgroundPresets.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            StudioPresets.backgroundPresets.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    pair.forEach { preset ->
                        val active = background.categoryId == preset.id
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = StudioWhite,
                            border = BorderStroke(if (active) 2.dp else 1.dp, if (active) KiteBlue else StudioBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectCategory(preset.id) },
                        ) {
                            Column {
                                BackdropThumb(preset = preset, modifier = Modifier.fillMaxWidth().height(56.dp))
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(preset.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(preset.shortDesc, fontSize = 10.sp, color = InkMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        // Smart Prompt Match
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = StudioCanvasBg,
            border = BorderStroke(1.dp, StudioBorder),
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Describe Ideal Background", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    minLines = 2,
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp),
                )
                Button(
                    onClick = { onApplyPromptMatch(promptText) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
                ) {
                    Text("Match Studio Backdrop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AnalysisKvRow(label: String, value: String, highlight: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 11.sp, color = InkMuted)
        Spacer(Modifier.width(12.dp))
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.SemiBold,
            color = if (highlight) KiteBlue else InkPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun BackdropThumb(preset: BackgroundPreset, modifier: Modifier) {
    val context = LocalContext.current
    val bmp = produceState<Bitmap?>(initialValue = null, preset.assetPath) {
        value = preset.assetPath?.let { path ->
            withContext(Dispatchers.IO) { runCatching { ImageEngine.loadBitmapFromAsset(context, path) }.getOrNull() }
        }
    }
    val (c0, c1, c2) = preset.gradientColors
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(listOf(Color(c0), Color(c1), Color(c2)))),
    ) {
        bmp.value?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = preset.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
fun AdjustPanelContent(
    adjustments: ColorAdjustments,
    onAIColorTune: () -> Unit,
    onResetAll: () -> Unit,
    onUpdate: (Boolean, (ColorAdjustments) -> ColorAdjustments) -> Unit,
) {
    var activeGroup by remember { mutableStateOf("Light") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = onAIColorTune,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
            ) {
                Text("AI Color Tune", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = onResetAll,
                shape = RoundedCornerShape(12.dp),
            ) {
                Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Reset", fontSize = 12.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("Light", "Color", "Detail").forEach { group ->
                val selected = activeGroup == group
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (selected) KiteBlue else StudioCanvasBg,
                    border = BorderStroke(1.dp, if (selected) KiteBlue else StudioBorder),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeGroup = group },
                ) {
                    Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Text(
                            group,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) Color.White else InkSecondary,
                        )
                    }
                }
            }
        }

        when (activeGroup) {
            "Light" -> {
                StudioSliderRow("Exposure", adjustments.exposure.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(exposure = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Brightness", adjustments.brightness.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(brightness = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Contrast", adjustments.contrast.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(contrast = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Highlights", adjustments.highlights.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(highlights = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Shadows", adjustments.shadows.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(shadows = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Whites", adjustments.whites.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(whites = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Blacks", adjustments.blacks.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(blacks = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
            }
            "Color" -> {
                StudioSliderRow("Saturation", adjustments.saturation.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(saturation = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Vibrance", adjustments.vibrance.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(vibrance = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Temperature", adjustments.temperature.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(temperature = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Tint", adjustments.tint.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(tint = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Color Balance", adjustments.colorBalance.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(colorBalance = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Skin Tone", adjustments.skinTone.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(skinTone = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
            }
            else -> {
                StudioSliderRow("Sharpness", adjustments.sharpness.toFloat(), 0f..100f,
                    onValueChange = { v -> onUpdate(false) { it.copy(sharpness = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Clarity", adjustments.clarity.toFloat(), -100f..100f, signed = true,
                    onValueChange = { v -> onUpdate(false) { it.copy(clarity = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
                StudioSliderRow("Noise Reduction", adjustments.noiseReduction.toFloat(), 0f..100f,
                    onValueChange = { v -> onUpdate(false) { it.copy(noiseReduction = v.roundToInt()) } },
                    onValueChangeFinished = { onUpdate(true) { it } })
            }
        }
    }
}

@Composable
fun FiltersPanelContent(
    selectedStyle: ColorStyleId,
    intensity: Int,
    onSelectStyle: (ColorStyleId) -> Unit,
    onIntensityChange: (Int, Boolean) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selectedStyle != ColorStyleId.NONE) {
            StudioSliderRow(
                label = "Style Strength",
                value = intensity.toFloat(),
                range = 0f..100f,
                suffix = "%",
                onValueChange = { onIntensityChange(it.roundToInt(), false) },
                onValueChangeFinished = { onIntensityChange(intensity, true) },
            )
        }
        ColorStyleId.entries.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { style ->
                    val active = selectedStyle == style
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (active) KiteBlueSoft else StudioWhite,
                        border = BorderStroke(if (active) 2.dp else 1.dp, if (active) KiteBlue else StudioBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectStyle(style) },
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(style.displayName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
                            Text(style.tagline, fontSize = 10.sp, color = InkMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CropPanelContent(
    cropDirty: Boolean,
    onSelectAspect: (Float?) -> Unit,
    onRotate: (Int) -> Unit,
    onFlipH: () -> Unit,
    onFlipV: () -> Unit,
    onApplyCrop: () -> Unit,
    onResetCrop: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Aspect Ratio", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val presets = listOf(
                "Free" to null,
                "1:1" to 1f,
                "4:5" to 0.8f,
                "3:4" to 0.75f,
                "16:9" to (16f / 9f),
                "9:16" to (9f / 16f),
            )
            presets.forEach { (label, ratio) ->
                OutlinedButton(
                    onClick = { onSelectAspect(ratio) },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(label, fontSize = 12.sp)
                }
            }
        }

        Text("Rotate & Flip", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { onRotate(-90) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Rounded.Rotate90DegreesCcw, contentDescription = "Rotate Left", modifier = Modifier.size(18.dp))
            }
            OutlinedButton(onClick = { onRotate(90) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Rounded.Rotate90DegreesCw, contentDescription = "Rotate Right", modifier = Modifier.size(18.dp))
            }
            OutlinedButton(onClick = onFlipH, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Rounded.Flip, contentDescription = "Flip H", modifier = Modifier.size(18.dp))
            }
            OutlinedButton(onClick = onFlipV, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                Text("Flip V", fontSize = 11.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = onResetCrop, enabled = cropDirty, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                Text("Reset Frame", fontSize = 12.sp)
            }
            Button(
                onClick = onApplyCrop,
                enabled = cropDirty,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
            ) {
                Text("Apply Crop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TextPanelContent(
    layers: List<TextLayer>,
    selectedId: String?,
    onAdd: () -> Unit,
    onSelect: (String) -> Unit,
    onUpdate: (String, Boolean, (TextLayer) -> TextLayer) -> Unit,
    onDelete: (String) -> Unit,
) {
    val active = layers.firstOrNull { it.id == selectedId } ?: layers.lastOrNull()
    val textColors = listOf(
        0xFFFFFFFF.toInt(),
        0xFF0F172A.toInt(),
        0xFF2563EB.toInt(),
        0xFFF59E0B.toInt(),
        0xFF10B981.toInt(),
        0xFFEF4444.toInt(),
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Add Text Overlay", fontWeight = FontWeight.Bold)
        }

        if (layers.size > 1) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                layers.forEachIndexed { idx, layer ->
                    val sel = active?.id == layer.id
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (sel) KiteBlueSoft else StudioWhite,
                        border = BorderStroke(1.dp, if (sel) KiteBlue else StudioBorder),
                        modifier = Modifier.clickable { onSelect(layer.id) },
                    ) {
                        Text(
                            text = layer.text.take(14).ifBlank { "Text ${idx + 1}" },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (sel) KiteBlue else InkSecondary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
            }
        }

        if (active != null) {
            OutlinedTextField(
                value = active.text,
                onValueChange = { txt -> onUpdate(active.id, true) { it.copy(text = txt) } },
                label = { Text("Text Content") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Color", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = InkSecondary)
                textColors.forEach { argb ->
                    val sel = active.colorArgb == argb
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(argb))
                            .border(
                                width = if (sel) 2.dp else 1.dp,
                                color = if (sel) KiteBlue else StudioBorder,
                                shape = RoundedCornerShape(8.dp),
                            )
                            .clickable { onUpdate(active.id, true) { it.copy(colorArgb = argb) } },
                    )
                }
            }
            StudioSliderRow(
                label = "Text Size",
                value = active.fontSizeSp,
                range = 16f..68f,
                suffix = "pt",
                onValueChange = { v -> onUpdate(active.id, false) { it.copy(fontSizeSp = v) } },
                onValueChangeFinished = { onUpdate(active.id, true) { it } },
            )
            StudioSliderRow(
                label = "Horizontal Position",
                value = active.xPct,
                range = 10f..90f,
                suffix = "%",
                onValueChange = { v -> onUpdate(active.id, false) { it.copy(xPct = v) } },
                onValueChangeFinished = { onUpdate(active.id, true) { it } },
            )
            StudioSliderRow(
                label = "Vertical Position",
                value = active.yPct,
                range = 10f..90f,
                suffix = "%",
                onValueChange = { v -> onUpdate(active.id, false) { it.copy(yPct = v) } },
                onValueChangeFinished = { onUpdate(active.id, true) { it } },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextBgStyle.entries.forEach { bg ->
                    val sel = active.bgStyle == bg
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (sel) KiteBlue else StudioWhite,
                        border = BorderStroke(1.dp, if (sel) KiteBlue else StudioBorder),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onUpdate(active.id, true) { it.copy(bgStyle = bg) } },
                    ) {
                        Box(Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                            Text(bg.label, fontSize = 11.sp, color = if (sel) Color.White else InkSecondary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            OutlinedButton(
                onClick = { onDelete(active.id) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
            ) {
                Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Delete Selected Text", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StickersPanelContent(
    layers: List<StickerLayer>,
    selectedId: String?,
    onAdd: (String) -> Unit,
    onUpdate: (String, Boolean, (StickerLayer) -> StickerLayer) -> Unit,
    onDelete: (String) -> Unit,
) {
    val active = layers.firstOrNull { it.id == selectedId } ?: layers.lastOrNull()
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Tap to Add Studio Sticker", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InkPrimary)
        StudioPresets.stickers.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { st ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(st.primaryColor),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clickable { onAdd(st.id) },
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(st.badgeText, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(st.accentColor))
                        }
                    }
                }
            }
        }

        if (active != null) {
            HorizontalDivider(color = StudioBorder)
            StudioSliderRow(
                label = "Sticker Scale",
                value = active.scale * 100f,
                range = 50f..200f,
                suffix = "%",
                onValueChange = { v -> onUpdate(active.id, false) { it.copy(scale = v / 100f) } },
                onValueChangeFinished = { onUpdate(active.id, true) { it } },
            )
            StudioSliderRow(
                label = "Horizontal Position",
                value = active.xPct,
                range = 10f..90f,
                suffix = "%",
                onValueChange = { v -> onUpdate(active.id, false) { it.copy(xPct = v) } },
                onValueChangeFinished = { onUpdate(active.id, true) { it } },
            )
            StudioSliderRow(
                label = "Vertical Position",
                value = active.yPct,
                range = 10f..90f,
                suffix = "%",
                onValueChange = { v -> onUpdate(active.id, false) { it.copy(yPct = v) } },
                onValueChangeFinished = { onUpdate(active.id, true) { it } },
            )
            OutlinedButton(
                onClick = { onDelete(active.id) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
            ) {
                Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Remove Sticker", fontSize = 12.sp)
            }
        }
    }
}
