package com.btmediastudio.btkite.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val KiteBlue = Color(0xFF2563EB)
val KiteBlueDark = Color(0xFF1D4ED8)
val KiteBlueSoft = Color(0xFFEFF6FF)
val KiteBlueBorder = Color(0xFFBFDBFE)
val StudioWhite = Color(0xFFFFFFFF)
val StudioCanvasBg = Color(0xFFF8FAFC)
val StudioBorder = Color(0xFFE2E8F0)
val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)
val InkMuted = Color(0xFF64748B)
val ErrorRed = Color(0xFFDC2626)

private val BTKiteColorScheme = lightColorScheme(
    primary = KiteBlue,
    onPrimary = Color.White,
    primaryContainer = KiteBlueSoft,
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = KiteBlueDark,
    onSecondary = Color.White,
    background = StudioCanvasBg,
    onBackground = InkPrimary,
    surface = StudioWhite,
    onSurface = InkPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = InkSecondary,
    outline = StudioBorder,
    error = ErrorRed,
    onError = Color.White,
)

private val BTKiteTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.5).sp,
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp,
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.sp,
        lineHeight = 14.sp,
    ),
)

@Composable
fun BTKiteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = BTKiteColorScheme,
        typography = BTKiteTypography,
        content = content,
    )
}
