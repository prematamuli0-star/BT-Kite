package com.btmediastudio.btkite.data

import com.btmediastudio.btkite.model.BackgroundCategoryId
import com.btmediastudio.btkite.model.CameraAngle
import com.btmediastudio.btkite.model.CameraDistance
import com.btmediastudio.btkite.model.ColorAdjustments
import com.btmediastudio.btkite.model.ColorStyleId
import com.btmediastudio.btkite.model.LightingDirection
import com.btmediastudio.btkite.model.RecommendedBackgroundItem
import com.btmediastudio.btkite.model.SubjectPose
import kotlin.math.abs
import kotlin.math.roundToInt

data class SamplePhotoPreset(
    val id: String,
    val title: String,
    val category: String,
    val subtitle: String,
    val assetPath: String,
)

enum class ProceduralStyle {
    STUDIO_SWEEP,
    PASSPORT,
    LUXURY_MARBLE,
    NATURE_BOKEH,
    MOUNTAIN_MIST,
    BEACH_HORIZON,
    FASHION_EDITORIAL,
    BUSINESS_SLATE,
    PRODUCT_PODIUM,
    CINEMATIC_TEAL,
}

data class BackgroundPreset(
    val id: BackgroundCategoryId,
    val name: String,
    val shortDesc: String,
    val assetPath: String? = null,
    val gradientColors: Triple<Int, Int, Int>,
    val ambientRgb: Triple<Int, Int, Int>,
    val ambientLuminance: Float,
    val defaultBlur: Int,
    val defaultShadow: Int,
    val horizonY: Float,
    val groundY: Float,
    val keyLightDirection: LightingDirection,
    val suitablePoses: Set<SubjectPose>,
    val suitablePhotoTypes: List<String>,
    val supportsSeatingOrSteps: Boolean = false,
    val keywords: List<String>,
    val proceduralStyle: ProceduralStyle? = null,
)

data class StickerPreset(
    val id: String,
    val name: String,
    val badgeText: String,
    val primaryColor: Int,
    val accentColor: Int,
)

data class AutoBlendResult(
    val backgroundBlur: Int,
    val shadowDepth: Int,
    val horizonShift: Int,
    val lightingDirection: LightingDirection,
)

object StudioPresets {

    val samplePhotos: List<SamplePhotoPreset> = listOf(
        SamplePhotoPreset(
            id = "sample-portrait",
            title = "City Street Portrait",
            category = "Portrait",
            subtitle = "Try Auto Background or Portrait Enhance",
            assetPath = "images/sample_portrait_1795251947836.jpg",
        ),
        SamplePhotoPreset(
            id = "sample-product",
            title = "Wireless Headphones",
            category = "Product",
            subtitle = "Try Product Studio & Clean Cutout",
            assetPath = "images/sample_product_1795251949698.jpg",
        ),
        SamplePhotoPreset(
            id = "sample-street",
            title = "Coastal Cafe Street",
            category = "Travel & Street",
            subtitle = "Try AI Color Tune & Golden Hour",
            assetPath = "images/sample_street_golden_1795252046830.jpg",
        ),
    )

    val passportColors: List<Pair<String, Int>> = listOf(
        "Pure White" to 0xFFFFFFFF.toInt(),
        "Studio Ice" to 0xFFF1F5F9.toInt(),
        "ID Blue" to 0xFFDBEAFE.toInt(),
        "Classic Blue" to 0xFF2563EB.toInt(),
        "Soft Gray" to 0xFFCBD5E1.toInt(),
    )

    val backgroundPresets: List<BackgroundPreset> = listOf(
        BackgroundPreset(
            id = BackgroundCategoryId.PROFESSIONAL_STUDIO,
            name = "Professional Studio",
            shortDesc = "Soft diffused studio cyclorama",
            assetPath = "images/bg_studio_pro_1795251948545.jpg",
            gradientColors = Triple(0xFFE2E8F0.toInt(), 0xFFCBD5E1.toInt(), 0xFF94A3B8.toInt()),
            ambientRgb = Triple(232, 238, 246),
            ambientLuminance = 0.78f,
            defaultBlur = 10,
            defaultShadow = 56,
            horizonY = 0.62f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.POSING, SubjectPose.SITTING, SubjectPose.OBJECT_STILL_LIFE),
            suitablePhotoTypes = listOf("Portrait", "Professional", "Fashion", "Product", "Casual"),
            keywords = listOf("studio", "portrait", "clean", "grey", "gray", "backdrop", "soft", "photography"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.MOUNTAINS,
            name = "Mountain Viewpoint",
            shortDesc = "Scenic alpine overlook with stone terrace",
            assetPath = "images/bg_mountain_viewpoint_1795257729702.jpg",
            gradientColors = Triple(0xFFDBEAFE.toInt(), 0xFF93C5FD.toInt(), 0xFF475569.toInt()),
            ambientRgb = Triple(226, 238, 248),
            ambientLuminance = 0.76f,
            defaultBlur = 14,
            defaultShadow = 54,
            horizonY = 0.42f,
            groundY = 0.82f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.SITTING, SubjectPose.STANDING, SubjectPose.LEANING, SubjectPose.POSING, SubjectPose.WALKING),
            suitablePhotoTypes = listOf("Travel", "Outdoor", "Landscape", "Casual", "Nature"),
            supportsSeatingOrSteps = true,
            keywords = listOf("mountain", "mountains", "viewpoint", "alps", "peak", "travel", "overlook", "scenic", "bench"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.LUXURY_TERRACE,
            name = "Luxury Outdoor Terrace",
            shortDesc = "Travertine steps overlooking coastal hills",
            assetPath = "images/bg_luxury_terrace_1795257731362.jpg",
            gradientColors = Triple(0xFFF7F3EB.toInt(), 0xFFD8CAB4.toInt(), 0xFF648DA8.toInt()),
            ambientRgb = Triple(246, 239, 228),
            ambientLuminance = 0.80f,
            defaultBlur = 18,
            defaultShadow = 52,
            horizonY = 0.48f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.SITTING, SubjectPose.LEANING, SubjectPose.STANDING, SubjectPose.POSING, SubjectPose.WALKING),
            suitablePhotoTypes = listOf("Travel", "Luxury", "Fashion", "Wedding", "Outdoor", "Casual"),
            supportsSeatingOrSteps = true,
            keywords = listOf("terrace", "balcony", "steps", "coastal", "villa", "resort", "travel", "luxury", "sitting"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.ARCHITECTURAL_STAIRS,
            name = "Modern Architectural Stairs",
            shortDesc = "Sunlit minimalist limestone steps",
            assetPath = "images/bg_architectural_stairs_1795257733752.jpg",
            gradientColors = Triple(0xFFF1F5F9.toInt(), 0xFFE2DFD7.toInt(), 0xFF94A3B8.toInt()),
            ambientRgb = Triple(240, 238, 232),
            ambientLuminance = 0.79f,
            defaultBlur = 14,
            defaultShadow = 58,
            horizonY = 0.46f,
            groundY = 0.78f,
            keyLightDirection = LightingDirection.TOP_RIGHT,
            suitablePoses = setOf(SubjectPose.SITTING, SubjectPose.LEANING, SubjectPose.STANDING, SubjectPose.WALKING, SubjectPose.POSING),
            suitablePhotoTypes = listOf("Fashion", "Travel", "Street", "Casual", "Outdoor", "Portrait"),
            supportsSeatingOrSteps = true,
            keywords = listOf("stairs", "steps", "staircase", "architectural", "modern", "sitting", "urban"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.OFFICE,
            name = "Office",
            shortDesc = "Modern architectural daylight workspace",
            assetPath = "images/bg_luxury_office_1795251949962.jpg",
            gradientColors = Triple(0xFFF5F0E8.toInt(), 0xFFE5DCCF.toInt(), 0xFFC8BBA8.toInt()),
            ambientRgb = Triple(244, 236, 224),
            ambientLuminance = 0.76f,
            defaultBlur = 24,
            defaultShadow = 48,
            horizonY = 0.56f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.RIGHT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.SITTING, SubjectPose.LEANING, SubjectPose.POSING),
            suitablePhotoTypes = listOf("Professional", "Portrait", "Business", "Indoor"),
            supportsSeatingOrSteps = true,
            keywords = listOf("office", "corporate", "desk", "workspace", "interior", "executive", "linkedin"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.SUNSET,
            name = "Sunset",
            shortDesc = "Golden hour warm mountain horizon",
            assetPath = "images/bg_sunset_nature_1795251948404.jpg",
            gradientColors = Triple(0xFFFDE68A.toInt(), 0xFFF59E0B.toInt(), 0xFF7C2D12.toInt()),
            ambientRgb = Triple(255, 206, 152),
            ambientLuminance = 0.68f,
            defaultBlur = 18,
            defaultShadow = 56,
            horizonY = 0.44f,
            groundY = 0.86f,
            keyLightDirection = LightingDirection.BACKLIT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.SITTING, SubjectPose.WALKING, SubjectPose.POSING, SubjectPose.LEANING),
            suitablePhotoTypes = listOf("Travel", "Outdoor", "Landscape", "Nature", "Wedding", "Portrait"),
            supportsSeatingOrSteps = true,
            keywords = listOf("sunset", "golden", "warm", "dusk", "sunrise", "amber", "horizon", "scenic"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.CITY,
            name = "City",
            shortDesc = "Blue-hour metropolitan avenue bokeh",
            assetPath = "images/bg_city_cinematic_1795252046970.jpg",
            gradientColors = Triple(0xFF1E3A8A.toInt(), 0xFF3B82F6.toInt(), 0xFF0F172A.toInt()),
            ambientRgb = Triple(176, 205, 246),
            ambientLuminance = 0.56f,
            defaultBlur = 22,
            defaultShadow = 60,
            horizonY = 0.56f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_RIGHT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.WALKING, SubjectPose.LEANING, SubjectPose.POSING),
            suitablePhotoTypes = listOf("Street", "Fashion", "Travel", "Night", "Portrait", "Casual"),
            keywords = listOf("city", "urban", "street", "skyline", "night", "lights", "downtown"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.WEDDING,
            name = "Wedding",
            shortDesc = "Romantic floral garden bokeh",
            assetPath = "images/bg_wedding_floral_1795252046977.jpg",
            gradientColors = Triple(0xFFFEFCE8.toInt(), 0xFFF0F4EA.toInt(), 0xFFD6E3CD.toInt()),
            ambientRgb = Triple(250, 245, 235),
            ambientLuminance = 0.84f,
            defaultBlur = 26,
            defaultShadow = 44,
            horizonY = 0.55f,
            groundY = 0.85f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.POSING, SubjectPose.WALKING, SubjectPose.SITTING),
            suitablePhotoTypes = listOf("Wedding", "Portrait", "Outdoor", "Fashion"),
            keywords = listOf("wedding", "floral", "garden", "bride", "romantic", "flowers", "ceremony"),
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.PASSPORT_ID,
            name = "Passport / ID Photo",
            shortDesc = "Official solid studio white or blue",
            gradientColors = Triple(0xFFFFFFFF.toInt(), 0xFFF8FAFC.toInt(), 0xFFF1F5F9.toInt()),
            ambientRgb = Triple(255, 255, 255),
            ambientLuminance = 0.92f,
            defaultBlur = 0,
            defaultShadow = 10,
            horizonY = 0.50f,
            groundY = 1.0f,
            keyLightDirection = LightingDirection.FRONT_DIFFUSED,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.POSING),
            suitablePhotoTypes = listOf("Portrait", "Professional"),
            keywords = listOf("passport", "id", "visa", "white", "document", "official"),
            proceduralStyle = ProceduralStyle.PASSPORT,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.LUXURY,
            name = "Luxury",
            shortDesc = "Warm travertine & champagne gold",
            gradientColors = Triple(0xFFF7F3EB.toInt(), 0xFFDFD3BE.toInt(), 0xFF9F8869.toInt()),
            ambientRgb = Triple(245, 233, 210),
            ambientLuminance = 0.72f,
            defaultBlur = 20,
            defaultShadow = 58,
            horizonY = 0.56f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.SITTING, SubjectPose.POSING, SubjectPose.OBJECT_STILL_LIFE),
            suitablePhotoTypes = listOf("Fashion", "Portrait", "Professional", "Product", "Wedding"),
            keywords = listOf("luxury", "gold", "marble", "hotel", "premium", "champagne"),
            proceduralStyle = ProceduralStyle.LUXURY_MARBLE,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.NATURE,
            name = "Nature",
            shortDesc = "Sunlit botanical meadow depth",
            gradientColors = Triple(0xFFD9F2DC.toInt(), 0xFF7DB986.toInt(), 0xFF2F5E3E.toInt()),
            ambientRgb = Triple(222, 240, 224),
            ambientLuminance = 0.70f,
            defaultBlur = 30,
            defaultShadow = 48,
            horizonY = 0.52f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.SITTING, SubjectPose.WALKING, SubjectPose.LYING_DOWN, SubjectPose.POSING),
            suitablePhotoTypes = listOf("Nature", "Outdoor", "Travel", "Casual", "Portrait"),
            supportsSeatingOrSteps = true,
            keywords = listOf("nature", "forest", "park", "green", "trees", "outdoor", "botanical"),
            proceduralStyle = ProceduralStyle.NATURE_BOKEH,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.BEACH,
            name = "Beach",
            shortDesc = "Turquoise shoreline & bright sky",
            gradientColors = Triple(0xFFE0F2FE.toInt(), 0xFF38BDF8.toInt(), 0xFFE7D5B5.toInt()),
            ambientRgb = Triple(232, 244, 250),
            ambientLuminance = 0.85f,
            defaultBlur = 18,
            defaultShadow = 46,
            horizonY = 0.54f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.SITTING, SubjectPose.WALKING, SubjectPose.LYING_DOWN, SubjectPose.POSING),
            suitablePhotoTypes = listOf("Travel", "Outdoor", "Casual", "Landscape"),
            supportsSeatingOrSteps = true,
            keywords = listOf("beach", "ocean", "sea", "coast", "summer", "sand", "tropical"),
            proceduralStyle = ProceduralStyle.BEACH_HORIZON,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.CINEMATIC,
            name = "Cinematic",
            shortDesc = "Teal & amber filmic depth",
            gradientColors = Triple(0xFF0F2937.toInt(), 0xFF1E4E68.toInt(), 0xFFC27A44.toInt()),
            ambientRgb = Triple(195, 214, 224),
            ambientLuminance = 0.54f,
            defaultBlur = 26,
            defaultShadow = 62,
            horizonY = 0.54f,
            groundY = 0.84f,
            keyLightDirection = LightingDirection.TOP_RIGHT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.LEANING, SubjectPose.POSING, SubjectPose.WALKING),
            suitablePhotoTypes = listOf("Fashion", "Street", "Travel", "Night", "Portrait"),
            keywords = listOf("cinematic", "film", "movie", "dramatic", "moody", "teal"),
            proceduralStyle = ProceduralStyle.CINEMATIC_TEAL,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.FASHION,
            name = "Fashion",
            shortDesc = "Editorial warm taupe studio",
            gradientColors = Triple(0xFFF4EFE9.toInt(), 0xFFD6CCC2.toInt(), 0xFF9C8F84.toInt()),
            ambientRgb = Triple(242, 236, 228),
            ambientLuminance = 0.78f,
            defaultBlur = 8,
            defaultShadow = 58,
            horizonY = 0.58f,
            groundY = 0.86f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.POSING, SubjectPose.SITTING, SubjectPose.LEANING, SubjectPose.WALKING),
            suitablePhotoTypes = listOf("Fashion", "Portrait", "Professional"),
            keywords = listOf("fashion", "editorial", "magazine", "model", "minimal"),
            proceduralStyle = ProceduralStyle.FASHION_EDITORIAL,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.BUSINESS_PORTRAIT,
            name = "Business Portrait",
            shortDesc = "Executive slate-blue vignette",
            gradientColors = Triple(0xFFEFF6FF.toInt(), 0xFFBFDBFE.toInt(), 0xFF1E3A8A.toInt()),
            ambientRgb = Triple(224, 236, 252),
            ambientLuminance = 0.74f,
            defaultBlur = 12,
            defaultShadow = 48,
            horizonY = 0.52f,
            groundY = 0.92f,
            keyLightDirection = LightingDirection.FRONT_DIFFUSED,
            suitablePoses = setOf(SubjectPose.STANDING, SubjectPose.POSING, SubjectPose.SITTING),
            suitablePhotoTypes = listOf("Professional", "Portrait"),
            keywords = listOf("business", "headshot", "resume", "profile", "executive", "blue"),
            proceduralStyle = ProceduralStyle.BUSINESS_SLATE,
        ),
        BackgroundPreset(
            id = BackgroundCategoryId.PRODUCT_PHOTOGRAPHY,
            name = "Product Photography",
            shortDesc = "Clean commercial studio pedestal",
            gradientColors = Triple(0xFFFFFFFF.toInt(), 0xFFE8EFF7.toInt(), 0xFFCBD5E1.toInt()),
            ambientRgb = Triple(245, 248, 252),
            ambientLuminance = 0.88f,
            defaultBlur = 4,
            defaultShadow = 64,
            horizonY = 0.68f,
            groundY = 0.82f,
            keyLightDirection = LightingDirection.TOP_LEFT,
            suitablePoses = setOf(SubjectPose.OBJECT_STILL_LIFE),
            suitablePhotoTypes = listOf("Product", "Food"),
            keywords = listOf("product", "ecommerce", "catalog", "shop", "podium", "commercial"),
            proceduralStyle = ProceduralStyle.PRODUCT_PODIUM,
        ),
    )

    val stickers: List<StickerPreset> = listOf(
        StickerPreset("studio-seal", "BT Kite Seal", "BT KITE", 0xFF2563EB.toInt(), 0xFFFFFFFF.toInt()),
        StickerPreset("new-edit", "New Edit", "NEW EDIT", 0xFF0F172A.toInt(), 0xFFFFFFFF.toInt()),
        StickerPreset("featured", "Featured", "FEATURED", 0xFF2563EB.toInt(), 0xFFDBEAFE.toInt()),
        StickerPreset("verified", "Studio Pro", "PRO STUDIO", 0xFF1D4ED8.toInt(), 0xFFFFFFFF.toInt()),
        StickerPreset("golden", "Golden Hour", "GOLDEN", 0xFFD97706.toInt(), 0xFFFFFBEB.toInt()),
        StickerPreset("editorial", "Editorial", "EDITORIAL", 0xFF334155.toInt(), 0xFFF8FAFC.toInt()),
    )

    fun presetFor(id: BackgroundCategoryId): BackgroundPreset =
        backgroundPresets.firstOrNull { it.id == id } ?: backgroundPresets.first()

    fun styleAdjustmentsFor(styleId: ColorStyleId): ColorAdjustments = when (styleId) {
        ColorStyleId.NONE -> ColorAdjustments()
        ColorStyleId.NATURAL -> ColorAdjustments(exposure = 6, contrast = 8, highlights = -8, shadows = 12, vibrance = 10, clarity = 6, sharpness = 12)
        ColorStyleId.CINEMATIC -> ColorAdjustments(contrast = 18, highlights = -14, shadows = -8, blacks = -12, temperature = -8, tint = -4, saturation = -6, vibrance = 14, colorBalance = -14, clarity = 14)
        ColorStyleId.PROFESSIONAL_PORTRAIT -> ColorAdjustments(exposure = 8, contrast = 6, highlights = -12, shadows = 18, temperature = 6, skinTone = 18, vibrance = 8, clarity = 4, sharpness = 14, noiseReduction = 12)
        ColorStyleId.HDR -> ColorAdjustments(contrast = 16, highlights = -34, shadows = 36, whites = 10, blacks = -8, clarity = 26, vibrance = 18, sharpness = 22)
        ColorStyleId.WARM -> ColorAdjustments(temperature = 22, tint = 4, exposure = 5, shadows = 10, vibrance = 12, skinTone = 10)
        ColorStyleId.COOL -> ColorAdjustments(temperature = -22, tint = -4, contrast = 10, whites = 8, clarity = 10, colorBalance = -10)
        ColorStyleId.LUXURY -> ColorAdjustments(contrast = 16, highlights = -10, blacks = -14, saturation = -12, vibrance = 12, temperature = 8, clarity = 16, sharpness = 16)
        ColorStyleId.WEDDING -> ColorAdjustments(exposure = 12, brightness = 6, contrast = -6, highlights = -16, shadows = 24, whites = 10, temperature = 6, tint = 6, saturation = -6, skinTone = 14)
        ColorStyleId.FILM -> ColorAdjustments(contrast = 12, highlights = -18, shadows = 12, blacks = 12, temperature = 8, tint = -6, saturation = -8, vibrance = 10, colorBalance = 8)
        ColorStyleId.VINTAGE -> ColorAdjustments(contrast = -8, blacks = 18, highlights = -14, temperature = 20, tint = 8, saturation = -18, colorBalance = 14)
        ColorStyleId.MODERN -> ColorAdjustments(exposure = 4, contrast = 14, whites = 12, blacks = -10, temperature = -4, vibrance = 12, clarity = 14, sharpness = 18)
        ColorStyleId.VIBRANT -> ColorAdjustments(exposure = 6, contrast = 10, saturation = 14, vibrance = 26, clarity = 10, sharpness = 12)
        ColorStyleId.MOODY -> ColorAdjustments(exposure = -10, contrast = 20, highlights = -20, shadows = -14, blacks = -16, saturation = -18, temperature = -6, clarity = 18)
        ColorStyleId.SOFT -> ColorAdjustments(exposure = 8, contrast = -12, highlights = -12, shadows = 20, clarity = -10, saturation = -6, noiseReduction = 18)
        ColorStyleId.GOLDEN_HOUR -> ColorAdjustments(exposure = 8, highlights = -14, shadows = 18, temperature = 28, tint = 8, vibrance = 16, colorBalance = 16, skinTone = 12)
    }

    fun mergeAdjustmentsWithStyle(
        base: ColorAdjustments,
        styleId: ColorStyleId,
        intensity: Int,
    ): ColorAdjustments {
        if (styleId == ColorStyleId.NONE || intensity <= 0) return base
        val style = styleAdjustmentsFor(styleId)
        val f = intensity / 100f
        fun blend(a: Int, b: Int, minVal: Int = -100): Int =
            (a + (b * f)).roundToInt().coerceIn(minVal, 100)
        return ColorAdjustments(
            exposure = blend(base.exposure, style.exposure),
            brightness = blend(base.brightness, style.brightness),
            contrast = blend(base.contrast, style.contrast),
            highlights = blend(base.highlights, style.highlights),
            shadows = blend(base.shadows, style.shadows),
            whites = blend(base.whites, style.whites),
            blacks = blend(base.blacks, style.blacks),
            saturation = blend(base.saturation, style.saturation),
            vibrance = blend(base.vibrance, style.vibrance),
            temperature = blend(base.temperature, style.temperature),
            tint = blend(base.tint, style.tint),
            sharpness = blend(base.sharpness, style.sharpness, 0),
            clarity = blend(base.clarity, style.clarity),
            colorBalance = blend(base.colorBalance, style.colorBalance),
            skinTone = blend(base.skinTone, style.skinTone),
            noiseReduction = blend(base.noiseReduction, style.noiseReduction, 0),
        )
    }

    fun rankBackgroundsForScene(
        pose: SubjectPose,
        poseDetail: String,
        photoCategory: String,
        cameraDistance: CameraDistance,
        cameraAngle: CameraAngle,
        lightingDirection: LightingDirection,
        originalEnvironment: String,
        avgLuminance: Float = 0.55f,
    ): List<RecommendedBackgroundItem> {
        val envLower = "$originalEnvironment $poseDetail".lowercase()
        val catLower = photoCategory.lowercase()
        val isStairsContext = Regex("stair|step|ledge|bench|terrace|sit").containsMatchIn(envLower) || pose == SubjectPose.SITTING
        val isTravelContext = Regex("travel|outdoor|landscape|nature|street|mountain|beach").containsMatchIn(catLower)
        val isPortraitContext = Regex("portrait|professional|business|headshot").containsMatchIn(catLower)
        val isProductContext = pose == SubjectPose.OBJECT_STILL_LIFE || Regex("product|food").containsMatchIn(catLower)

        return backgroundPresets.map { preset ->
            var score = 45
            val reasons = mutableListOf<String>()

            if (pose in preset.suitablePoses) score += 18 else score -= 22

            if (pose == SubjectPose.SITTING || pose == SubjectPose.LEANING || isStairsContext) {
                if (preset.supportsSeatingOrSteps) {
                    score += 22
                    when {
                        preset.id == BackgroundCategoryId.ARCHITECTURAL_STAIRS && Regex("stair|step").containsMatchIn(envLower) -> {
                            score += 12
                            reasons.add("Preserves natural stair & seated ground perspective")
                        }
                        preset.id == BackgroundCategoryId.MOUNTAINS ->
                            reasons.add("Natural overlook seating & elevated scenic depth")
                        preset.id == BackgroundCategoryId.LUXURY_TERRACE ->
                            reasons.add("Architectural terrace steps fit seated pose & daylight")
                        else ->
                            reasons.add("Natural ground plane matches seated posture")
                    }
                } else if (preset.id == BackgroundCategoryId.PASSPORT_ID || preset.id == BackgroundCategoryId.PRODUCT_PHOTOGRAPHY) {
                    score -= 30
                }
            }

            if (preset.suitablePhotoTypes.any { t ->
                    catLower.contains(t.lowercase()) || t.lowercase().contains(catLower.substringBefore(" "))
                }
            ) {
                score += 18
            }

            when {
                isProductContext -> {
                    when (preset.id) {
                        BackgroundCategoryId.PRODUCT_PHOTOGRAPHY -> {
                            score += 35
                            reasons.add("Commercial studio surface anchors product contact shadows")
                        }
                        BackgroundCategoryId.LUXURY, BackgroundCategoryId.PROFESSIONAL_STUDIO -> {
                            score += 18
                            reasons.add("Clean studio lighting highlights object contours")
                        }
                        else -> score -= 18
                    }
                }
                isPortraitContext && (cameraDistance == CameraDistance.CLOSE_UP || cameraDistance == CameraDistance.MEDIUM_SHOT) -> {
                    if (preset.id in setOf(
                            BackgroundCategoryId.PROFESSIONAL_STUDIO,
                            BackgroundCategoryId.BUSINESS_PORTRAIT,
                            BackgroundCategoryId.OFFICE,
                        )
                    ) {
                        score += 20
                        reasons.add("Balanced studio depth separates hair and shoulders cleanly")
                    } else if (preset.id == BackgroundCategoryId.FASHION || preset.id == BackgroundCategoryId.LUXURY) {
                        score += 12
                        reasons.add("Editorial portrait tones complement facial lighting")
                    }
                }
                isTravelContext -> {
                    if (preset.id in setOf(
                            BackgroundCategoryId.MOUNTAINS,
                            BackgroundCategoryId.LUXURY_TERRACE,
                            BackgroundCategoryId.SUNSET,
                            BackgroundCategoryId.ARCHITECTURAL_STAIRS,
                            BackgroundCategoryId.BEACH,
                        )
                    ) {
                        score += 20
                        reasons.add("Authentic travel environment with matching open-sky depth")
                    }
                }
            }

            if (cameraAngle == CameraAngle.SLIGHTLY_ELEVATED && preset.id in setOf(
                    BackgroundCategoryId.MOUNTAINS,
                    BackgroundCategoryId.LUXURY_TERRACE,
                    BackgroundCategoryId.ARCHITECTURAL_STAIRS,
                )
            ) {
                score += 8
            }

            if (preset.keyLightDirection == lightingDirection) {
                score += 7
                reasons.add("Matches ${lightingDirection.label.lowercase()} key light direction")
            }

            if (abs(preset.ambientLuminance - avgLuminance) < 0.22f) score += 6
            if (preset.assetPath != null) score += 4

            if (reasons.isEmpty()) {
                reasons.add("${preset.shortDesc} · balanced for ${photoCategory.lowercase()}")
            }

            RecommendedBackgroundItem(
                categoryId = preset.id,
                name = preset.name,
                reason = reasons.first(),
                matchScore = score.coerceIn(55, 99),
            )
        }.sortedByDescending { it.matchScore }.take(5)
    }

    fun computeAutoBlendForScene(
        preset: BackgroundPreset,
        cameraDistance: CameraDistance,
        groundLevelY: Float,
        horizonY: Float,
        lightingDirection: LightingDirection,
    ): AutoBlendResult {
        val distanceBlurFactor = when (cameraDistance) {
            CameraDistance.CLOSE_UP -> 1.45f
            CameraDistance.MEDIUM_SHOT -> 1.10f
            CameraDistance.FULL_BODY -> 0.72f
            CameraDistance.WIDE_SHOT -> 0.55f
        }
        val blur = if (preset.id == BackgroundCategoryId.PASSPORT_ID) {
            0
        } else {
            (preset.defaultBlur * distanceBlurFactor).roundToInt().coerceIn(4, 58)
        }

        val rawDeltaY = if (groundLevelY < 0.96f) {
            (groundLevelY - preset.groundY) * 100f
        } else {
            (horizonY - preset.horizonY) * 75f
        }
        val horizonShift = rawDeltaY.roundToInt().coerceIn(-28, 28)

        val shadowDepth = when {
            preset.id == BackgroundCategoryId.PASSPORT_ID -> 10
            groundLevelY < 0.96f -> maxOf(48, preset.defaultShadow)
            else -> (preset.defaultShadow * 0.45f).roundToInt()
        }

        return AutoBlendResult(
            backgroundBlur = blur,
            shadowDepth = shadowDepth,
            horizonShift = horizonShift,
            lightingDirection = lightingDirection,
        )
    }

    fun matchPromptToBackgroundPreset(prompt: String): BackgroundPreset {
        val lower = prompt.lowercase()
        var best = backgroundPresets.first()
        var bestScore = -1
        for (preset in backgroundPresets) {
            var score = 0
            if (lower.contains(preset.name.lowercase())) score += 5
            for (kw in preset.keywords) {
                if (lower.contains(kw)) score += 2
            }
            if (score > bestScore) {
                bestScore = score
                best = preset
            }
        }
        return best
    }
}
