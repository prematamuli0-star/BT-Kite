package com.btmediastudio.btkite.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Compare
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.FilterVintage
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.btmediastudio.btkite.model.ExportFormat
import com.btmediastudio.btkite.model.ToolTab
import com.btmediastudio.btkite.ui.theme.ErrorRed
import com.btmediastudio.btkite.ui.theme.InkMuted
import com.btmediastudio.btkite.ui.theme.InkPrimary
import com.btmediastudio.btkite.ui.theme.InkSecondary
import com.btmediastudio.btkite.ui.theme.KiteBlue
import com.btmediastudio.btkite.ui.theme.KiteBlueSoft
import com.btmediastudio.btkite.ui.theme.StudioBorder
import com.btmediastudio.btkite.ui.theme.StudioCanvasBg
import com.btmediastudio.btkite.ui.theme.StudioWhite
import com.btmediastudio.btkite.viewmodel.EditorUiState
import com.btmediastudio.btkite.viewmodel.EditorViewModel

private data class BrushStroke(
    val points: List<Offset>,
    val widthPx: Float,
)

@Composable
fun EditorScreen(
    state: EditorUiState,
    viewModel: EditorViewModel,
    onPickCustomBackdrop: () -> Unit,
) {
    val present = state.present ?: return
    val preview = state.previewBitmap ?: present.baseBitmap
    val original = state.sourceBitmap ?: present.baseBitmap

    val context = LocalContext.current
    var showLeaveDialog by remember { mutableStateOf(false) }
    val brushStrokes = remember { mutableStateListOf<BrushStroke>() }
    var currentStrokePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var stageSize by remember { mutableStateOf(IntSize(1, 1)) }
    var pendingExport by remember { mutableStateOf<Pair<ExportFormat, Int>?>(null) }

    val legacyStoragePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        val req = pendingExport
        pendingExport = null
        if (granted && req != null) {
            viewModel.exportPhoto(req.first, req.second)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioCanvasBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // Compact Top Studio Bar
        Surface(color = StudioWhite) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            if (state.canUndo) showLeaveDialog = true else viewModel.closeEditor()
                        }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = InkPrimary)
                        }
                        IconButton(onClick = { viewModel.undo() }, enabled = state.canUndo) {
                            Icon(
                                Icons.AutoMirrored.Rounded.Undo,
                                contentDescription = "Undo",
                                tint = if (state.canUndo) InkPrimary else StudioBorder,
                            )
                        }
                        IconButton(onClick = { viewModel.redo() }, enabled = state.canRedo) {
                            Icon(
                                Icons.AutoMirrored.Rounded.Redo,
                                contentDescription = "Redo",
                                tint = if (state.canRedo) InkPrimary else StudioBorder,
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (state.compareMode) KiteBlueSoft else StudioWhite,
                            border = BorderStroke(1.dp, if (state.compareMode) KiteBlue else StudioBorder),
                            modifier = Modifier.clickable { viewModel.toggleCompareMode() },
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    Icons.Rounded.Compare,
                                    contentDescription = "Before/After",
                                    tint = if (state.compareMode) KiteBlue else InkSecondary,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    "Compare",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (state.compareMode) KiteBlue else InkSecondary,
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.setShowExportSheet(true) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        ) {
                            Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Save", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                HorizontalDivider(color = StudioBorder)
            }
        }

        // Status Feedback Banner
        state.statusMessage?.let { msg ->
            Surface(
                color = if (state.isErrorBanner) Color(0xFFFEF2F2) else KiteBlueSoft,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = msg,
                        fontSize = 12.sp,
                        color = if (state.isErrorBanner) ErrorRed else Color(0xFF1E3A8A),
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { viewModel.clearBanner() }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Dismiss", modifier = Modifier.size(15.dp))
                    }
                }
            }
        }

        // Interactive Photo Stage
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.48f)
                .background(Color(0xFFF1F5F9))
                .padding(12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .clipToBounds()
                    .onSizeChanged { stageSize = it }
                    .graphicsLayer(scaleX = state.zoom, scaleY = state.zoom),
                contentAlignment = Alignment.Center,
            ) {
                // Edited After Image
                Image(
                    bitmap = preview.asImageBitmap(),
                    contentDescription = "Edited photo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )

                // Before/After Draggable Split Overlay
                if (state.compareMode) {
                    val split = state.compareSplit
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures { change, _ ->
                                    change.consume()
                                    if (stageSize.width > 0) {
                                        viewModel.setCompareSplit(change.position.x / stageSize.width.toFloat())
                                    }
                                }
                            },
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val splitX = size.width * split
                            clipRect(left = 0f, top = 0f, right = splitX, bottom = size.height) {
                                val imgRatio = original.width.toFloat() / original.height.coerceAtLeast(1)
                                val boxRatio = size.width / size.height.coerceAtLeast(1f)
                                val drawW: Float
                                val drawH: Float
                                if (imgRatio > boxRatio) {
                                    drawW = size.width
                                    drawH = size.width / imgRatio
                                } else {
                                    drawH = size.height
                                    drawW = size.height * imgRatio
                                }
                                val left = (size.width - drawW) / 2f
                                val top = (size.height - drawH) / 2f
                                drawImage(
                                    image = original.asImageBitmap(),
                                    dstOffset = androidx.compose.ui.unit.IntOffset(left.toInt(), top.toInt()),
                                    dstSize = IntSize(drawW.toInt(), drawH.toInt()),
                                )
                            }
                            drawLine(
                                color = Color.White,
                                start = Offset(splitX, 0f),
                                end = Offset(splitX, size.height),
                                strokeWidth = 5f,
                            )
                            drawCircle(
                                color = KiteBlue,
                                radius = 26f,
                                center = Offset(splitX, size.height / 2f),
                            )
                            drawCircle(
                                color = Color.White,
                                radius = 26f,
                                center = Offset(splitX, size.height / 2f),
                                style = Stroke(width = 4f),
                            )
                        }
                    }
                }

                // Interactive Brush Object Removal Painting Layer
                if (state.brushActive) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(state.brushSizePx) {
                                detectDragGestures(
                                    onDragStart = { pt -> currentStrokePoints = listOf(pt) },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        currentStrokePoints = currentStrokePoints + change.position
                                    },
                                    onDragEnd = {
                                        if (currentStrokePoints.isNotEmpty()) {
                                            brushStrokes.add(BrushStroke(currentStrokePoints, state.brushSizePx))
                                            currentStrokePoints = emptyList()
                                        }
                                    },
                                )
                            },
                    ) {
                        val allStrokes = brushStrokes + if (currentStrokePoints.isNotEmpty()) {
                            listOf(BrushStroke(currentStrokePoints, state.brushSizePx))
                        } else emptyList()

                        allStrokes.forEach { stroke ->
                            if (stroke.points.size == 1) {
                                drawCircle(
                                    color = Color(0x882563EB),
                                    radius = stroke.widthPx / 2f,
                                    center = stroke.points.first(),
                                )
                            } else {
                                for (i in 0 until stroke.points.lastIndex) {
                                    drawLine(
                                        color = Color(0x882563EB),
                                        start = stroke.points[i],
                                        end = stroke.points[i + 1],
                                        strokeWidth = stroke.widthPx,
                                        cap = StrokeCap.Round,
                                    )
                                }
                            }
                        }
                    }
                }

                // Crop Overlay Frame
                if (state.activeTab == ToolTab.CROP && state.cropRect.isDirty) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val r = state.cropRect
                        val left = r.x * size.width
                        val top = r.y * size.height
                        val w = r.width * size.width
                        val h = r.height * size.height
                        drawRect(
                            color = KiteBlue,
                            topLeft = Offset(left, top),
                            size = Size(w, h),
                            style = Stroke(width = 4f, join = StrokeJoin.Miter),
                        )
                    }
                }
            }

            // Compact Stage Zoom Controls
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp),
                shape = RoundedCornerShape(10.dp),
                color = StudioWhite.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, StudioBorder),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.setZoom(state.zoom - 0.25f) },
                        modifier = Modifier.size(30.dp),
                    ) {
                        Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom out", tint = InkSecondary, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "${(state.zoom * 100).toInt()}%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = InkPrimary,
                        modifier = Modifier
                            .clickable { viewModel.setZoom(1f) }
                            .padding(horizontal = 4.dp),
                    )
                    IconButton(
                        onClick = { viewModel.setZoom(state.zoom + 0.25f) },
                        modifier = Modifier.size(30.dp),
                    ) {
                        Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom in", tint = InkSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // Scrollable Active Tool Panel
        Surface(
            color = StudioWhite,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.52f),
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                HorizontalDivider(color = StudioBorder)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                ) {
                    when (state.activeTab) {
                        ToolTab.AI -> AIPanelContent(
                            analysis = state.analysis,
                            brushActive = state.brushActive,
                            brushSizePx = state.brushSizePx,
                            hasBrushStrokes = brushStrokes.isNotEmpty(),
                            onAutoBackground = { viewModel.runAutoBackground() },
                            onAIColorTune = { viewModel.runAIColorTune() },
                            onAIEnhance = { viewModel.runAIEnhance() },
                            onPortraitEnhance = { viewModel.runPortraitEnhance() },
                            onOpenBackgrounds = { viewModel.setActiveTab(ToolTab.BACKGROUND) },
                            onToggleBrush = { active ->
                                if (!active) brushStrokes.clear()
                                viewModel.toggleBrushMode(active)
                            },
                            onBrushSizeChange = { viewModel.setBrushSize(it) },
                            onClearBrush = { brushStrokes.clear() },
                            onApplyBrushRemoval = {
                                val mask = rasterizeBrushMask(
                                    strokes = brushStrokes,
                                    stageSize = stageSize,
                                    targetW = present.baseBitmap.width,
                                    targetH = present.baseBitmap.height,
                                )
                                brushStrokes.clear()
                                viewModel.applyObjectRemoval(mask)
                            },
                        )
                        ToolTab.BACKGROUND -> BackgroundPanelContent(
                            background = present.background,
                            hasCutout = present.cutoutBitmap != null,
                            analysis = state.analysis,
                            analyzingScene = state.analyzingScene,
                            onRefreshAnalysis = { viewModel.refreshSceneAnalysis() },
                            onAutoBackground = { viewModel.runAutoBackground() },
                            onSelectCategory = { viewModel.selectBackgroundCategory(it) },
                            onPickCustomBackdrop = onPickCustomBackdrop,
                            onSelectPassportColor = { viewModel.selectPassportColor(it) },
                            onApplyPromptMatch = { viewModel.applyPromptMatchedBackground(it) },
                            onUpdateBlend = { commit, fn -> viewModel.updateBlend(commit, fn) },
                        )
                        ToolTab.ADJUST -> AdjustPanelContent(
                            adjustments = present.adjustments,
                            onAIColorTune = { viewModel.runAIColorTune() },
                            onResetAll = { viewModel.resetAdjustments() },
                            onUpdate = { commit, fn -> viewModel.updateAdjustments(commit, fn) },
                        )
                        ToolTab.FILTERS -> FiltersPanelContent(
                            selectedStyle = present.styleId,
                            intensity = present.styleIntensity,
                            onSelectStyle = { viewModel.selectColorStyle(it) },
                            onIntensityChange = { v, c -> viewModel.updateStyleIntensity(v, c) },
                        )
                        ToolTab.CROP -> CropPanelContent(
                            cropDirty = state.cropRect.isDirty,
                            onSelectAspect = { viewModel.selectCropAspectRatio(it) },
                            onRotate = { viewModel.rotate(it) },
                            onFlipH = { viewModel.flipHorizontal() },
                            onFlipV = { viewModel.flipVertical() },
                            onApplyCrop = { viewModel.applyCrop() },
                            onResetCrop = { viewModel.selectCropAspectRatio(null) },
                        )
                        ToolTab.TEXT -> TextPanelContent(
                            layers = present.textLayers,
                            selectedId = state.selectedTextId,
                            onAdd = { viewModel.addTextLayer() },
                            onSelect = { viewModel.selectTextLayer(it) },
                            onUpdate = { id, c, fn -> viewModel.updateTextLayer(id, c, fn) },
                            onDelete = { viewModel.deleteTextLayer(it) },
                        )
                        ToolTab.STICKERS -> StickersPanelContent(
                            layers = present.stickerLayers,
                            selectedId = state.selectedStickerId,
                            onAdd = { viewModel.addStickerLayer(it) },
                            onUpdate = { id, c, fn -> viewModel.updateStickerLayer(id, c, fn) },
                            onDelete = { viewModel.deleteStickerLayer(it) },
                        )
                    }
                }

                // Bottom 7-Tab Tool Rail
                HorizontalDivider(color = StudioBorder)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    ToolTab.entries.forEach { tab ->
                        val active = state.activeTab == tab
                        val icon = when (tab) {
                            ToolTab.AI -> Icons.Rounded.AutoAwesome
                            ToolTab.BACKGROUND -> Icons.Rounded.Image
                            ToolTab.ADJUST -> Icons.Rounded.Tune
                            ToolTab.FILTERS -> Icons.Rounded.FilterVintage
                            ToolTab.CROP -> Icons.Rounded.Crop
                            ToolTab.TEXT -> Icons.Rounded.TextFields
                            ToolTab.STICKERS -> Icons.Rounded.EmojiEmotions
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) KiteBlueSoft else Color.Transparent,
                            modifier = Modifier.clickable { viewModel.setActiveTab(tab) },
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Icon(
                                    icon,
                                    contentDescription = tab.label,
                                    tint = if (active) KiteBlue else InkMuted,
                                    modifier = Modifier.size(19.dp),
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    tab.label,
                                    fontSize = 10.sp,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                    color = if (active) KiteBlue else InkMuted,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Processing Progress Modal
    if (state.processing.active) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = StudioWhite,
            title = { Text(state.processing.title, fontWeight = FontWeight.Bold, color = InkPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(state.processing.detail, fontSize = 13.sp, color = InkSecondary)
                    LinearProgressIndicator(
                        progress = { state.processing.progress.coerceIn(0.05f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape),
                        color = KiteBlue,
                        trackColor = StudioBorder,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.cancelActiveTask() }) {
                    Text("Cancel", color = InkSecondary)
                }
            },
        )
    }

    // Export High-Res Dialog
    if (state.showExportSheet) {
        var selectedFormat by remember { mutableStateOf(ExportFormat.JPEG) }
        var jpegQuality by remember { mutableIntStateOf(95) }
        AlertDialog(
            onDismissRequest = { viewModel.setShowExportSheet(false) },
            containerColor = StudioWhite,
            title = { Text("Save High-Resolution Photo", fontWeight = FontWeight.Bold, color = InkPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Output: ${present.baseBitmap.width} × ${present.baseBitmap.height} px · Pictures/BT Kite",
                        fontSize = 12.sp,
                        color = InkMuted,
                    )
                    ExportFormat.entries.forEach { fmt ->
                        val enabled = fmt != ExportFormat.TRANSPARENT_PNG || present.cutoutBitmap != null
                        val active = selectedFormat == fmt
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) KiteBlueSoft else StudioWhite,
                            border = BorderStroke(1.dp, if (active) KiteBlue else StudioBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = enabled) { selectedFormat = fmt },
                        ) {
                            Text(
                                text = fmt.label + if (!enabled) " (Run Auto BG first)" else "",
                                fontSize = 13.sp,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                color = if (!enabled) InkMuted else if (active) KiteBlue else InkPrimary,
                                modifier = Modifier.padding(12.dp),
                            )
                        }
                    }
                    if (selectedFormat == ExportFormat.JPEG) {
                        StudioSliderRow(
                            label = "JPG Quality",
                            value = jpegQuality.toFloat(),
                            range = 70f..100f,
                            suffix = "%",
                            onValueChange = { jpegQuality = it.toInt() },
                            onValueChangeFinished = {},
                        )
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setShowExportSheet(false) }) { Text("Cancel") }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                        ) {
                            pendingExport = selectedFormat to jpegQuality
                            legacyStoragePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        } else {
                            viewModel.exportPhoto(selectedFormat, jpegQuality)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
                ) {
                    Text("Save to Gallery", fontWeight = FontWeight.Bold)
                }
            },
        )
    }

    if (showLeaveDialog) {
        AlertDialog(
            onDismissRequest = { showLeaveDialog = false },
            containerColor = StudioWhite,
            title = { Text("Leave Editor?", fontWeight = FontWeight.Bold) },
            text = { Text("Unsaved edits will be cleared when returning to Home.", fontSize = 13.sp, color = InkSecondary) },
            dismissButton = {
                TextButton(onClick = { showLeaveDialog = false }) { Text("Stay") }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLeaveDialog = false
                        viewModel.closeEditor()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
                ) {
                    Text("Return Home")
                }
            },
        )
    }
}

private fun rasterizeBrushMask(
    strokes: List<BrushStroke>,
    stageSize: IntSize,
    targetW: Int,
    targetH: Int,
): Bitmap {
    val mask = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(mask)
    val imgRatio = targetW.toFloat() / targetH.coerceAtLeast(1)
    val boxW = stageSize.width.coerceAtLeast(1).toFloat()
    val boxH = stageSize.height.coerceAtLeast(1).toFloat()
    val boxRatio = boxW / boxH

    val drawW: Float
    val drawH: Float
    if (imgRatio > boxRatio) {
        drawW = boxW
        drawH = boxW / imgRatio
    } else {
        drawH = boxH
        drawW = boxH * imgRatio
    }
    val offsetX = (boxW - drawW) / 2f
    val offsetY = (boxH - drawH) / 2f
    val scaleX = targetW / drawW
    val scaleY = targetH / drawH

    val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.BLUE
        style = AndroidPaint.Style.STROKE
        strokeCap = AndroidPaint.Cap.ROUND
        strokeJoin = AndroidPaint.Join.ROUND
    }

    strokes.forEach { stroke ->
        paint.strokeWidth = stroke.widthPx * scaleX
        if (stroke.points.size == 1) {
            val pt = stroke.points.first()
            paint.style = AndroidPaint.Style.FILL
            canvas.drawCircle((pt.x - offsetX) * scaleX, (pt.y - offsetY) * scaleY, (stroke.widthPx * scaleX) / 2f, paint)
            paint.style = AndroidPaint.Style.STROKE
        } else {
            for (i in 0 until stroke.points.lastIndex) {
                val p0 = stroke.points[i]
                val p1 = stroke.points[i + 1]
                canvas.drawLine(
                    (p0.x - offsetX) * scaleX,
                    (p0.y - offsetY) * scaleY,
                    (p1.x - offsetX) * scaleX,
                    (p1.y - offsetY) * scaleY,
                    paint,
                )
            }
        }
    }
    return mask
}
