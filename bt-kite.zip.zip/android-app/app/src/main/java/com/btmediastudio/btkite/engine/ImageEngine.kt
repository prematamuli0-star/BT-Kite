package com.btmediastudio.btkite.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import com.btmediastudio.btkite.data.BackgroundPreset
import com.btmediastudio.btkite.data.ProceduralStyle
import com.btmediastudio.btkite.data.StudioPresets
import com.btmediastudio.btkite.model.BackgroundCategoryId
import com.btmediastudio.btkite.model.BackgroundState
import com.btmediastudio.btkite.model.ColorAdjustments
import com.btmediastudio.btkite.model.CropRect
import com.btmediastudio.btkite.model.CutoutGeometry
import com.btmediastudio.btkite.model.EditorSnapshot
import com.btmediastudio.btkite.model.ExportFormat
import com.btmediastudio.btkite.model.LightingDirection
import com.btmediastudio.btkite.model.StickerLayer
import com.btmediastudio.btkite.model.TextBgStyle
import com.btmediastudio.btkite.model.TextLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

object ImageEngine {

    private val assetCache = LinkedHashMap<String, Bitmap>(16, 0.75f, true)

    fun loadBitmapFromAsset(context: Context, assetPath: String): Bitmap {
        synchronized(assetCache) {
            assetCache[assetPath]?.takeIf { !it.isRecycled }?.let { return it }
        }
        val decoded = context.assets.open(assetPath).use { input ->
            BitmapFactory.decodeStream(input)
        } ?: throw IllegalStateException("Unable to decode asset: $assetPath")
        val argb = if (decoded.config == Bitmap.Config.ARGB_8888) decoded else decoded.copy(Bitmap.Config.ARGB_8888, false)
        synchronized(assetCache) {
            if (assetCache.size >= 14) {
                val oldestKey = assetCache.keys.firstOrNull()
                if (oldestKey != null) assetCache.remove(oldestKey)
            }
            assetCache[assetPath] = argb
        }
        return argb
    }

    suspend fun loadBitmapFromUri(
        context: Context,
        uri: Uri,
        maxDimension: Int = 2400,
    ): Bitmap = withContext(Dispatchers.IO) {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, boundsOpts)
        }
        val maxSide = max(boundsOpts.outWidth, boundsOpts.outHeight)
        var sampleSize = 1
        while (maxSide / (sampleSize * 2) >= maxDimension) {
            sampleSize *= 2
        }

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val raw = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        } ?: throw IllegalStateException("Could not open selected image.")

        val exifRotation = runCatching {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        }.getOrDefault(0f)

        val oriented = if (exifRotation != 0f) {
            val m = Matrix().apply { postRotate(exifRotation) }
            val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            if (rotated !== raw) raw.recycle()
            rotated
        } else {
            raw
        }

        val curMax = max(oriented.width, oriented.height)
        if (curMax > maxDimension) {
            val scale = maxDimension.toFloat() / curMax
            val scaled = Bitmap.createScaledBitmap(
                oriented,
                max(1, (oriented.width * scale).roundToInt()),
                max(1, (oriented.height * scale).roundToInt()),
                true,
            )
            if (scaled !== oriented) oriented.recycle()
            scaled
        } else {
            oriented
        }
    }

    suspend fun renderSnapshotToBitmap(
        context: Context,
        snapshot: EditorSnapshot,
        maxDimension: Int? = 1280,
        includeOverlays: Boolean = true,
    ): Bitmap = withContext(Dispatchers.Default) {
        val srcW = snapshot.baseBitmap.width
        val srcH = snapshot.baseBitmap.height

        val scale = if (maxDimension != null && max(srcW, srcH) > maxDimension) {
            maxDimension.toFloat() / max(srcW, srcH)
        } else {
            1f
        }
        val workW = max(1, (srcW * scale).roundToInt())
        val workH = max(1, (srcH * scale).roundToInt())

        val workBitmap = Bitmap.createBitmap(workW, workH, Bitmap.Config.ARGB_8888)
        val workCanvas = Canvas(workBitmap)

        val usesBgReplacement =
            snapshot.cutoutBitmap != null && snapshot.background.categoryId != BackgroundCategoryId.ORIGINAL

        if (usesBgReplacement && snapshot.cutoutBitmap != null) {
            compositeSubjectWithBackground(
                context = context,
                targetCanvas = workCanvas,
                w = workW,
                h = workH,
                cutoutBitmap = snapshot.cutoutBitmap,
                bg = snapshot.background,
            )
        } else {
            val dstRect = Rect(0, 0, workW, workH)
            workCanvas.drawBitmap(snapshot.baseBitmap, null, dstRect, Paint(Paint.FILTER_BITMAP_FLAG))
        }

        // Step 2: Apply 16 adjustments merged with active Color Style
        val effectiveAdj = StudioPresets.mergeAdjustmentsWithStyle(
            snapshot.adjustments,
            snapshot.styleId,
            snapshot.styleIntensity,
        )
        if (effectiveAdj.hasAnyEffect()) {
            applyColorAdjustmentsInPlace(workBitmap, effectiveAdj)
        }

        // Step 3: Rotation & Flip
        val rot = ((snapshot.transform.rotationDegrees % 360) + 360) % 360
        val swapAxes = rot == 90 || rot == 270
        val outW = if (swapAxes) workH else workW
        val outH = if (swapAxes) workW else workH

        val outBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val outCanvas = Canvas(outBitmap)
        outCanvas.save()
        outCanvas.translate(outW / 2f, outH / 2f)
        outCanvas.rotate(rot.toFloat())
        outCanvas.scale(
            if (snapshot.transform.flipH) -1f else 1f,
            if (snapshot.transform.flipV) -1f else 1f,
        )
        outCanvas.drawBitmap(workBitmap, -workW / 2f, -workH / 2f, Paint(Paint.FILTER_BITMAP_FLAG))
        outCanvas.restore()
        workBitmap.recycle()

        // Step 4: Text & Sticker Overlays
        if (includeOverlays && (snapshot.textLayers.isNotEmpty() || snapshot.stickerLayers.isNotEmpty())) {
            drawOverlays(outCanvas, outW, outH, snapshot.textLayers, snapshot.stickerLayers)
        }

        outBitmap
    }

    /**
     * Photorealistically composites an RGBA subject cutout onto a new background with:
     * - Perspective & horizon vertical alignment (horizonShift)
     * - Camera-distance matched depth-of-field blur
     * - Two-zone ambient light sampling (upper key + lower ground bounce)
     * - Directional subject relighting + skin-protected color temperature matching
     * - Halo-free hair/clothing edge decontamination & rim light wrap
     * - Grounded Ambient Occlusion contact shadow + perspective-flattened directional cast shadow
     * - Exact 1:1 original subject position, size & proportions at subjectScale == 100
     */
    private fun compositeSubjectWithBackground(
        context: Context,
        targetCanvas: Canvas,
        w: Int,
        h: Int,
        cutoutBitmap: Bitmap,
        bg: BackgroundState,
    ) {
        val geo = SubjectSegmenterEngine.measureCutoutGeometry(cutoutBitmap)

        if (bg.categoryId == BackgroundCategoryId.TRANSPARENT) {
            drawScaledSubject(targetCanvas, cutoutBitmap, w, h, bg.blend.subjectScale, geo)
            return
        }

        val preset = StudioPresets.presetFor(bg.categoryId)
        val horizonShift = bg.blend.horizonShift
        val lightDir = bg.blend.lightingDirection

        // 1. Render background onto offscreen bitmap with perspective horizon shift & DoF blur
        val bgBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val bgCanvas = Canvas(bgBitmap)

        val backdropSource: Bitmap? = when {
            bg.categoryId == BackgroundCategoryId.CUSTOM_UPLOAD && bg.customBackdropBitmap != null ->
                bg.customBackdropBitmap
            preset.assetPath != null ->
                runCatching { loadBitmapFromAsset(context, preset.assetPath) }.getOrNull()
            else -> null
        }

        val blurRadius = ((bg.blend.backgroundBlur / 100f) * max(w, h) * 0.016f).roundToInt().coerceIn(0, 28)

        if (backdropSource != null) {
            val shiftPx = (horizonShift / 100f) * h * 0.45f
            val overscanX = if (blurRadius > 0) blurRadius * 2f else 0f
            val overscanY = abs(shiftPx) + if (blurRadius > 0) blurRadius * 2f else 0f
            val drawW = w + overscanX * 2f
            val drawH = h + overscanY * 2f
            val coverScale = max(drawW / backdropSource.width, drawH / backdropSource.height)
            val sw = backdropSource.width * coverScale
            val sh = backdropSource.height * coverScale
            val dx = (w - sw) / 2f
            val dy = (h - sh) / 2f + shiftPx
            bgCanvas.drawBitmap(
                backdropSource,
                null,
                RectF(dx, dy, dx + sw, dy + sh),
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG),
            )
        } else {
            drawProceduralBackdrop(bgCanvas, w, h, preset, bg.passportColorArgb, horizonShift)
        }

        val finalBg = if (blurRadius > 1) {
            val blurred = fastBlurBitmap(bgBitmap, blurRadius)
            bgBitmap.recycle()
            blurred
        } else {
            bgBitmap
        }

        targetCanvas.drawBitmap(finalBg, 0f, 0f, null)

        // Sample two-zone ambient light (upper sky/key + lower ground bounce)
        val sample = Bitmap.createScaledBitmap(finalBg, 24, 24, true)
        val sPixels = IntArray(24 * 24)
        sample.getPixels(sPixels, 0, 24, 0, 0, 24, 24)
        sample.recycle()
        finalBg.recycle()

        var tr = 0f; var tg = 0f; var tb = 0f
        var gr = 0f; var gg = 0f; var gb = 0f
        val halfN = 24f * 12f
        for (y in 0 until 24) {
            for (x in 0 until 24) {
                val c = sPixels[y * 24 + x]
                if (y < 12) {
                    tr += Color.red(c); tg += Color.green(c); tb += Color.blue(c)
                } else {
                    gr += Color.red(c); gg += Color.green(c); gb += Color.blue(c)
                }
            }
        }
        val ambR = (tr * 0.65f + gr * 0.35f) / halfN
        val ambG = (tg * 0.65f + gg * 0.35f) / halfN
        val ambB = (tb * 0.65f + gb * 0.35f) / halfN
        val groundR = gr / halfN
        val groundG = gg / halfN
        val groundB = gb / halfN
        val ambLum = (0.299f * ambR + 0.587f * ambG + 0.114f * ambB) / 255f

        // 2. Render subject cutout at exact preserved position & size for directional relighting
        val subBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val subCanvas = Canvas(subBitmap)
        drawScaledSubject(subCanvas, cutoutBitmap, w, h, bg.blend.subjectScale, geo)

        val lightStrength = bg.blend.lightMatch / 100f
        val colorStrength = bg.blend.colorMatch / 100f
        val edgeStrength = bg.blend.edgeRefine / 100f

        if (lightStrength > 0f || colorStrength > 0f || edgeStrength > 0f) {
            val pixels = IntArray(w * h)
            subBitmap.getPixels(pixels, 0, w, 0, 0, w, h)

            var subLumSum = 0.0
            var subPixels = 0
            var idx = 0
            while (idx < pixels.size) {
                val c = pixels[idx]
                if (Color.alpha(c) > 180) {
                    subLumSum += (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
                    subPixels++
                }
                idx += 4
            }
            val subLum = if (subPixels > 0) (subLumSum / subPixels).toFloat() else 0.5f
            val baseLumRatio = (1f + (ambLum - subLum) * 0.42f * lightStrength).coerceIn(0.84f, 1.18f)

            val dirX = when (lightDir) {
                LightingDirection.LEFT, LightingDirection.TOP_LEFT -> -1f
                LightingDirection.RIGHT, LightingDirection.TOP_RIGHT -> 1f
                else -> 0f
            }
            val dirY = if (lightDir == LightingDirection.TOP_LEFT || lightDir == LightingDirection.TOP_RIGHT) -0.6f else 0f
            val isBacklit = lightDir == LightingDirection.BACKLIT

            val tintR = (ambR - 128f) * 0.14f * colorStrength
            val tintG = (ambG - 128f) * 0.14f * colorStrength
            val tintB = (ambB - 128f) * 0.14f * colorStrength

            val subMinX = geo.minX * w
            val subSpanX = max(1f, geo.widthRatio * w)
            val subMinY = geo.minY * h
            val subSpanY = max(1f, geo.heightRatio * h)

            for (y in 0 until h) {
                val ny = (y - subMinY) / subSpanY
                val groundBounce = ((ny - 0.55f) / 0.45f).coerceIn(0f, 1f) * 0.08f * colorStrength
                val row = y * w
                for (x in 0 until w) {
                    val p = pixels[row + x]
                    var a = Color.alpha(p)
                    if (a == 0) continue

                    val nx = (x - subMinX) / subSpanX
                    val directionalBias = ((nx - 0.5f) * dirX * 0.085f + (ny - 0.5f) * dirY * 0.05f) * lightStrength
                    val lumRatio = baseLumRatio + directionalBias

                    var r = Color.red(p) * lumRatio
                    var g = Color.green(p) * lumRatio
                    var b = Color.blue(p) * lumRatio

                    val isSkin = r > 78f && g > 40f && b > 22f && r > g && r > b && r - min(g, b) > 14f
                    val castScale = if (isSkin) 0.55f else 1.0f

                    r += tintR * castScale + (groundR - 128f) * groundBounce
                    g += tintG * castScale + (groundG - 128f) * groundBounce
                    b += tintB * castScale + (groundB - 128f) * groundBounce

                    if (a < 238 && edgeStrength > 0f) {
                        val fringeNorm = 1f - a / 238f
                        val wrapBoost = if (isBacklit) 0.62f else 0.44f
                        val fringe = fringeNorm * wrapBoost * edgeStrength
                        r = r * (1f - fringe) + ambR * fringe
                        g = g * (1f - fringe) + ambG * fringe
                        b = b * (1f - fringe) + ambB * fringe

                        if (a < 42) {
                            a = (a * (1f - edgeStrength * 0.48f)).roundToInt().coerceIn(0, 255)
                        }
                    }

                    pixels[row + x] = Color.argb(
                        a,
                        r.roundToInt().coerceIn(0, 255),
                        g.roundToInt().coerceIn(0, 255),
                        b.roundToInt().coerceIn(0, 255),
                    )
                }
            }
            subBitmap.setPixels(pixels, 0, w, 0, 0, w, h)
        }

        // 3. Physically grounded Ambient Occlusion contact shadow & perspective cast shadow
        val shadowStrength = bg.blend.shadowDepth / 100f
        val scaleFactor = bg.blend.subjectScale / 100f

        if (shadowStrength > 0.02f && bg.categoryId != BackgroundCategoryId.PASSPORT_ID) {
            val groundY = min(h * 0.99f, geo.maxY * h)
            val contactLeftX = geo.contactMinX * w
            val contactRightX = geo.contactMaxX * w
            val contactCenterX = (contactLeftX + contactRightX) / 2f
            val contactWidth = max(w * 0.1f, (contactRightX - contactLeftX) * scaleFactor)

            if (geo.isGroundedInFrame) {
                // A. Perspective-flattened directional cast shadow projected away from key light
                val shColor = Color.rgb(
                    max(10, (groundR * 0.12f).roundToInt()),
                    max(14, (groundG * 0.14f).roundToInt()),
                    max(22, (groundB * 0.20f).roundToInt()),
                )
                val skewX = when (lightDir) {
                    LightingDirection.LEFT, LightingDirection.TOP_LEFT -> 0.42f
                    LightingDirection.RIGHT, LightingDirection.TOP_RIGHT -> -0.42f
                    LightingDirection.BACKLIT -> 0f
                    else -> 0.14f
                }
                val squashY = if (lightDir == LightingDirection.BACKLIT) 0.26f else 0.19f
                val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    colorFilter = PorterDuffColorFilter(shColor, PorterDuff.Mode.SRC_IN)
                    alpha = (0.28f * shadowStrength * 255f).roundToInt().coerceIn(0, 255)
                    maskFilter = BlurMaskFilter(max(4f, max(w, h) * 0.015f), BlurMaskFilter.Blur.NORMAL)
                }
                targetCanvas.save()
                targetCanvas.translate(contactCenterX, groundY)
                targetCanvas.concat(Matrix().apply {
                    setValues(floatArrayOf(1f, skewX, 0f, 0f, squashY, 0f, 0f, 0f, 1f))
                })
                targetCanvas.translate(-contactCenterX, -groundY)
                targetCanvas.drawBitmap(subBitmap, 0f, 0f, shadowPaint)
                targetCanvas.restore()

                // B. Tight Ambient Occlusion contact shadow anchored beneath feet / base
                val aoRx = contactWidth * 0.58f
                val aoRy = (contactWidth * 0.14f).coerceIn(6f, h * 0.055f)
                val aoOffsetX = when (lightDir) {
                    LightingDirection.LEFT, LightingDirection.TOP_LEFT -> aoRx * 0.10f
                    LightingDirection.RIGHT, LightingDirection.TOP_RIGHT -> -aoRx * 0.10f
                    else -> 0f
                }
                targetCanvas.save()
                targetCanvas.translate(contactCenterX + aoOffsetX, groundY - aoRy * 0.1f)
                targetCanvas.scale(1f, aoRy / max(1f, aoRx))
                val aoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(
                        0f, 0f, max(1f, aoRx),
                        intArrayOf(
                            Color.argb((0.52f * shadowStrength * 255).roundToInt(), 12, 18, 30),
                            Color.argb((0.24f * shadowStrength * 255).roundToInt(), 15, 23, 42),
                            Color.TRANSPARENT,
                        ),
                        floatArrayOf(0.08f, 0.55f, 1f),
                        Shader.TileMode.CLAMP,
                    )
                }
                targetCanvas.drawCircle(0f, 0f, aoRx, aoPaint)
                targetCanvas.restore()
            } else if (shadowStrength > 0.18f) {
                // Bottom-cropped portrait: subtle lower depth vignette only (no floating cutout halo)
                val torsoCx = geo.centerX * w
                val torsoCy = h * 0.78f
                val rad = max(w, h) * 0.42f
                val depthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(
                        torsoCx, torsoCy, max(1f, rad),
                        Color.argb((0.14f * shadowStrength * 255).roundToInt(), 15, 23, 42),
                        Color.TRANSPARENT,
                        Shader.TileMode.CLAMP,
                    )
                }
                targetCanvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), depthPaint)
            }
        }

        // 4. Composite harmonized subject sharply over grounded shadows
        targetCanvas.drawBitmap(subBitmap, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        subBitmap.recycle()
    }

    private fun drawScaledSubject(
        canvas: Canvas,
        cutout: Bitmap,
        w: Int,
        h: Int,
        subjectScalePct: Int,
        geo: CutoutGeometry,
    ) {
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        if (subjectScalePct == 100) {
            canvas.drawBitmap(cutout, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), paint)
            return
        }
        val scale = subjectScalePct / 100f
        val dw = w * scale
        val dh = h * scale
        val anchorX = geo.centerX * w
        val anchorY = geo.maxY * h
        val dx = anchorX - anchorX * scale
        val dy = anchorY - anchorY * scale
        canvas.drawBitmap(cutout, null, RectF(dx, dy, dx + dw, dy + dh), paint)
    }

    private fun drawProceduralBackdrop(
        canvas: Canvas,
        w: Int,
        h: Int,
        preset: BackgroundPreset,
        passportColorArgb: Int,
        horizonShiftPct: Int,
    ) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val shiftY = (horizonShiftPct / 100f) * hf * 0.45f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        if (preset.proceduralStyle == ProceduralStyle.PASSPORT) {
            paint.color = passportColorArgb
            canvas.drawRect(0f, 0f, wf, hf, paint)
            paint.shader = RadialGradient(
                wf * 0.5f, hf * 0.42f, max(wf, hf) * 0.78f,
                Color.argb(30, 255, 255, 255),
                Color.argb(12, 15, 23, 42),
                Shader.TileMode.CLAMP,
            )
            canvas.drawRect(0f, 0f, wf, hf, paint)
            return
        }

        val (c0, c1, c2) = preset.gradientColors
        val midStop = (0.58f + shiftY / max(1f, hf)).coerceIn(0.2f, 0.85f)
        paint.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(c0, c1, c2),
            floatArrayOf(0f, midStop, 1f),
            Shader.TileMode.CLAMP,
        )
        canvas.drawRect(0f, 0f, wf, hf, paint)
        paint.shader = null

        when (preset.proceduralStyle) {
            ProceduralStyle.PRODUCT_PODIUM -> {
                val hLine = (hf * 0.68f + shiftY).coerceIn(hf * 0.42f, hf * 0.86f)
                paint.shader = LinearGradient(0f, hLine, 0f, hf, 0xFFE2E8F0.toInt(), 0xFFCBD5E1.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, hLine, wf, hf, paint)
                paint.shader = null
                paint.color = Color.argb(215, 255, 255, 255)
                paint.strokeWidth = max(2f, hf * 0.003f)
                canvas.drawLine(0f, hLine, wf, hLine, paint)
            }
            ProceduralStyle.BEACH_HORIZON -> {
                val hLine = (hf * 0.54f + shiftY).coerceIn(hf * 0.32f, hf * 0.72f)
                val shore = min(hf * 0.9f, hLine + hf * 0.2f)
                paint.shader = LinearGradient(0f, 0f, 0f, hLine, 0xFFBAE6FD.toInt(), 0xFFF0F9FF.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, wf, hLine, paint)
                paint.shader = LinearGradient(0f, hLine, 0f, shore, 0xFF0284C7.toInt(), 0xFFA5F3FC.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, hLine, wf, shore, paint)
                paint.shader = LinearGradient(0f, shore, 0f, hf, 0xFFF5EBD6.toInt(), 0xFFDECBA8.toInt(), Shader.TileMode.CLAMP)
                canvas.drawRect(0f, shore, wf, hf, paint)
            }
            ProceduralStyle.NATURE_BOKEH, ProceduralStyle.CINEMATIC_TEAL -> {
                val isNature = preset.proceduralStyle == ProceduralStyle.NATURE_BOKEH
                val orbs = if (isNature) {
                    listOf(
                        Triple(0.18f, 0.22f, Color.argb(110, 254, 249, 195)),
                        Triple(0.76f, 0.18f, Color.argb(95, 220, 252, 231)),
                        Triple(0.84f, 0.55f, Color.argb(72, 134, 239, 172)),
                    )
                } else {
                    listOf(
                        Triple(0.16f, 0.34f, Color.argb(115, 251, 146, 60)),
                        Triple(0.82f, 0.28f, Color.argb(92, 56, 189, 248)),
                        Triple(0.68f, 0.56f, Color.argb(102, 253, 186, 116)),
                    )
                }
                orbs.forEach { (ox, oy, col) ->
                    val cx = wf * ox
                    val cy = hf * oy + shiftY * 0.5f
                    val r = wf * 0.18f
                    paint.shader = RadialGradient(cx, cy, max(1f, r), col, Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    canvas.drawCircle(cx, cy, r, paint)
                }
            }
            else -> {
                paint.shader = RadialGradient(
                    wf * 0.42f, hf * 0.34f + shiftY * 0.4f, max(wf, hf) * 0.72f,
                    Color.argb(120, 255, 255, 255),
                    Color.argb(80, 15, 23, 42),
                    Shader.TileMode.CLAMP,
                )
                canvas.drawRect(0f, 0f, wf, hf, paint)
            }
        }
    }

    /**
     * Applies all 16 real photographic light, color, skin, clarity, denoise, and sharpness adjustments in-place.
     */
    fun applyColorAdjustmentsInPlace(bitmap: Bitmap, adj: ColorAdjustments) {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        if (adj.noiseReduction > 0) {
            applyEdgePreservingDenoise(pixels, w, h, adj.noiseReduction / 100f)
        }

        val hasColorOrLight =
            adj.exposure != 0 || adj.brightness != 0 || adj.contrast != 0 ||
                adj.highlights != 0 || adj.shadows != 0 || adj.whites != 0 || adj.blacks != 0 ||
                adj.saturation != 0 || adj.vibrance != 0 || adj.temperature != 0 ||
                adj.tint != 0 || adj.colorBalance != 0 || adj.skinTone != 0

        if (hasColorOrLight) {
            val expMul = 2.0.pow(adj.exposure / 65.0).toFloat()
            val brightAdd = adj.brightness * 1.15f
            val contrastFactor = ((100f + adj.contrast * 0.85f) / 100f).coerceAtLeast(0.05f).toDouble().pow(1.35).toFloat()
            val highlightsVal = adj.highlights * 0.65f
            val shadowsVal = adj.shadows * 0.72f
            val whitesVal = adj.whites * 0.55f
            val blacksVal = adj.blacks * 0.55f
            val satMul = 1f + adj.saturation / 100f
            val vibAmt = adj.vibrance / 100f
            val tempR = adj.temperature * 0.58f
            val tempB = -adj.temperature * 0.58f
            val tintG = -adj.tint * 0.42f
            val tintRB = adj.tint * 0.22f
            val balAmt = adj.colorBalance / 100f
            val skinAmt = adj.skinTone / 100f

            for (i in pixels.indices) {
                val p = pixels[i]
                val a = Color.alpha(p)
                if (a == 0) continue

                var r = Color.red(p) * expMul + brightAdd
                var g = Color.green(p) * expMul + brightAdd
                var b = Color.blue(p) * expMul + brightAdd

                val lum = ((0.299f * r + 0.587f * g + 0.114f * b) / 255f).coerceIn(0f, 1f)

                var toneDelta = 0f
                if (shadowsVal != 0f) toneDelta += (1f - smoothstep(0.05f, 0.58f, lum)) * shadowsVal
                if (highlightsVal != 0f) toneDelta += smoothstep(0.45f, 0.95f, lum) * highlightsVal
                if (blacksVal != 0f) toneDelta += (1f - smoothstep(0f, 0.28f, lum)) * blacksVal
                if (whitesVal != 0f) toneDelta += smoothstep(0.72f, 1f, lum) * whitesVal
                if (toneDelta != 0f) { r += toneDelta; g += toneDelta; b += toneDelta }

                if (adj.contrast != 0) {
                    r = (r - 128f) * contrastFactor + 128f
                    g = (g - 128f) * contrastFactor + 128f
                    b = (b - 128f) * contrastFactor + 128f
                }

                if (adj.temperature != 0 || adj.tint != 0) {
                    r += tempR + tintRB
                    g += tintG
                    b += tempB + tintRB
                }

                if (balAmt != 0f) {
                    val splitHi = smoothstep(0.45f, 0.95f, lum)
                    val splitSh = 1f - smoothstep(0.05f, 0.55f, lum)
                    r += (splitHi * 18f - splitSh * 10f) * balAmt
                    g += splitHi * 5f * balAmt
                    b += (-splitHi * 14f + splitSh * 16f) * balAmt
                }

                if (skinAmt != 0f) {
                    val rn = r.coerceIn(0f, 255f)
                    val gn = g.coerceIn(0f, 255f)
                    val bn = b.coerceIn(0f, 255f)
                    if (rn > 75f && gn > 38f && bn > 20f && rn > gn && rn > bn && rn - min(gn, bn) > 12f) {
                        val mask = min(1f, (rn - gn) / 55f) * smoothstep(0.15f, 0.85f, lum)
                        r += skinAmt * 14f * mask
                        g += skinAmt * 10f * mask
                        b += skinAmt * 4f * mask
                    }
                }

                if (adj.saturation != 0 || adj.vibrance != 0) {
                    val gray = 0.299f * r + 0.587f * g + 0.114f * b
                    val maxC = max(r, max(g, b))
                    val minC = min(r, min(g, b))
                    val curSat = if (maxC > 0f) (maxC - minC) / max(1f, maxC) else 0f
                    val isSkin = r > g && g > b && r - b > 18f
                    val vibBoost = vibAmt * (1f - curSat) * if (isSkin) 0.45f else 1f
                    val totalSat = max(0f, satMul + vibBoost)
                    r = gray + (r - gray) * totalSat
                    g = gray + (g - gray) * totalSat
                    b = gray + (b - gray) * totalSat
                }

                pixels[i] = Color.argb(
                    a,
                    r.roundToInt().coerceIn(0, 255),
                    g.roundToInt().coerceIn(0, 255),
                    b.roundToInt().coerceIn(0, 255),
                )
            }
        }

        if (adj.sharpness > 0 || adj.clarity != 0) {
            applyDetailConvolution(pixels, w, h, adj.sharpness / 100f, adj.clarity / 100f)
        }

        bitmap.setPixels(pixels, 0, w, 0, 0, w, h)
    }

    private fun applyEdgePreservingDenoise(pixels: IntArray, w: Int, h: Int, amount: Float) {
        val copy = pixels.copyOf()
        val strength = min(0.85f, amount * 0.85f)
        val threshold = (24f + amount * 26f) * 3f
        val offsets = intArrayOf(-1, 1, -w, w)

        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val idx = row + x
                val c = copy[idx]
                val a = Color.alpha(c)
                if (a == 0) continue
                val cr = Color.red(c)
                val cg = Color.green(c)
                val cb = Color.blue(c)

                var sr = cr.toFloat()
                var sg = cg.toFloat()
                var sb = cb.toFloat()
                var wSum = 1f

                for (off in offsets) {
                    val nc = copy[idx + off]
                    val nr = Color.red(nc)
                    val ng = Color.green(nc)
                    val nb = Color.blue(nc)
                    val diff = abs(nr - cr) + abs(ng - cg) + abs(nb - cb)
                    if (diff < threshold) {
                        val wt = 1f - diff / threshold
                        sr += nr * wt; sg += ng * wt; sb += nb * wt; wSum += wt
                    }
                }
                pixels[idx] = Color.argb(
                    a,
                    (cr + (sr / wSum - cr) * strength).roundToInt().coerceIn(0, 255),
                    (cg + (sg / wSum - cg) * strength).roundToInt().coerceIn(0, 255),
                    (cb + (sb / wSum - cb) * strength).roundToInt().coerceIn(0, 255),
                )
            }
        }
    }

    private fun applyDetailConvolution(pixels: IntArray, w: Int, h: Int, sharpness: Float, clarity: Float) {
        val copy = pixels.copyOf()
        val sharpGain = sharpness * 0.9f
        val clarityGain = clarity * 0.55f

        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val idx = row + x
                val c = copy[idx]
                val a = Color.alpha(c)
                if (a == 0) continue
                val t = copy[idx - w]; val b = copy[idx + w]; val l = copy[idx - 1]; val r = copy[idx + 1]

                fun filterChannel(cc: Int, tc: Int, bc: Int, lc: Int, rc: Int): Int {
                    val avg = (tc + bc + lc + rc) * 0.25f
                    val hi = cc - avg
                    var v = cc + hi * sharpGain
                    if (clarityGain != 0f) {
                        val midWeight = 1f - abs(cc - 128f) / 128f
                        v += hi * clarityGain * (0.4f + 0.6f * midWeight)
                    }
                    return v.roundToInt().coerceIn(0, 255)
                }

                pixels[idx] = Color.argb(
                    a,
                    filterChannel(Color.red(c), Color.red(t), Color.red(b), Color.red(l), Color.red(r)),
                    filterChannel(Color.green(c), Color.green(t), Color.green(b), Color.green(l), Color.green(r)),
                    filterChannel(Color.blue(c), Color.blue(t), Color.blue(b), Color.blue(l), Color.blue(r)),
                )
            }
        }
    }

    /**
     * Fast separable box blur (2 passes approximates Gaussian DoF smoothly on Android 8.0+ without RenderScript).
     */
    private fun fastBlurBitmap(source: Bitmap, radius: Int): Bitmap {
        val downScale = if (max(source.width, source.height) > 720) 0.5f else 1f
        val sw = max(2, (source.width * downScale).roundToInt())
        val sh = max(2, (source.height * downScale).roundToInt())
        val small = Bitmap.createScaledBitmap(source, sw, sh, true)
        val r = max(1, (radius * downScale).roundToInt())
        val pix = IntArray(sw * sh)
        small.getPixels(pix, 0, sw, 0, 0, sw, sh)
        val tmp = IntArray(sw * sh)

        repeat(2) {
            // Horizontal pass
            for (y in 0 until sh) {
                val row = y * sw
                var sr = 0; var sg = 0; var sb = 0
                val span = r * 2 + 1
                for (dx in -r..r) {
                    val c = pix[row + dx.coerceIn(0, sw - 1)]
                    sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c)
                }
                for (x in 0 until sw) {
                    tmp[row + x] = Color.rgb(sr / span, sg / span, sb / span)
                    val outC = pix[row + (x - r).coerceIn(0, sw - 1)]
                    val inC = pix[row + (x + r + 1).coerceIn(0, sw - 1)]
                    sr += Color.red(inC) - Color.red(outC)
                    sg += Color.green(inC) - Color.green(outC)
                    sb += Color.blue(inC) - Color.blue(outC)
                }
            }
            // Vertical pass
            for (x in 0 until sw) {
                var sr = 0; var sg = 0; var sb = 0
                val span = r * 2 + 1
                for (dy in -r..r) {
                    val c = tmp[dy.coerceIn(0, sh - 1) * sw + x]
                    sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c)
                }
                for (y in 0 until sh) {
                    pix[y * sw + x] = Color.rgb(sr / span, sg / span, sb / span)
                    val outC = tmp[(y - r).coerceIn(0, sh - 1) * sw + x]
                    val inC = tmp[(y + r + 1).coerceIn(0, sh - 1) * sw + x]
                    sr += Color.red(inC) - Color.red(outC)
                    sg += Color.green(inC) - Color.green(outC)
                    sb += Color.blue(inC) - Color.blue(outC)
                }
            }
        }
        small.setPixels(pix, 0, sw, 0, 0, sw, sh)
        val out = Bitmap.createScaledBitmap(small, source.width, source.height, true)
        small.recycle()
        return out
    }

    /**
     * Genuine Brush Object Removal:
     * Onion-peel boundary propagation + iterative harmonic relaxation + surrounding micro-grain transfer.
     */
    suspend fun inpaintMaskedRegion(baseBitmap: Bitmap, maskBitmap: Bitmap): Bitmap =
        withContext(Dispatchers.Default) {
            val w = baseBitmap.width
            val h = baseBitmap.height
            val out = baseBitmap.copy(Bitmap.Config.ARGB_8888, true)
            val scaledMask = if (maskBitmap.width == w && maskBitmap.height == h) {
                maskBitmap
            } else {
                Bitmap.createScaledBitmap(maskBitmap, w, h, true)
            }

            val pixels = IntArray(w * h)
            val maskPixels = IntArray(w * h)
            out.getPixels(pixels, 0, w, 0, 0, w, h)
            scaledMask.getPixels(maskPixels, 0, w, 0, 0, w, h)
            if (scaledMask !== maskBitmap) scaledMask.recycle()

            val mask = ByteArray(w * h)
            var minX = w; var minY = h; var maxX = 0; var maxY = 0; var maskedCount = 0
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    if (Color.alpha(maskPixels[row + x]) > 28) {
                        mask[row + x] = 1
                        maskedCount++
                        if (x < minX) minX = x; if (x > maxX) maxX = x
                        if (y < minY) minY = y; if (y > maxY) maxY = y
                    }
                }
            }
            if (maskedCount == 0) return@withContext out

            minX = max(1, minX - 2); minY = max(1, minY - 2)
            maxX = min(w - 2, maxX + 2); maxY = min(h - 2, maxY + 2)

            val rBuf = FloatArray(w * h)
            val gBuf = FloatArray(w * h)
            val bBuf = FloatArray(w * h)
            val known = ByteArray(w * h)
            for (i in pixels.indices) {
                rBuf[i] = Color.red(pixels[i]).toFloat()
                gBuf[i] = Color.green(pixels[i]).toFloat()
                bBuf[i] = Color.blue(pixels[i]).toFloat()
                known[i] = if (mask[i].toInt() == 1) 0 else 1
            }

            // Phase 1: Onion-peel inward fill
            var remaining = maskedCount
            val nextKnown = ArrayList<Int>(1024)
            val maxSteps = max(maxX - minX, maxY - minY) + 12
            for (step in 0 until maxSteps) {
                if (remaining <= 0) break
                nextKnown.clear()
                for (y in minY..maxY) {
                    val row = y * w
                    for (x in minX..maxX) {
                        val idx = row + x
                        if (known[idx].toInt() == 1) continue
                        var sr = 0f; var sg = 0f; var sb = 0f; var wtSum = 0f
                        for (dy in -1..1) {
                            for (dx in -1..1) {
                                if (dx == 0 && dy == 0) continue
                                val nIdx = (y + dy) * w + (x + dx)
                                if (known[nIdx].toInt() == 1) {
                                    val wt = if (dx == 0 || dy == 0) 1.4f else 1f
                                    sr += rBuf[nIdx] * wt; sg += gBuf[nIdx] * wt; sb += bBuf[nIdx] * wt
                                    wtSum += wt
                                }
                            }
                        }
                        if (wtSum > 0f) {
                            rBuf[idx] = sr / wtSum; gBuf[idx] = sg / wtSum; bBuf[idx] = sb / wtSum
                            nextKnown.add(idx)
                        }
                    }
                }
                if (nextKnown.isEmpty()) break
                for (k in nextKnown) known[k] = 1
                remaining -= nextKnown.size
            }

            // Phase 2: Iterative harmonic relaxation
            repeat(22) {
                for (y in minY..maxY) {
                    val row = y * w
                    for (x in minX..maxX) {
                        val idx = row + x
                        if (mask[idx].toInt() == 0) continue
                        rBuf[idx] = (rBuf[idx - w] + rBuf[idx + w] + rBuf[idx - 1] + rBuf[idx + 1]) * 0.25f
                        gBuf[idx] = (gBuf[idx - w] + gBuf[idx + w] + gBuf[idx - 1] + gBuf[idx + 1]) * 0.25f
                        bBuf[idx] = (bBuf[idx - w] + bBuf[idx + w] + bBuf[idx - 1] + bBuf[idx + 1]) * 0.25f
                    }
                }
            }

            // Phase 3: Subtle organic micro-grain matching surrounding area
            var grainAcc = 0f; var grainSamples = 0
            for (y in minY..maxY step 2) {
                val row = y * w
                for (x in minX..maxX step 2) {
                    val idx = row + x
                    if (mask[idx].toInt() == 0) {
                        grainAcc += abs(rBuf[idx] - rBuf[idx + 1])
                        grainSamples++
                    }
                }
            }
            val grainAmp = min(6.5f, (grainAcc / max(1, grainSamples)) * 0.6f)
            var seed = 1337L
            for (y in minY..maxY) {
                val row = y * w
                for (x in minX..maxX) {
                    val idx = row + x
                    if (mask[idx].toInt() == 0) continue
                    val n = if (grainAmp > 0.8f) {
                        seed = (seed * 16807L) % 2147483647L
                        ((seed.toFloat() / 2147483647f) * 2f - 1f) * grainAmp
                    } else 0f
                    pixels[idx] = Color.argb(
                        Color.alpha(pixels[idx]),
                        (rBuf[idx] + n).roundToInt().coerceIn(0, 255),
                        (gBuf[idx] + n).roundToInt().coerceIn(0, 255),
                        (bBuf[idx] + n).roundToInt().coerceIn(0, 255),
                    )
                }
            }

            out.setPixels(pixels, 0, w, 0, 0, w, h)
            out
        }

    fun cropBitmap(source: Bitmap, crop: CropRect): Bitmap {
        val sx = (crop.x * source.width).roundToInt().coerceIn(0, source.width - 16)
        val sy = (crop.y * source.height).roundToInt().coerceIn(0, source.height - 16)
        val sw = (crop.width * source.width).roundToInt().coerceIn(16, source.width - sx)
        val sh = (crop.height * source.height).roundToInt().coerceIn(16, source.height - sy)
        return Bitmap.createBitmap(source, sx, sy, sw, sh)
    }

    private fun drawOverlays(
        canvas: Canvas,
        w: Int,
        h: Int,
        textLayers: List<TextLayer>,
        stickerLayers: List<StickerLayer>,
    ) {
        val refDim = min(w, h).toFloat()

        // Vector Studio Stickers
        for (layer in stickerLayers) {
            val preset = StudioPresets.stickers.firstOrNull { it.id == layer.stickerId } ?: continue
            val cx = (layer.xPct / 100f) * w
            val cy = (layer.yPct / 100f) * h
            val boxW = refDim * 0.30f * layer.scale
            val boxH = refDim * 0.11f * layer.scale

            canvas.save()
            canvas.translate(cx, cy)
            canvas.rotate(layer.rotationDeg)

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = preset.primaryColor }
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = preset.accentColor
                style = Paint.Style.STROKE
                strokeWidth = max(2f, refDim * 0.006f)
            }
            val rect = RectF(-boxW / 2f, -boxH / 2f, boxW / 2f, boxH / 2f)
            val corner = boxH * 0.32f
            canvas.drawRoundRect(rect, corner, corner, bgPaint)
            canvas.drawRoundRect(rect, corner, corner, borderPaint)

            val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = preset.accentColor
                textSize = boxH * 0.44f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                letterSpacing = 0.08f
            }
            val fm = txtPaint.fontMetrics
            canvas.drawText(preset.badgeText, 0f, -(fm.ascent + fm.descent) / 2f, txtPaint)
            canvas.restore()
        }

        // Text Layers
        for (layer in textLayers) {
            if (layer.text.isBlank()) continue
            val fontPx = max(14f, (layer.fontSizeSp / 400f) * refDim)
            val cx = (layer.xPct / 100f) * w
            val cy = (layer.yPct / 100f) * h

            val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = layer.colorArgb
                textSize = fontPx
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                if (layer.bgStyle == TextBgStyle.NONE) {
                    setShadowLayer(max(4f, fontPx * 0.22f), 0f, 2f, Color.argb(140, 15, 23, 42))
                }
            }

            val lines = layer.text.split("\n")
            val lineHeight = fontPx * 1.24f
            val maxW = lines.maxOfOrNull { txtPaint.measureText(it) } ?: 0f
            val blockH = lines.size * lineHeight

            if (layer.bgStyle != TextBgStyle.NONE) {
                val padX = fontPx * 0.55f
                val padY = fontPx * 0.32f
                val bgRect = RectF(
                    cx - maxW / 2f - padX,
                    cy - blockH / 2f - padY,
                    cx + maxW / 2f + padX,
                    cy + blockH / 2f + padY,
                )
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = if (layer.bgStyle == TextBgStyle.SOLID) {
                        Color.argb(215, 15, 23, 42)
                    } else {
                        Color.argb(185, 255, 255, 255)
                    }
                }
                canvas.drawRoundRect(bgRect, min(16f, fontPx * 0.35f), min(16f, fontPx * 0.35f), bgPaint)
            }

            val fm = txtPaint.fontMetrics
            val baselineOffset = -(fm.ascent + fm.descent) / 2f
            lines.forEachIndexed { idx, line ->
                val ly = cy - ((lines.size - 1) * lineHeight) / 2f + idx * lineHeight + baselineOffset
                canvas.drawText(line, cx, ly, txtPaint)
            }
        }
    }

    /**
     * Saves the full-resolution edited photo to Android Gallery (Pictures/BT Kite) on Android 8.0–15.
     */
    suspend fun saveSnapshotToGallery(
        context: Context,
        snapshot: EditorSnapshot,
        format: ExportFormat,
        jpegQuality: Int,
    ): String = withContext(Dispatchers.IO) {
        val exportSnapshot = if (format == ExportFormat.TRANSPARENT_PNG && snapshot.cutoutBitmap != null) {
            snapshot.copy(background = snapshot.background.copy(categoryId = BackgroundCategoryId.TRANSPARENT))
        } else {
            snapshot
        }

        val bitmap = renderSnapshotToBitmap(context, exportSnapshot, maxDimension = null, includeOverlays = true)
        val filename = "BT_Kite_${System.currentTimeMillis()}.${format.extension}"
        val compressFormat = if (format == ExportFormat.JPEG) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG
        val quality = if (format == ExportFormat.JPEG) jpegQuality.coerceIn(60, 100) else 100

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, format.mimeType)
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/BT Kite")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create MediaStore entry.")
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(compressFormat, quality, out)
                } ?: throw IllegalStateException("Could not write to gallery output stream.")
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                "Saved $filename (${bitmap.width}×${bitmap.height}) to Pictures/BT Kite"
            } else {
                @Suppress("DEPRECATION")
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "BT Kite",
                )
                if (!dir.exists()) dir.mkdirs()
                val outFile = File(dir, filename)
                FileOutputStream(outFile).use { out ->
                    bitmap.compress(compressFormat, quality, out)
                }
                "Saved $filename (${bitmap.width}×${bitmap.height}) to Pictures/BT Kite"
            }
        } finally {
            bitmap.recycle()
        }
    }

    private fun smoothstep(edge0: Float, edge1: Float, x: Float): Float {
        val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}
