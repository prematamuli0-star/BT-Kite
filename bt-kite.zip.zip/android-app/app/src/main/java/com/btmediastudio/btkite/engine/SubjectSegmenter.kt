package com.btmediastudio.btkite.engine

import android.graphics.Bitmap
import android.graphics.Color
import com.btmediastudio.btkite.model.CutoutGeometry
import com.btmediastudio.btkite.model.SubjectPosition
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * On-device neural subject segmentation powered by Google ML Kit Subject Segmentation.
 * Runs locally on Android 8.0+ without requiring any paid API key.
 */
object SubjectSegmenterEngine {

    private val segmenter by lazy {
        val options = SubjectSegmenterOptions.Builder()
            .enableForegroundConfidenceMask()
            .enableForegroundBitmap()
            .build()
        SubjectSegmentation.getClient(options)
    }

    suspend fun removeBackground(source: Bitmap): Bitmap = withContext(Dispatchers.Default) {
        val safeSource = if (source.config == Bitmap.Config.ARGB_8888) {
            source
        } else {
            source.copy(Bitmap.Config.ARGB_8888, false)
        }

        val inputImage = InputImage.fromBitmap(safeSource, 0)
        val result = segmenter.process(inputImage).await()

        val maskBuffer = result.foregroundConfidenceMask
        if (maskBuffer != null) {
            val w = safeSource.width
            val h = safeSource.height
            val pixels = IntArray(w * h)
            safeSource.getPixels(pixels, 0, w, 0, 0, w, h)
            maskBuffer.rewind()

            val out = IntArray(w * h)
            for (i in 0 until w * h) {
                val confidence = if (maskBuffer.hasRemaining()) maskBuffer.float else 0f
                // Soft smoothstep matte around fine hair & clothing boundaries
                val alphaNorm = smoothstep(0.18f, 0.78f, confidence)
                val alpha = (alphaNorm * 255f).roundToInt().coerceIn(0, 255)
                val rgb = pixels[i] and 0x00FFFFFF
                out[i] = (alpha shl 24) or rgb
            }
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
                setPixels(out, 0, w, 0, 0, w, h)
            }
        } else {
            result.foregroundBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                ?: throw IllegalStateException("Subject segmentation returned no foreground mask.")
        }
    }

    /**
     * Measures exact normalized subject bounding box, horizontal centroid, ground contact footprint,
     * and whether the subject's feet/base stop inside the frame.
     */
    fun measureCutoutGeometry(cutout: Bitmap): CutoutGeometry {
        val sampleW = 180
        val sampleH = max(80, ((cutout.height.toFloat() / max(1, cutout.width)) * sampleW).roundToInt())
        val scaled = Bitmap.createScaledBitmap(cutout, sampleW, sampleH, true)
        val pixels = IntArray(sampleW * sampleH)
        scaled.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        if (scaled !== cutout) scaled.recycle()

        var minX = sampleW
        var maxX = 0
        var minY = sampleH
        var maxY = 0
        var sumX = 0L
        var count = 0

        for (y in 0 until sampleH) {
            val rowOffset = y * sampleW
            for (x in 0 until sampleW) {
                val a = Color.alpha(pixels[rowOffset + x])
                if (a > 80) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                    sumX += x
                    count++
                }
            }
        }

        if (count < 25 || maxX <= minX || maxY <= minY) {
            return CutoutGeometry(
                minX = 0.25f, maxX = 0.75f, minY = 0.12f, maxY = 0.98f,
                centerX = 0.5f, widthRatio = 0.5f, heightRatio = 0.86f,
                contactMinX = 0.32f, contactMaxX = 0.68f, isGroundedInFrame = false,
            )
        }

        val bandTop = max(minY, (maxY - (maxY - minY) * 0.07f).toInt())
        var cMinX = sampleW
        var cMaxX = 0
        var cCount = 0
        for (y in bandTop..maxY) {
            val rowOffset = y * sampleW
            for (x in minX..maxX) {
                if (Color.alpha(pixels[rowOffset + x]) > 80) {
                    if (x < cMinX) cMinX = x
                    if (x > cMaxX) cMaxX = x
                    cCount++
                }
            }
        }

        val nMinX = minX.toFloat() / sampleW
        val nMaxX = maxX.toFloat() / sampleW
        val nMinY = minY.toFloat() / sampleH
        val nMaxY = maxY.toFloat() / sampleH
        val nCenterX = (sumX.toFloat() / count) / sampleW

        return CutoutGeometry(
            minX = nMinX,
            maxX = nMaxX,
            minY = nMinY,
            maxY = nMaxY,
            centerX = nCenterX,
            widthRatio = max(0.05f, nMaxX - nMinX),
            heightRatio = max(0.05f, nMaxY - nMinY),
            contactMinX = if (cCount > 8) cMinX.toFloat() / sampleW else nMinX + (nMaxX - nMinX) * 0.15f,
            contactMaxX = if (cCount > 8) cMaxX.toFloat() / sampleW else nMaxX - (nMaxX - nMinX) * 0.15f,
            isGroundedInFrame = nMaxY < 0.965f,
        )
    }

    fun classifyHorizontalPosition(centerX: Float): SubjectPosition = when {
        centerX < 0.34f -> SubjectPosition.LEFT
        centerX < 0.45f -> SubjectPosition.CENTER_LEFT
        centerX <= 0.55f -> SubjectPosition.CENTER
        centerX <= 0.66f -> SubjectPosition.CENTER_RIGHT
        else -> SubjectPosition.RIGHT
    }

    private fun smoothstep(edge0: Float, edge1: Float, x: Float): Float {
        val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }
}
