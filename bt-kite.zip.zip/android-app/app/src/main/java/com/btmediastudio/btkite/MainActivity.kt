package com.btmediastudio.btkite

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.btmediastudio.btkite.ui.EditorScreen
import com.btmediastudio.btkite.ui.HomeScreen
import com.btmediastudio.btkite.ui.theme.BTKiteTheme
import com.btmediastudio.btkite.viewmodel.EditorViewModel
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BTKiteTheme {
                val vm: EditorViewModel = viewModel()
                val uiState by vm.uiState.collectAsState()
                var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

                val photoPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia(),
                ) { uri ->
                    if (uri != null) vm.openPhotoUri(uri)
                }

                val customBackdropLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia(),
                ) { uri ->
                    if (uri != null) vm.applyCustomBackdropUri(uri)
                }

                val cameraLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.TakePicture(),
                ) { success ->
                    val captured = pendingCameraUri
                    if (success && captured != null) {
                        vm.openPhotoUri(captured)
                    }
                }

                val launchCamera = {
                    val dir = File(cacheDir, "captures").apply { mkdirs() }
                    val file = File(dir, "bt_kite_capture_${System.currentTimeMillis()}.jpg")
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                    pendingCameraUri = uri
                    cameraLauncher.launch(uri)
                }

                val cameraPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission(),
                ) { granted ->
                    if (granted) launchCamera()
                }

                if (uiState.present == null) {
                    HomeScreen(
                        onPickFromGallery = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                            )
                        },
                        onCaptureFromCamera = {
                            val hasPerm = ContextCompat.checkSelfPermission(
                                this,
                                Manifest.permission.CAMERA,
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPerm) {
                                launchCamera()
                            } else {
                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        },
                        onSelectSample = { assetPath -> vm.openSamplePhoto(assetPath) },
                    )
                } else {
                    EditorScreen(
                        state = uiState,
                        viewModel = vm,
                        onPickCustomBackdrop = {
                            customBackdropLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                            )
                        },
                    )
                }
            }
        }
    }
}
