package com.btmediastudio.btkite.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.btmediastudio.btkite.data.StudioPresets
import com.btmediastudio.btkite.engine.ImageEngine
import com.btmediastudio.btkite.engine.SceneAnalyzer
import com.btmediastudio.btkite.engine.SubjectSegmenterEngine
import com.btmediastudio.btkite.model.BackgroundBlendSettings
import com.btmediastudio.btkite.model.BackgroundCategoryId
import com.btmediastudio.btkite.model.ColorAdjustments
import com.btmediastudio.btkite.model.ColorStyleId
import com.btmediastudio.btkite.model.CropRect
import com.btmediastudio.btkite.model.EditorSnapshot
import com.btmediastudio.btkite.model.ExportFormat
import com.btmediastudio.btkite.model.PhotoAnalysisResult
import com.btmediastudio.btkite.model.ProcessingStatus
import com.btmediastudio.btkite.model.StickerLayer
import com.btmediastudio.btkite.model.TextBgStyle
import com.btmediastudio.btkite.model.TextLayer
import com.btmediastudio.btkite.model.ToolTab
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EditorUiState(
    val sourceBitmap: Bitmap? = null,
    val present: EditorSnapshot? = null,
    val previewBitmap: Bitmap? = null,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val activeTab: ToolTab = ToolTab.AI,
    val compareMode: Boolean = false,
    val compareSplit: Float = 0.5f,
    val zoom: Float = 1f,
    val analysis: PhotoAnalysisResult? = null,
    val analyzingScene: Boolean = false,
    val processing: ProcessingStatus = ProcessingStatus(),
    val statusMessage: String? = null,
    val isErrorBanner: Boolean = false,
    val brushActive: Boolean = false,
    val brushSizePx: Float = 36f,
    val cropRect: CropRect = CropRect(),
    val selectedTextId: String? = null,
    val selectedStickerId: String? = null,
    val showExportSheet: Boolean = false,
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    private val past = ArrayDeque<EditorSnapshot>()
    private val future = ArrayDeque<EditorSnapshot>()
    private var pendingHistoryBase: EditorSnapshot? = null
    private var renderJob: Job? = null
    private var activeTaskJob: Job? = null

    fun openSamplePhoto(assetPath: String) {
        viewModelScope.launch {
            runCatching {
                ImageEngine.loadBitmapFromAsset(getApplication(), assetPath)
            }.onSuccess { bmp ->
                openBitmap(bmp)
            }.onFailure { err ->
                postMessage(err.message ?: "Unable to open sample photo.", isError = true)
            }
        }
    }

    fun openPhotoUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    processing = ProcessingStatus(true, "Loading Photo", "Reading full-resolution image...", 0.4f),
                )
            }
            runCatching {
                ImageEngine.loadBitmapFromUri(getApplication(), uri, maxDimension = 2200)
            }.onSuccess { bmp ->
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                openBitmap(bmp)
            }.onFailure { err ->
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(err.message ?: "Unable to load selected photo.", isError = true)
            }
        }
    }

    private fun openBitmap(bitmap: Bitmap) {
        past.clear()
        future.clear()
        pendingHistoryBase = null
        val initial = EditorSnapshot(baseBitmap = bitmap, label = "Original")
        _uiState.value = EditorUiState(
            sourceBitmap = bitmap,
            present = initial,
            previewBitmap = bitmap,
            activeTab = ToolTab.AI,
        )
        schedulePreviewRender(initial)
        analyzeCurrentScene(initial.baseBitmap, initial.cutoutBitmap)
    }

    fun closeEditor() {
        activeTaskJob?.cancel()
        renderJob?.cancel()
        past.clear()
        future.clear()
        _uiState.value = EditorUiState()
    }

    fun setActiveTab(tab: ToolTab) {
        _uiState.update {
            it.copy(
                activeTab = tab,
                brushActive = if (tab != ToolTab.AI) false else it.brushActive,
            )
        }
    }

    fun toggleCompareMode() {
        _uiState.update { it.copy(compareMode = !it.compareMode, brushActive = false) }
    }

    fun setCompareSplit(split: Float) {
        _uiState.update { it.copy(compareSplit = split.coerceIn(0.05f, 0.95f)) }
    }

    fun setZoom(zoom: Float) {
        _uiState.update { it.copy(zoom = zoom.coerceIn(1f, 3f)) }
    }

    fun setShowExportSheet(show: Boolean) {
        _uiState.update { it.copy(showExportSheet = show) }
    }

    fun clearBanner() {
        _uiState.update { it.copy(statusMessage = null, isErrorBanner = false) }
    }

    fun cancelActiveTask() {
        activeTaskJob?.cancel()
        activeTaskJob = null
        _uiState.update {
            it.copy(
                processing = ProcessingStatus(),
                statusMessage = "Operation cancelled. Your photo was not changed.",
                isErrorBanner = false,
            )
        }
    }

    private fun postMessage(text: String, isError: Boolean = false) {
        _uiState.update { it.copy(statusMessage = text, isErrorBanner = isError) }
    }

    private fun commitSnapshot(next: EditorSnapshot) {
        val current = _uiState.value.present
        if (current != null) {
            if (past.size >= 30) past.removeFirst()
            past.addLast(current)
            future.clear()
        }
        pendingHistoryBase = null
        _uiState.update {
            it.copy(
                present = next,
                canUndo = past.isNotEmpty(),
                canRedo = false,
            )
        }
        schedulePreviewRender(next)
    }

    private fun updateLive(commit: Boolean, transform: (EditorSnapshot) -> EditorSnapshot) {
        val curr = _uiState.value.present ?: return
        val next = transform(curr)
        if (commit) {
            val base = pendingHistoryBase ?: curr
            if (past.size >= 30) past.removeFirst()
            past.addLast(base)
            future.clear()
            pendingHistoryBase = null
        } else if (pendingHistoryBase == null) {
            pendingHistoryBase = curr
        }
        _uiState.update {
            it.copy(
                present = next,
                canUndo = past.isNotEmpty(),
                canRedo = future.isNotEmpty(),
            )
        }
        schedulePreviewRender(next)
    }

    fun undo() {
        val current = _uiState.value.present ?: return
        if (past.isEmpty()) return
        val prev = past.removeLast()
        future.addFirst(current)
        pendingHistoryBase = null
        _uiState.update {
            it.copy(
                present = prev,
                canUndo = past.isNotEmpty(),
                canRedo = future.isNotEmpty(),
            )
        }
        schedulePreviewRender(prev)
    }

    fun redo() {
        val current = _uiState.value.present ?: return
        if (future.isEmpty()) return
        val next = future.removeFirst()
        past.addLast(current)
        pendingHistoryBase = null
        _uiState.update {
            it.copy(
                present = next,
                canUndo = past.isNotEmpty(),
                canRedo = future.isNotEmpty(),
            )
        }
        schedulePreviewRender(next)
    }

    private fun schedulePreviewRender(snapshot: EditorSnapshot) {
        renderJob?.cancel()
        renderJob = viewModelScope.launch {
            delay(18)
            runCatching {
                ImageEngine.renderSnapshotToBitmap(
                    context = getApplication(),
                    snapshot = snapshot,
                    maxDimension = 1080,
                    includeOverlays = true,
                )
            }.onSuccess { rendered ->
                _uiState.update { it.copy(previewBitmap = rendered) }
            }
        }
    }

    fun refreshSceneAnalysis() {
        val snap = _uiState.value.present ?: return
        analyzeCurrentScene(snap.baseBitmap, snap.cutoutBitmap)
    }

    private fun analyzeCurrentScene(bitmap: Bitmap, cutout: Bitmap?) {
        viewModelScope.launch {
            _uiState.update { it.copy(analyzingScene = true) }
            runCatching {
                SceneAnalyzer.analyzePhoto(bitmap, cutout)
            }.onSuccess { result ->
                _uiState.update { it.copy(analysis = result, analyzingScene = false) }
            }.onFailure {
                _uiState.update { it.copy(analyzingScene = false) }
            }
        }
    }

    // FEATURE 1: INTELLIGENT ONE-TAP AUTO BACKGROUND
    fun runAutoBackground() {
        val snap = _uiState.value.present ?: return
        activeTaskJob?.cancel()
        activeTaskJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    brushActive = false,
                    processing = ProcessingStatus(
                        active = true,
                        title = "Auto Background",
                        detail = "Analyzing subject pose, position, angle & lighting direction...",
                        progress = 0.15f,
                    ),
                )
            }
            try {
                var scene = _uiState.value.analysis ?: SceneAnalyzer.analyzePhoto(snap.baseBitmap)
                _uiState.update { it.copy(analysis = scene) }

                val preset = StudioPresets.presetFor(scene.recommendedBackgroundId)
                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(
                            active = true,
                            title = "Auto Background",
                            detail = "Matched ${preset.name} (${scene.poseDetail}) · Isolating subject...",
                            progress = 0.42f,
                        ),
                    )
                }

                val cutout = snap.cutoutBitmap ?: SubjectSegmenterEngine.removeBackground(snap.baseBitmap)

                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(
                            active = true,
                            title = "Auto Background",
                            detail = "Aligning perspective horizon, lighting & grounded shadows...",
                            progress = 0.85f,
                        ),
                    )
                }

                scene = SceneAnalyzer.refineWithCutout(scene, cutout)
                _uiState.update { it.copy(analysis = scene) }

                val autoBlend = StudioPresets.computeAutoBlendForScene(
                    preset = preset,
                    cameraDistance = scene.cameraDistance,
                    groundLevelY = scene.groundLevelY,
                    horizonY = scene.horizonY,
                    lightingDirection = scene.lightingDirection,
                )

                commitSnapshot(
                    snap.copy(
                        cutoutBitmap = cutout,
                        background = snap.background.copy(
                            categoryId = preset.id,
                            blend = BackgroundBlendSettings(
                                lightMatch = 72,
                                colorMatch = 60,
                                shadowDepth = autoBlend.shadowDepth,
                                backgroundBlur = autoBlend.backgroundBlur,
                                edgeRefine = 52,
                                subjectScale = 100, // Exact original position & proportions
                                horizonShift = autoBlend.horizonShift,
                                lightingDirection = autoBlend.lightingDirection,
                            ),
                        ),
                        label = "Auto BG: ${preset.name}",
                    ),
                )

                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(),
                        compareMode = true,
                        compareSplit = 0.5f,
                        activeTab = ToolTab.BACKGROUND,
                        statusMessage = "Auto Background matched ${preset.name} (${scene.poseDetail}).",
                        isErrorBanner = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(e.message ?: "Background segmentation could not complete.", isError = true)
            }
        }
    }

    fun selectBackgroundCategory(categoryId: BackgroundCategoryId) {
        val snap = _uiState.value.present ?: return
        val preset = StudioPresets.presetFor(categoryId)

        if (categoryId == BackgroundCategoryId.ORIGINAL) {
            commitSnapshot(snap.copy(background = snap.background.copy(categoryId = categoryId), label = "Original BG"))
            return
        }

        activeTaskJob?.cancel()
        activeTaskJob = viewModelScope.launch {
            try {
                val cutout = if (snap.cutoutBitmap != null) {
                    snap.cutoutBitmap
                } else {
                    _uiState.update {
                        it.copy(
                            processing = ProcessingStatus(
                                active = true,
                                title = "Applying ${preset.name}",
                                detail = "Isolating subject and measuring position & perspective...",
                                progress = 0.45f,
                            ),
                        )
                    }
                    SubjectSegmenterEngine.removeBackground(snap.baseBitmap)
                }

                if (categoryId == BackgroundCategoryId.TRANSPARENT) {
                    commitSnapshot(
                        snap.copy(
                            cutoutBitmap = cutout,
                            background = snap.background.copy(categoryId = BackgroundCategoryId.TRANSPARENT),
                            label = "Transparent Cutout",
                        ),
                    )
                    _uiState.update {
                        it.copy(
                            processing = ProcessingStatus(),
                            statusMessage = "Background removed. Export as Cutout Transparent PNG anytime.",
                            isErrorBanner = false,
                        )
                    }
                    return@launch
                }

                val baseScene = _uiState.value.analysis ?: SceneAnalyzer.analyzePhoto(snap.baseBitmap, cutout)
                val refined = SceneAnalyzer.refineWithCutout(baseScene, cutout)
                _uiState.update { it.copy(analysis = refined) }

                val autoBlend = StudioPresets.computeAutoBlendForScene(
                    preset = preset,
                    cameraDistance = refined.cameraDistance,
                    groundLevelY = refined.groundLevelY,
                    horizonY = refined.horizonY,
                    lightingDirection = refined.lightingDirection,
                )

                commitSnapshot(
                    snap.copy(
                        cutoutBitmap = cutout,
                        background = snap.background.copy(
                            categoryId = categoryId,
                            blend = snap.background.blend.copy(
                                backgroundBlur = autoBlend.backgroundBlur,
                                shadowDepth = autoBlend.shadowDepth,
                                horizonShift = autoBlend.horizonShift,
                                lightingDirection = autoBlend.lightingDirection,
                                subjectScale = 100,
                            ),
                        ),
                        label = "BG: ${preset.name}",
                    ),
                )
                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(),
                        statusMessage = "Blended into ${preset.name} with matched perspective & lighting.",
                        isErrorBanner = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(e.message ?: "Unable to apply background.", isError = true)
            }
        }
    }

    fun applyCustomBackdropUri(uri: Uri) {
        val snap = _uiState.value.present ?: return
        activeTaskJob?.cancel()
        activeTaskJob = viewModelScope.launch {
            _uiState.update {
                it.copy(processing = ProcessingStatus(true, "Custom Backdrop", "Loading image & isolating subject...", 0.4f))
            }
            try {
                val customBmp = ImageEngine.loadBitmapFromUri(getApplication(), uri, maxDimension = 2000)
                val cutout = snap.cutoutBitmap ?: SubjectSegmenterEngine.removeBackground(snap.baseBitmap)
                commitSnapshot(
                    snap.copy(
                        cutoutBitmap = cutout,
                        background = snap.background.copy(
                            categoryId = BackgroundCategoryId.CUSTOM_UPLOAD,
                            customBackdropBitmap = customBmp,
                        ),
                        label = "Custom Backdrop",
                    ),
                )
                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(),
                        statusMessage = "Applied your custom background photo.",
                        isErrorBanner = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(e.message ?: "Unable to load custom backdrop.", isError = true)
            }
        }
    }

    fun applyPromptMatchedBackground(prompt: String) {
        if (prompt.isBlank()) return
        val matched = StudioPresets.matchPromptToBackgroundPreset(prompt)
        selectBackgroundCategory(matched.id)
    }

    fun selectPassportColor(argb: Int) {
        val snap = _uiState.value.present ?: return
        commitSnapshot(snap.copy(background = snap.background.copy(passportColorArgb = argb), label = "Passport Color"))
    }

    fun updateBlend(commit: Boolean = false, updater: (BackgroundBlendSettings) -> BackgroundBlendSettings) {
        updateLive(commit) { curr ->
            curr.copy(background = curr.background.copy(blend = updater(curr.background.blend)))
        }
    }

    // FEATURE 2: AI COLOR TUNE
    fun runAIColorTune() {
        val snap = _uiState.value.present ?: return
        activeTaskJob?.cancel()
        activeTaskJob = viewModelScope.launch {
            _uiState.update {
                it.copy(processing = ProcessingStatus(true, "AI Color Tune", "Analyzing exposure, white balance & skin tones...", 0.4f))
            }
            try {
                val res = SceneAnalyzer.analyzePhoto(snap.baseBitmap, snap.cutoutBitmap)
                _uiState.update { it.copy(analysis = res) }
                commitSnapshot(
                    snap.copy(
                        adjustments = res.adjustments,
                        styleId = res.recommendedStyleId,
                        styleIntensity = 45,
                        label = "AI Color Tune",
                    ),
                )
                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(),
                        compareMode = true,
                        compareSplit = 0.5f,
                        statusMessage = "AI Color Tune applied (${res.photoCategory} · ${res.engineLabel}).",
                        isErrorBanner = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(e.message ?: "AI Color Tune failed.", isError = true)
            }
        }
    }

    fun runAIEnhance() {
        val snap = _uiState.value.present ?: return
        viewModelScope.launch {
            val enhanced = SceneAnalyzer.computeAIEnhanceAdjustments(snap.baseBitmap)
            commitSnapshot(snap.copy(adjustments = enhanced, label = "AI Enhance"))
            _uiState.update {
                it.copy(compareMode = true, compareSplit = 0.5f, statusMessage = "AI Enhance applied.", isErrorBanner = false)
            }
        }
    }

    fun runPortraitEnhance() {
        val snap = _uiState.value.present ?: return
        viewModelScope.launch {
            val portraitAdj = SceneAnalyzer.computePortraitEnhanceAdjustments(snap.baseBitmap)
            commitSnapshot(
                snap.copy(
                    adjustments = portraitAdj,
                    styleId = ColorStyleId.PROFESSIONAL_PORTRAIT,
                    styleIntensity = 45,
                    label = "Portrait Enhance",
                ),
            )
            _uiState.update {
                it.copy(compareMode = true, compareSplit = 0.5f, statusMessage = "Portrait Enhance applied.", isErrorBanner = false)
            }
        }
    }

    fun updateAdjustments(commit: Boolean = false, updater: (ColorAdjustments) -> ColorAdjustments) {
        updateLive(commit) { curr -> curr.copy(adjustments = updater(curr.adjustments)) }
    }

    fun resetAdjustments() {
        val snap = _uiState.value.present ?: return
        commitSnapshot(snap.copy(adjustments = ColorAdjustments(), label = "Reset Adjustments"))
    }

    fun selectColorStyle(styleId: ColorStyleId) {
        val snap = _uiState.value.present ?: return
        commitSnapshot(
            snap.copy(
                styleId = styleId,
                styleIntensity = if (styleId == ColorStyleId.NONE) 0 else snap.styleIntensity.coerceAtLeast(65),
                label = "Style: ${styleId.displayName}",
            ),
        )
    }

    fun updateStyleIntensity(intensity: Int, commit: Boolean = false) {
        updateLive(commit) { curr -> curr.copy(styleIntensity = intensity.coerceIn(0, 100)) }
    }

    // BRUSH OBJECT REMOVAL
    fun toggleBrushMode(active: Boolean) {
        _uiState.update { it.copy(brushActive = active, compareMode = if (active) false else it.compareMode) }
    }

    fun setBrushSize(px: Float) {
        _uiState.update { it.copy(brushSizePx = px.coerceIn(12f, 80f)) }
    }

    fun applyObjectRemoval(maskBitmap: Bitmap) {
        val snap = _uiState.value.present ?: return
        activeTaskJob?.cancel()
        activeTaskJob = viewModelScope.launch {
            _uiState.update {
                it.copy(processing = ProcessingStatus(true, "Object Removal", "Reconstructing surrounding texture...", 0.55f))
            }
            try {
                val healed = ImageEngine.inpaintMaskedRegion(snap.baseBitmap, maskBitmap)
                commitSnapshot(snap.copy(baseBitmap = healed, cutoutBitmap = null, label = "Object Removal"))
                _uiState.update {
                    it.copy(
                        processing = ProcessingStatus(),
                        brushActive = false,
                        statusMessage = "Brushed object removed cleanly.",
                        isErrorBanner = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(e.message ?: "Object removal failed.", isError = true)
            }
        }
    }

    // CROP & TRANSFORM
    fun setCropRect(rect: CropRect) {
        _uiState.update { it.copy(cropRect = rect) }
    }

    fun selectCropAspectRatio(ratio: Float?) {
        val bmp = _uiState.value.previewBitmap ?: return
        if (ratio == null) {
            _uiState.update { it.copy(cropRect = CropRect()) }
            return
        }
        val imgAspect = bmp.width.toFloat() / bmp.height.coerceAtLeast(1)
        var w: Float
        var h: Float
        if (ratio > imgAspect) {
            w = 0.92f
            h = (w * imgAspect) / ratio
        } else {
            h = 0.92f
            w = (h * ratio) / imgAspect
        }
        w = w.coerceAtMost(1f)
        h = h.coerceAtMost(1f)
        _uiState.update { it.copy(cropRect = CropRect((1f - w) / 2f, (1f - h) / 2f, w, h)) }
    }

    fun applyCrop() {
        val snap = _uiState.value.present ?: return
        val crop = _uiState.value.cropRect
        if (!crop.isDirty) return
        val croppedBase = ImageEngine.cropBitmap(snap.baseBitmap, crop)
        val croppedCutout = snap.cutoutBitmap?.let { ImageEngine.cropBitmap(it, crop) }
        commitSnapshot(snap.copy(baseBitmap = croppedBase, cutoutBitmap = croppedCutout, label = "Cropped"))
        _uiState.update { it.copy(cropRect = CropRect(), statusMessage = "Crop applied.", isErrorBanner = false) }
        analyzeCurrentScene(croppedBase, croppedCutout)
    }

    fun rotate(deltaDeg: Int) {
        val snap = _uiState.value.present ?: return
        val nextRot = (snap.transform.rotationDegrees + deltaDeg + 360) % 360
        commitSnapshot(snap.copy(transform = snap.transform.copy(rotationDegrees = nextRot), label = "Rotate"))
    }

    fun flipHorizontal() {
        val snap = _uiState.value.present ?: return
        commitSnapshot(snap.copy(transform = snap.transform.copy(flipH = !snap.transform.flipH), label = "Flip H"))
    }

    fun flipVertical() {
        val snap = _uiState.value.present ?: return
        commitSnapshot(snap.copy(transform = snap.transform.copy(flipV = !snap.transform.flipV), label = "Flip V"))
    }

    // TEXT & STICKERS
    fun addTextLayer() {
        val snap = _uiState.value.present ?: return
        val id = "txt_${System.currentTimeMillis()}"
        val layer = TextLayer(id = id, text = "BT Kite Studio", bgStyle = TextBgStyle.SOLID)
        commitSnapshot(snap.copy(textLayers = snap.textLayers + layer, label = "Add Text"))
        _uiState.update { it.copy(selectedTextId = id) }
    }

    fun selectTextLayer(id: String?) {
        _uiState.update { it.copy(selectedTextId = id) }
    }

    fun updateTextLayer(id: String, commit: Boolean = false, updater: (TextLayer) -> TextLayer) {
        updateLive(commit) { curr ->
            curr.copy(textLayers = curr.textLayers.map { if (it.id == id) updater(it) else it })
        }
    }

    fun deleteTextLayer(id: String) {
        val snap = _uiState.value.present ?: return
        commitSnapshot(snap.copy(textLayers = snap.textLayers.filterNot { it.id == id }, label = "Delete Text"))
        _uiState.update { it.copy(selectedTextId = null) }
    }

    fun addStickerLayer(stickerId: String) {
        val snap = _uiState.value.present ?: return
        val id = "stk_${System.currentTimeMillis()}"
        val layer = StickerLayer(id = id, stickerId = stickerId)
        commitSnapshot(snap.copy(stickerLayers = snap.stickerLayers + layer, label = "Add Sticker"))
        _uiState.update { it.copy(selectedStickerId = id) }
    }

    fun selectStickerLayer(id: String?) {
        _uiState.update { it.copy(selectedStickerId = id) }
    }

    fun updateStickerLayer(id: String, commit: Boolean = false, updater: (StickerLayer) -> StickerLayer) {
        updateLive(commit) { curr ->
            curr.copy(stickerLayers = curr.stickerLayers.map { if (it.id == id) updater(it) else it })
        }
    }

    fun deleteStickerLayer(id: String) {
        val snap = _uiState.value.present ?: return
        commitSnapshot(snap.copy(stickerLayers = snap.stickerLayers.filterNot { it.id == id }, label = "Delete Sticker"))
        _uiState.update { it.copy(selectedStickerId = null) }
    }

    // HIGH-RES EXPORT
    fun exportPhoto(format: ExportFormat, jpegQuality: Int) {
        val snap = _uiState.value.present ?: return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    showExportSheet = false,
                    processing = ProcessingStatus(true, "Exporting High-Res Photo", "Rendering full resolution...", 0.65f),
                )
            }
            runCatching {
                ImageEngine.saveSnapshotToGallery(getApplication(), snap, format, jpegQuality)
            }.onSuccess { msg ->
                _uiState.update {
                    it.copy(processing = ProcessingStatus(), statusMessage = msg, isErrorBanner = false)
                }
            }.onFailure { err ->
                _uiState.update { it.copy(processing = ProcessingStatus()) }
                postMessage(err.message ?: "Export failed.", isError = true)
            }
        }
    }
}
