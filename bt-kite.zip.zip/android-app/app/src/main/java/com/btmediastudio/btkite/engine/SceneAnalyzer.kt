package com.btmediastudio.btkite.engine

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Base64
import com.btmediastudio.btkite.BuildConfig
import com.btmediastudio.btkite.data.StudioPresets
import com.btmediastudio.btkite.model.BackgroundCategoryId
import com.btmediastudio.btkite.model.CameraAngle
import com.btmediastudio.btkite.model.CameraDistance
import com.btmediastudio.btkite.model.ColorAdjustments
import com.btmediastudio.btkite.model.ColorStyleId
import com.btmediastudio.btkite.model.LightingDirection
import com.btmediastudio.btkite.model.PhotoAnalysisResult
import com.btmediastudio.btkite.model.RecommendedBackgroundItem
import com.btmediastudio.btkite.model.SubjectPose
import com.btmediastudio.btkite.model.SubjectPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Intelligent Photo Understanding & Color Analysis Engine.
 * Uses free-tier Gemini Vision (gemini-4-hydrogen) when GEMINI_API_KEY is supplied in local.properties,
 * and seamlessly runs BT Kite's genuine on-device computer-vision analyzer offline / without any API key.
 */
object SceneAnalyzer {

    suspend fun analyzePhoto(
        bitmap: Bitmap,
        optionalCutout: Bitmap? = null,
    ): PhotoAnalysisResult = withContext(Dispatchers.Default) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isNotBlank()) {
            val geminiResult = runCatching { analyzeWithGeminiVision(bitmap, apiKey) }.getOrNull()
            if (geminiResult != null) {
                return@withContext if (optionalCutout != null) {
                    refineWithCutout(geminiResult, optionalCutout)
                } else {
                    geminiResult
                }
            }
        }
        analyzeLocally(bitmap, optionalCutout)
    }

    fun refineWithCutout(analysis: PhotoAnalysisResult, cutout: Bitmap): PhotoAnalysisResult {
        val geo = SubjectSegmenterEngine.measureCutoutGeometry(cutout)
        val exactPosition = SubjectSegmenterEngine.classifyHorizontalPosition(geo.centerX)
        val exactGroundY = if (geo.isGroundedInFrame) geo.maxY else 1.0f

        val distance = if (analysis.engineLabel == "Local Vision") {
            if (geo.isGroundedInFrame) {
                if (geo.heightRatio < 0.55f) CameraDistance.WIDE_SHOT else CameraDistance.FULL_BODY
            } else {
                if (geo.widthRatio > 0.62f) CameraDistance.CLOSE_UP else CameraDistance.MEDIUM_SHOT
            }
        } else {
            analysis.cameraDistance
        }

        return analysis.copy(
            subjectPosition = exactPosition,
            groundLevelY = exactGroundY,
            cameraDistance = distance,
        )
    }

    fun analyzeLocally(
        bitmap: Bitmap,
        optionalCutout: Bitmap? = null,
    ): PhotoAnalysisResult {
        val sampleW = 160
        val sampleH = max(80, ((bitmap.height.toFloat() / max(1, bitmap.width)) * sampleW).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, true)
        val pixels = IntArray(sampleW * sampleH)
        scaled.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        if (scaled !== bitmap) scaled.recycle()

        val hist = IntArray(256)
        var totalPixels = 0
        var sumR = 0.0
        var sumG = 0.0
        var sumB = 0.0
        var sumLum = 0.0
        var sumSat = 0.0
        var skinPixels = 0
        var skinXSum = 0.0
        var skinYSum = 0.0
        var skyBluePixels = 0
        var greenNaturePixels = 0
        var centerEdgeStrength = 0.0

        var tlLum = 0.0; var tlCount = 0
        var trLum = 0.0; var trCount = 0
        var blLum = 0.0; var blCount = 0
        var brLum = 0.0; var brCount = 0
        var borderLum = 0.0; var borderCount = 0
        var centerLum = 0.0; var centerCount = 0
        var salientXSum = 0.0; var salientWeightSum = 0.0

        val halfW = sampleW / 2
        val halfH = sampleH / 2

        for (y in 0 until sampleH) {
            val row = y * sampleW
            for (x in 0 until sampleW) {
                val px = pixels[row + x]
                if (Color.alpha(px) < 128) continue
                val r = Color.red(px)
                val g = Color.green(px)
                val b = Color.blue(px)
                val lum = (0.299 * r + 0.587 * g + 0.114 * b).roundToInt().coerceIn(0, 255)
                hist[lum]++
                totalPixels++
                sumR += r; sumG += g; sumB += b; sumLum += lum

                if (y < halfH) {
                    if (x < halfW) { tlLum += lum; tlCount++ } else { trLum += lum; trCount++ }
                } else {
                    if (x < halfW) { blLum += lum; blCount++ } else { brLum += lum; brCount++ }
                }

                val isBorder = x < sampleW * 0.15 || x > sampleW * 0.85 || y < sampleH * 0.15
                if (isBorder) {
                    borderLum += lum; borderCount++
                } else if (x > sampleW * 0.28 && x < sampleW * 0.72 && y > sampleH * 0.22 && y < sampleH * 0.78) {
                    centerLum += lum; centerCount++
                }

                val maxC = max(r, max(g, b))
                val minC = min(r, min(g, b))
                if (maxC > 0) sumSat += (maxC - minC).toDouble() / maxC

                if (r > 85 && g > 42 && b > 24 && r > g && r > b &&
                    r - min(g, b) > 15 && abs(r - g) > 12 &&
                    y > sampleH * 0.08 && y < sampleH * 0.88
                ) {
                    skinPixels++
                    skinXSum += x.toDouble() / sampleW
                    skinYSum += y.toDouble() / sampleH
                }
                if (y < sampleH * 0.4 && b > r + 15 && b > 100) skyBluePixels++
                if (g > r + 12 && g > b + 12 && g > 55) greenNaturePixels++

                if (x in 1 until (sampleW - 1) && y > sampleH * 0.16 && y < sampleH * 0.86) {
                    val prev = pixels[row + x - 1]
                    val prevLum = 0.299 * Color.red(prev) + 0.587 * Color.green(prev) + 0.114 * Color.blue(prev)
                    val edge = abs(lum - prevLum)
                    if (y > sampleH * 0.2 && y < sampleH * 0.8) centerEdgeStrength += edge
                    if (edge > 14.0) {
                        salientXSum += (x.toDouble() / sampleW) * edge
                        salientWeightSum += edge
                    }
                }
            }
        }

        val count = max(1, totalPixels)
        val avgR = sumR / count
        val avgG = sumG / count
        val avgB = sumB / count
        val avgLum = sumLum / count
        val avgSat = sumSat / count
        val skinRatio = skinPixels.toDouble() / count
        val skyRatio = skyBluePixels.toDouble() / count
        val greenRatio = greenNaturePixels.toDouble() / count
        val avgEdge = centerEdgeStrength / (count * 0.6)

        val tlAvg = tlLum / max(1, tlCount)
        val trAvg = trLum / max(1, trCount)
        val blAvg = blLum / max(1, blCount)
        val brAvg = brLum / max(1, brCount)
        val leftAvg = (tlAvg + blAvg) / 2.0
        val rightAvg = (trAvg + brAvg) / 2.0
        val topAvg = (tlAvg + trAvg) / 2.0
        val botAvg = (blAvg + brAvg) / 2.0
        val borderAvg = borderLum / max(1, borderCount)
        val centerAvg = centerLum / max(1, centerCount)

        val lightingDirection: LightingDirection
        val lightingType: String
        when {
            borderAvg - centerAvg > 28 && borderAvg > 155 -> {
                lightingDirection = LightingDirection.BACKLIT
                lightingType = "Bright backlit ambient"
            }
            abs(leftAvg - rightAvg) > 12 -> {
                val fromLeft = leftAvg > rightAvg
                val fromTop = topAvg - botAvg > 12
                lightingDirection = when {
                    fromLeft && fromTop -> LightingDirection.TOP_LEFT
                    fromLeft -> LightingDirection.LEFT
                    fromTop -> LightingDirection.TOP_RIGHT
                    else -> LightingDirection.RIGHT
                }
                lightingType = if (fromTop) "Directional overhead daylight" else "Directional side key light"
            }
            topAvg - botAvg > 18 -> {
                lightingDirection = if (tlAvg >= trAvg) LightingDirection.TOP_LEFT else LightingDirection.TOP_RIGHT
                lightingType = "Natural overhead sunlight"
            }
            avgLum < 85 -> {
                lightingDirection = LightingDirection.TOP_RIGHT
                lightingType = "Low-key ambient lighting"
            }
            else -> {
                lightingDirection = LightingDirection.FRONT_DIFFUSED
                lightingType = "Soft diffused daylight"
            }
        }

        var acc = 0
        var p5 = 0
        var p95 = 255
        for (v in 0..255) {
            acc += hist[v]
            if (acc >= count * 0.05 && p5 == 0) p5 = v
            if (acc >= count * 0.95) {
                p95 = v
                break
            }
        }
        val dynamicRange = p95 - p5

        val cutoutGeo = optionalCutout?.let { SubjectSegmenterEngine.measureCutoutGeometry(it) }
        val estCenterX = when {
            cutoutGeo != null -> cutoutGeo.centerX
            skinPixels > 45 -> (skinXSum / skinPixels).toFloat()
            salientWeightSum > 0 -> (salientXSum / salientWeightSum).toFloat()
            else -> 0.5f
        }
        val subjectPosition = SubjectSegmenterEngine.classifyHorizontalPosition(estCenterX)
        val avgSkinY = if (skinPixels > 45) (skinYSum / skinPixels).toFloat() else 0.38f

        var photoCategory = "Portrait"
        var subjectDescription = "Main subject"
        var pose = SubjectPose.STANDING
        var poseDetail = "Standing natural posture"
        var cameraDistance = CameraDistance.MEDIUM_SHOT
        var cameraAngle = CameraAngle.EYE_LEVEL
        var originalEnvironment = "Indoor / daylight space"
        var horizonY = 0.52f
        var groundLevelY = cutoutGeo?.let { if (it.isGroundedInFrame) it.maxY else 1.0f } ?: 0.94f
        var recommendedStyleId = ColorStyleId.NATURAL
        val aspect = bitmap.width.toFloat() / max(1, bitmap.height)

        when {
            skinRatio > 0.055 -> {
                val isOutdoor = skyRatio > 0.08 || greenRatio > 0.10
                photoCategory = if (isOutdoor) "Travel & Outdoor Portrait" else "Portrait"
                subjectDescription = if (isOutdoor) "Person in outdoor scene" else "Portrait subject"
                originalEnvironment = when {
                    skyRatio > 0.10 -> "Open outdoor daylight scenery"
                    greenRatio > 0.12 -> "Natural greenery & outdoor setting"
                    avgLum < 95 -> "Evening ambient / indoor location"
                    else -> "Daylight portrait setting"
                }
                if (cutoutGeo != null) {
                    if (cutoutGeo.isGroundedInFrame) {
                        cameraDistance = if (cutoutGeo.heightRatio < 0.55f) CameraDistance.WIDE_SHOT else CameraDistance.FULL_BODY
                        val subAspect = cutoutGeo.widthRatio / max(0.1f, cutoutGeo.heightRatio)
                        if (subAspect > 0.62f) {
                            pose = SubjectPose.SITTING
                            poseDetail = "Seated relaxed posture"
                        } else {
                            pose = SubjectPose.STANDING
                            poseDetail = "Full-body standing posture"
                        }
                        groundLevelY = cutoutGeo.maxY
                        horizonY = (cutoutGeo.minY + cutoutGeo.heightRatio * 0.25f).coerceIn(0.32f, 0.62f)
                    } else {
                        cameraDistance = if (skinRatio > 0.18 || cutoutGeo.widthRatio > 0.62f) CameraDistance.CLOSE_UP else CameraDistance.MEDIUM_SHOT
                        pose = SubjectPose.POSING
                        poseDetail = if (cameraDistance == CameraDistance.CLOSE_UP) "Close-up portrait pose" else "Waist-up portrait pose"
                        groundLevelY = 1.0f
                        horizonY = 0.48f
                    }
                } else {
                    cameraDistance = when {
                        skinRatio > 0.18 -> CameraDistance.CLOSE_UP
                        avgSkinY > 0.45f -> CameraDistance.FULL_BODY
                        else -> CameraDistance.MEDIUM_SHOT
                    }
                    if (isOutdoor && aspect >= 1.15f) {
                        pose = SubjectPose.SITTING
                        poseDetail = "Relaxed seated / travel pose"
                        groundLevelY = 0.86f
                        horizonY = 0.44f
                    } else {
                        pose = if (cameraDistance == CameraDistance.CLOSE_UP) SubjectPose.POSING else SubjectPose.STANDING
                        poseDetail = if (cameraDistance == CameraDistance.CLOSE_UP) "Portrait head & shoulders" else "Natural upright pose"
                        groundLevelY = if (cameraDistance == CameraDistance.FULL_BODY) 0.88f else 1.0f
                    }
                }
                cameraAngle = if (avgSkinY > 0.48f) CameraAngle.SLIGHTLY_ELEVATED else CameraAngle.EYE_LEVEL
                recommendedStyleId = if (isOutdoor) ColorStyleId.GOLDEN_HOUR else ColorStyleId.PROFESSIONAL_PORTRAIT
            }
            avgLum < 72 -> {
                photoCategory = "Night & Street"
                subjectDescription = "Low-light subject"
                pose = SubjectPose.STANDING
                poseDetail = "Standing in low-light scene"
                originalEnvironment = "Evening / urban night lighting"
                horizonY = 0.54f
                recommendedStyleId = ColorStyleId.CINEMATIC
            }
            skyRatio > 0.14 || greenRatio > 0.18 -> {
                photoCategory = if (greenRatio > 0.22) "Nature & Travel" else "Travel Photography"
                subjectDescription = "Outdoor travel subject"
                pose = if (aspect > 1.1f) SubjectPose.SITTING else SubjectPose.STANDING
                poseDetail = if (aspect > 1.1f) "Outdoor scenic / seated framing" else "Outdoor standing framing"
                cameraDistance = CameraDistance.WIDE_SHOT
                cameraAngle = CameraAngle.SLIGHTLY_ELEVATED
                originalEnvironment = if (greenRatio > 0.22) "Lush outdoor nature scenery" else "Open sky outdoor location"
                horizonY = 0.44f
                groundLevelY = 0.84f
                recommendedStyleId = ColorStyleId.GOLDEN_HOUR
            }
            avgEdge > 11 && skinRatio < 0.03 -> {
                photoCategory = "Product Photography"
                subjectDescription = "Product / still-life object"
                pose = SubjectPose.OBJECT_STILL_LIFE
                poseDetail = "Resting on flat surface"
                cameraDistance = CameraDistance.CLOSE_UP
                cameraAngle = CameraAngle.SLIGHTLY_ELEVATED
                originalEnvironment = "Tabletop / studio surface"
                horizonY = 0.68f
                groundLevelY = cutoutGeo?.takeIf { it.isGroundedInFrame }?.maxY ?: 0.82f
                recommendedStyleId = ColorStyleId.MODERN
            }
            aspect > 1.15f -> {
                photoCategory = "Travel & Street"
                subjectDescription = "Subject in wide scene"
                pose = SubjectPose.STANDING
                poseDetail = "Wide environmental framing"
                cameraDistance = CameraDistance.WIDE_SHOT
                originalEnvironment = "Architectural / street environment"
                horizonY = 0.50f
                groundLevelY = 0.86f
                recommendedStyleId = ColorStyleId.CINEMATIC
            }
        }

        val ranked = StudioPresets.rankBackgroundsForScene(
            pose = pose,
            poseDetail = poseDetail,
            photoCategory = photoCategory,
            cameraDistance = cameraDistance,
            cameraAngle = cameraAngle,
            lightingDirection = lightingDirection,
            originalEnvironment = originalEnvironment,
            avgLuminance = (avgLum / 255.0).toFloat(),
        )

        val targetLum = if (photoCategory == "Night & Street") 105.0 else 132.0
        val exposureDelta = ((targetLum - avgLum) * 0.38).roundToInt().coerceIn(-24, 28)
        val brightnessDelta = ((targetLum - avgLum) * 0.15).roundToInt().coerceIn(-15, 18)
        val contrastDelta = when {
            dynamicRange < 155 -> ((175 - dynamicRange) * 0.22).roundToInt().coerceAtMost(24)
            dynamicRange > 225 -> -6
            else -> 8
        }
        val highlightsDelta = when {
            p95 > 235 -> -22
            p95 > 215 -> -10
            else -> 6
        }
        val shadowsDelta = when {
            p5 < 24 -> 26
            p5 < 42 -> 14
            else -> 4
        }
        val whitesDelta = if (p95 < 210) 14 else -4
        val blacksDelta = if (p5 > 36) -12 else 4

        val grayAvg = (avgR + avgG + avgB) / 3.0
        val rbCast = avgR - avgB
        val tempDelta = (-rbCast * 0.28 + if (skinRatio > 0.055) 4 else 0).roundToInt().coerceIn(-22, 22)
        val tintDelta = ((avgG - grayAvg) * 0.35).roundToInt().coerceIn(-14, 14)

        val adjustments = ColorAdjustments(
            exposure = exposureDelta,
            brightness = brightnessDelta,
            contrast = contrastDelta,
            highlights = highlightsDelta,
            shadows = shadowsDelta,
            whites = whitesDelta,
            blacks = blacksDelta,
            saturation = if (avgSat < 0.18) 8 else if (avgSat > 0.52) -8 else 2,
            vibrance = if (avgSat < 0.22) 22 else if (avgSat < 0.35) 12 else 4,
            temperature = tempDelta,
            tint = tintDelta,
            sharpness = if (avgEdge < 10) 24 else 14,
            clarity = if (skinRatio > 0.055) 6 else 14,
            colorBalance = if (skinRatio > 0.055) 6 else if (photoCategory == "Night & Street") -8 else 4,
            skinTone = if (skinRatio > 0.055) 14 else 0,
            noiseReduction = if (avgLum < 95) 24 else 8,
        )

        val notes = mutableListOf<String>()
        when {
            avgLum < 105 -> notes.add("lifted underexposed shadows")
            avgLum > 165 -> notes.add("recovered bright highlights")
            else -> notes.add("balanced exposure")
        }
        if (abs(rbCast) > 16) notes.add(if (rbCast > 0) "neutralized warm cast" else "warmed cool cast")
        if (dynamicRange < 165) notes.add("expanded tonal contrast")
        if (skinRatio > 0.055) notes.add("protected skin tones")

        return PhotoAnalysisResult(
            engineLabel = "Local Vision",
            photoCategory = photoCategory,
            subjectDescription = subjectDescription,
            pose = pose,
            poseDetail = poseDetail,
            subjectPosition = subjectPosition,
            cameraAngle = cameraAngle,
            cameraDistance = cameraDistance,
            lightingDirection = lightingDirection,
            lightingType = lightingType,
            originalEnvironment = originalEnvironment,
            horizonY = horizonY,
            groundLevelY = groundLevelY,
            lightingDiagnosis = "${photoCategory} (${lightingDirection.label.lowercase()} light): ${notes.joinToString(", ")}.",
            recommendedBackgroundId = ranked.firstOrNull()?.categoryId ?: BackgroundCategoryId.PROFESSIONAL_STUDIO,
            recommendedBackgrounds = ranked,
            recommendedStyleId = recommendedStyleId,
            adjustments = adjustments,
        )
    }

    fun computeAIEnhanceAdjustments(bitmap: Bitmap): ColorAdjustments {
        val base = analyzeLocally(bitmap).adjustments
        return base.copy(
            clarity = (base.clarity + 8).coerceIn(12, 35),
            sharpness = (base.sharpness + 10).coerceIn(18, 40),
            noiseReduction = max(14, base.noiseReduction),
            vibrance = (base.vibrance + 4).coerceIn(8, 26),
        )
    }

    fun computePortraitEnhanceAdjustments(bitmap: Bitmap): ColorAdjustments {
        val base = analyzeLocally(bitmap).adjustments
        return base.copy(
            exposure = (base.exposure + 4).coerceIn(4, 20),
            highlights = (base.highlights - 6).coerceAtMost(-6),
            shadows = (base.shadows + 8).coerceIn(14, 32),
            temperature = (base.temperature + 5).coerceIn(4, 18),
            skinTone = 22,
            clarity = 4,
            sharpness = 16,
            noiseReduction = 22,
            vibrance = base.vibrance.coerceIn(6, 18),
        )
    }

    private fun analyzeWithGeminiVision(bitmap: Bitmap, apiKey: String): PhotoAnalysisResult? {
        val maxSide = 640
        val scale = min(1f, maxSide.toFloat() / max(bitmap.width, bitmap.height))
        val w = max(1, (bitmap.width * scale).roundToInt())
        val h = max(1, (bitmap.height * scale).roundToInt())
        val resized = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val baos = ByteArrayOutputStream()
        resized.compress(Bitmap.CompressFormat.JPEG, 82, baos)
        if (resized !== bitmap) resized.recycle()
        val base64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

        val validBgIds = StudioPresets.backgroundPresets.joinToString(", ") { it.id.id }
        val prompt = """
            You are an expert commercial photographer inside BT Kite. Return strict JSON with:
            photoCategory, subjectDescription, pose (standing|sitting|walking|lying_down|leaning|posing|object_still_life),
            poseDetail, subjectPosition (left|center-left|center|center-right|right),
            cameraAngle (eye-level|slightly-elevated|low-angle|overhead),
            cameraDistance (close-up|medium-shot|full-body|wide-shot),
            lightingDirection (left|right|top-left|top-right|front-diffused|backlit),
            lightingType, originalEnvironment, horizonYPct (20..80), groundLevelYPct (55..100),
            lightingDiagnosis, recommendedBackgrounds (array of 5 objects {id, reason, matchScore} from [$validBgIds]),
            recommendedStyleId (natural|cinematic|professional-portrait|hdr|warm|cool|luxury|wedding|film|vintage|modern|vibrant|moody|soft|golden-hour),
            adjustments ({exposure,brightness,contrast,highlights,shadows,whites,blacks,saturation,vibrance,temperature,tint,sharpness,clarity,colorBalance,skinTone,noiseReduction}).
        """.trimIndent()

        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray()
                    .put(JSONObject().put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64)
                    }))
                    .put(JSONObject().put("text", prompt))
                )
            }))
            put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        }

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-4-hydrogen:generateContent?key=$apiKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 20_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }

        return try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val rawResponse = conn.inputStream.bufferedReader().use { it.readText() }
            val jsonText = JSONObject(rawResponse)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
            val parsed = JSONObject(jsonText)
            val adjObj = parsed.optJSONObject("adjustments") ?: JSONObject()

            val pose = SubjectPose.fromRaw(parsed.optString("pose", "standing"))
            val poseDetail = parsed.optString("poseDetail", pose.label)
            val photoCategory = parsed.optString("photoCategory", "Portrait")
            val cameraDistance = CameraDistance.fromRaw(parsed.optString("cameraDistance", "medium-shot"))
            val cameraAngle = CameraAngle.fromRaw(parsed.optString("cameraAngle", "eye-level"))
            val lightingDirection = LightingDirection.fromRaw(parsed.optString("lightingDirection", "top-left"))
            val originalEnvironment = parsed.optString("originalEnvironment", "Original scene")

            val recs = mutableListOf<RecommendedBackgroundItem>()
            val seen = mutableSetOf<BackgroundCategoryId>()
            val arr = parsed.optJSONArray("recommendedBackgrounds")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val cat = BackgroundCategoryId.fromId(item.optString("id"))
                    if (seen.add(cat)) {
                        val preset = StudioPresets.presetFor(cat)
                        recs.add(
                            RecommendedBackgroundItem(
                                categoryId = cat,
                                name = preset.name,
                                reason = item.optString("reason", preset.shortDesc),
                                matchScore = item.optInt("matchScore", 94 - i * 3).coerceIn(60, 99),
                            )
                        )
                    }
                }
            }
            if (recs.size < 5) {
                for (fb in StudioPresets.rankBackgroundsForScene(
                    pose, poseDetail, photoCategory, cameraDistance, cameraAngle, lightingDirection, originalEnvironment
                )) {
                    if (recs.size >= 5) break
                    if (seen.add(fb.categoryId)) recs.add(fb)
                }
            }

            val styleId = ColorStyleId.entries.firstOrNull {
                it.name.lowercase().replace('_', '-') == parsed.optString("recommendedStyleId", "natural").lowercase()
            } ?: ColorStyleId.NATURAL

            PhotoAnalysisResult(
                engineLabel = "Gemini Vision",
                photoCategory = photoCategory,
                subjectDescription = parsed.optString("subjectDescription", "Main subject"),
                pose = pose,
                poseDetail = poseDetail,
                subjectPosition = SubjectPosition.fromRaw(parsed.optString("subjectPosition", "center")),
                cameraAngle = cameraAngle,
                cameraDistance = cameraDistance,
                lightingDirection = lightingDirection,
                lightingType = parsed.optString("lightingType", "Natural daylight"),
                originalEnvironment = originalEnvironment,
                horizonY = parsed.optInt("horizonYPct", 50).coerceIn(20, 80) / 100f,
                groundLevelY = parsed.optInt("groundLevelYPct", 92).coerceIn(55, 100) / 100f,
                lightingDiagnosis = parsed.optString("lightingDiagnosis", "Balanced tonal range and natural color harmony."),
                recommendedBackgroundId = recs.firstOrNull()?.categoryId ?: BackgroundCategoryId.PROFESSIONAL_STUDIO,
                recommendedBackgrounds = recs.take(5),
                recommendedStyleId = styleId,
                adjustments = ColorAdjustments(
                    exposure = adjObj.optInt("exposure").coerceIn(-40, 40),
                    brightness = adjObj.optInt("brightness").coerceIn(-35, 35),
                    contrast = adjObj.optInt("contrast").coerceIn(-30, 40),
                    highlights = adjObj.optInt("highlights").coerceIn(-50, 35),
                    shadows = adjObj.optInt("shadows").coerceIn(-35, 50),
                    whites = adjObj.optInt("whites").coerceIn(-35, 35),
                    blacks = adjObj.optInt("blacks").coerceIn(-35, 35),
                    saturation = adjObj.optInt("saturation").coerceIn(-25, 30),
                    vibrance = adjObj.optInt("vibrance").coerceIn(-20, 35),
                    temperature = adjObj.optInt("temperature").coerceIn(-35, 35),
                    tint = adjObj.optInt("tint").coerceIn(-25, 25),
                    sharpness = adjObj.optInt("sharpness").coerceIn(0, 45),
                    clarity = adjObj.optInt("clarity").coerceIn(-15, 35),
                    colorBalance = adjObj.optInt("colorBalance").coerceIn(-25, 25),
                    skinTone = adjObj.optInt("skinTone").coerceIn(-25, 25),
                    noiseReduction = adjObj.optInt("noiseReduction").coerceIn(0, 40),
                ),
            )
        } finally {
            conn.disconnect()
        }
    }
}
