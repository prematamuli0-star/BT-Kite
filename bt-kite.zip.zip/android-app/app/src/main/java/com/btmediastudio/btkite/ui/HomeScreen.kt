package com.btmediastudio.btkite.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btmediastudio.btkite.data.SamplePhotoPreset
import com.btmediastudio.btkite.data.StudioPresets
import com.btmediastudio.btkite.engine.ImageEngine
import com.btmediastudio.btkite.ui.theme.InkMuted
import com.btmediastudio.btkite.ui.theme.InkPrimary
import com.btmediastudio.btkite.ui.theme.InkSecondary
import com.btmediastudio.btkite.ui.theme.KiteBlue
import com.btmediastudio.btkite.ui.theme.KiteBlueSoft
import com.btmediastudio.btkite.ui.theme.StudioBorder
import com.btmediastudio.btkite.ui.theme.StudioCanvasBg
import com.btmediastudio.btkite.ui.theme.StudioWhite
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun BTKiteBrandMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(KiteBlue),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(22.dp)) {
            val w = size.width
            val h = size.height
            val diamond = Path().apply {
                moveTo(w * 0.5f, h * 0.05f)
                lineTo(w * 0.92f, h * 0.45f)
                lineTo(w * 0.5f, h * 0.96f)
                lineTo(w * 0.08f, h * 0.45f)
                close()
            }
            drawPath(diamond, color = Color.White)
            val facet = Path().apply {
                moveTo(w * 0.5f, h * 0.05f)
                lineTo(w * 0.92f, h * 0.45f)
                lineTo(w * 0.5f, h * 0.45f)
                close()
            }
            drawPath(facet, color = Color(0xFFBFDBFE))
            drawLine(
                color = KiteBlue,
                start = Offset(w * 0.5f, h * 0.05f),
                end = Offset(w * 0.5f, h * 0.96f),
                strokeWidth = 2f,
            )
        }
    }
}

@Composable
fun HomeScreen(
    onPickFromGallery: () -> Unit,
    onCaptureFromCamera: () -> Unit,
    onSelectSample: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioCanvasBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // Clean Studio Header
        Surface(color = StudioWhite) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BTKiteBrandMark()
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "BT Kite",
                                style = MaterialTheme.typography.titleMedium,
                                color = InkPrimary,
                            )
                            Text(
                                text = "BT Media Studio",
                                fontSize = 11.sp,
                                color = InkMuted,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                    }
                    Text(
                        text = "AI Photo Studio",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = KiteBlue,
                    )
                }
                HorizontalDivider(color = StudioBorder)
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            // Hero Studio Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = StudioWhite),
                border = BorderStroke(1.dp, StudioBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = KiteBlue,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Scene-Aware Auto Background · 16-Slider AI Color Tune",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = KiteBlue,
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Transform everyday photos into studio-grade shots.",
                        style = MaterialTheme.typography.headlineSmall,
                        color = InkPrimary,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Analyze subject pose, perspective, and lighting direction automatically, replace backgrounds with grounded shadows, and export in full resolution.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = InkSecondary,
                    )

                    Spacer(Modifier.height(18.dp))

                    Button(
                        onClick = onPickFromGallery,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = KiteBlue),
                    ) {
                        Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Upload Photo from Gallery", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onCaptureFromCamera,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, StudioBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = KiteBlueSoft,
                            contentColor = KiteBlue,
                        ),
                    ) {
                        Icon(Icons.Rounded.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Take Photo with Camera", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            // Sample Photos Section
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "Try with Sample Studio Photos",
                        style = MaterialTheme.typography.titleMedium,
                        color = InkPrimary,
                    )
                    Text(
                        text = "Instant offline",
                        fontSize = 12.sp,
                        color = InkMuted,
                    )
                }

                StudioPresets.samplePhotos.forEach { sample ->
                    SamplePhotoCard(
                        preset = sample,
                        onClick = { onSelectSample(sample.assetPath) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SamplePhotoCard(
    preset: SamplePhotoPreset,
    onClick: () -> Unit,
) {
    val context = LocalContext.current
    val thumb = produceState<Bitmap?>(initialValue = null, preset.assetPath) {
        value = withContext(Dispatchers.IO) {
            runCatching { ImageEngine.loadBitmapFromAsset(context, preset.assetPath) }.getOrNull()
        }
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = StudioWhite),
        border = BorderStroke(1.dp, StudioBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(KiteBlueSoft),
            ) {
                thumb.value?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = preset.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = preset.category,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = KiteBlue,
                )
                Text(
                    text = preset.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = preset.subtitle,
                    fontSize = 12.sp,
                    color = InkSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
