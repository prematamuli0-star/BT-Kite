# Keep ML Kit Subject Segmentation runtime classes
-keep class com.google.mlkit.vision.segmentation.subject.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_subject_segmentation.** { *; }
