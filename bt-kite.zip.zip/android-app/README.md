# BT Kite — Native Android App (Kotlin + Jetpack Compose)

Developed by **BT Media Studio** · Minimum Android 8.0 (`minSdk = 26`) · Target Android 15 (`targetSdk = 35`).

## Features Included
- **Photo Gallery Picker & Full-Res Camera Capture** with automatic EXIF orientation handling
- **On-Device AI Background Removal** powered by Google ML Kit Subject Segmentation (free, runs locally on-device)
- **Scene-Aware Auto Background & Top 5 Ranked Recommendations** analyzing subject pose, position, camera angle, camera distance, lighting direction, and ground contact level
- **Photorealistic Blending Engine** preserving exact subject size & position (`100%` scale), perspective horizon alignment, distance-matched depth-of-field blur, directional relighting with skin protection, edge light-wrap, and grounded Ambient Occlusion + perspective cast shadows
- **AI Color Tune, AI Enhance & Portrait Enhance** driving 16 real-time pixel adjustments (Light, Color, Detail) + 16 Color Styles
- **Interactive Brush Object Removal** with real onion-peel + harmonic relaxation inpainting
- **Crop, Rotate, Flip, Text & Studio Stickers**
- **Interactive Before/After Split Comparison**
- **High-Resolution Gallery Export** (`Pictures/BT Kite`) in JPG, PNG, and Transparent Cutout PNG

## Build the APK in Android Studio
1. Open the `android-app/` folder in **Android Studio** (Ladybug / Jellyfish or newer with JDK 17).
2. *(Optional)* Add `GEMINI_API_KEY=your_free_tier_key` to `android-app/local.properties` to enable Gemini Vision (`gemini-4-hydrogen`) scene understanding on top of BT Kite's built-in on-device Local Vision engine.
3. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)** (or run `./gradlew assembleDebug` / `./gradlew assembleRelease` from a machine with JDK 17 + Android SDK installed).
   - Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`
