# BT Kite — AI Photo Studio by BT Media Studio

**BT Kite** is a mobile-first, installable Progressive Web App (PWA) designed to transform everyday photos into studio-grade imagery with one-tap AI automation. Built around a crisp white-and-blue professional interface, it pairs flagship **Automatic AI Background Replacement** and **Automatic AI Color Tuning** with a complete suite of non-destructive local editing, comparison, and high-resolution export tools.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Your Phase 1 preferences have been locked into this blueprint. Please review the confirmed decisions and the API key note below before approving execution.

- **Confirmed — Installable Mobile-First PWA**: Responsive architecture optimized for Android thumb-zone ergonomics on phones and expanding into a full-viewport studio workspace on desktop, complete with Web App Manifest, service worker offline caching for local edits, and an in-app **Install App** trigger.
- **Confirmed — Home Hub Landing Experience**: Opens to a clean BT Kite studio hub featuring **Upload Photo**, **Take Photo (Camera)**, and curated **Sample Studio Photos** for instant testing of Auto Background and AI Color Tune.
- **Confirmed — Hybrid AI Color Tune & Brush Object Removal**: **AI Color Tune** runs Gemini vision analysis to identify the scene, correct lighting/skin tones, and automatically populate all 16 live adjustment sliders (so users can fine-tune or apply any of the 15 color styles immediately without losing control). **Object Removal** lets users paint directly over unwanted elements with an interactive adjustable brush (plus optional text guidance) for seamless AI inpainting.
- **Confirmed — Fast vs. Studio HD Quality Toggle**: Users can switch seamlessly inside the workspace between **Fast** mode (quicker turnaround via `gemini-3.1-flash-lite-image`) and **Studio HD** mode (higher-detail 2K rendering via `gemini-nano-banana-2.1`).
- **Paid Gemini Image Model Setup**: Because Gemini's image editing and generation models (`gemini-3.1-flash-lite-image` and `gemini-nano-banana-2.1`) require a billing-enabled API key, we will prompt you to select your API key through the built-in AI Studio key selector during implementation. All Gemini calls will execute securely on the server.

---

## 1. Overview & Core Concept

- **What It Does**: BT Kite turns casual smartphone snapshots into polished portraits, product shots, ID photos, and editorial visuals in a single tap. Users upload or snap a photo, tap **Auto Background** or **AI Color Tune** (or **AI Enhance**, **Portrait Enhance**, **Object Removal**, **AI Background Generator**), inspect the result with an interactive Before/After drag slider, fine-tune locally with Crop, Adjust, Filters, Text, and Stickers, and export in JPG, PNG, or true alpha-transparent PNG.
- **Target Audience**: Everyday Android mobile creators, small business sellers, portrait subjects, and casual photographers who want Lightroom/Picsart-level polish without learning complex manual masking or color grading.
- **Key Value**: Eliminates multi-step manual masking and guesswork. Every AI action analyzes the image first, preserves fine edges like hair and clothing, matches subject lighting and shadows to new scenes, keeps the original photo untouched, and supports instant Undo/Redo and cancellation.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Home Hub → Image Intake**:
   - User opens BT Kite on Android or desktop to a crisp white studio hub branded **BT Kite** (by BT Media Studio) with an **Install App** action when not yet installed.
   - Three immediate entry paths: **Upload Photo** (device gallery/drag-and-drop), **Camera** (direct mobile/desktop camera capture), or tapping any of 4 curated **Sample Photos** (portrait, product, event, street/outdoor) to test AI tools immediately.
2. **One-Tap Auto Background & Background Studio**:
   - Inside the Editor, tapping the prominent **Auto Background** button runs a two-stage pipeline: Gemini analyzes subject type, pose, lighting, and attire → automatically selects the optimal studio/environment direction → generates and blends a realistic new background with matching lighting, shadows, color temperature, and edge fidelity.
   - Users can also browse all **15 Background Categories** (Professional Studio, Passport / ID Photo, Office, Wedding, Luxury, Nature, Mountains, Beach, Sunset, City, Cinematic, Fashion, Business Portrait, Product Photography, Custom AI Background), write a **Custom AI Prompt**, or tap **Remove Background (Transparent PNG)** to isolate the subject onto a true alpha-transparent checkerboard canvas.
3. **One-Tap AI Color Tune & Live Grading**:
   - Tapping **AI Color Tune** inspects the photo with Gemini Vision to classify the scene (Portrait, Landscape, Wedding, Food, Product, Night, Indoor, Outdoor, Nature, Street, Professional), diagnose exposure/white-balance/skin-tone issues, and automatically dial in natural values across all **16 live adjustment sliders** (Exposure, Brightness, Contrast, Highlights, Shadows, Whites, Blacks, Saturation, Vibrance, Temperature, Tint, Sharpness, Clarity, Color Balance, Skin Tone, Noise Reduction) while recommending a matching style.
   - Users can switch across all **15 Professional Color Styles** (Natural, Cinematic, Professional Portrait, HDR, Warm, Cool, Luxury, Wedding, Film, Vintage, Modern, Vibrant, Moody, Soft, Golden Hour) or refine any individual slider in real time with instant Before/After preview.
4. **Full AI Suite & Local Creative Tools**:
   - **AI Enhance**: One-click overall clarity, lighting balance, denoise, and natural detail restoration.
   - **Portrait Enhance**: Subtle studio skin-tone balance, eye/hair crispness, and portrait lighting lift without plastic over-smoothing.
   - **Object Removal**: Interactive touch/mouse brush canvas overlay (adjustable brush size, eraser, clear/undo stroke, optional hint) that paints a mask over distractions and removes them seamlessly.
   - **Local Tools**: Non-destructive **Crop & Rotate** (aspect presets + freeform + 90° rotate + flip), **Adjust** (16 sliders), **Filters** (15 color styles + intensity), **Text** (custom typography, color, size, alignment, drag placement), and **Stickers** (crisp studio badges/shapes, drag & scale).
5. **Compare, Inspect & Export**:
   - Drag the **Before / After** split curtain smoothly across the photo, zoom up to 400% with pan, or open **Fullscreen Preview**.
   - Tap **Save** to open the Export Sheet: choose **JPG**, **PNG**, or **Transparent PNG** (enabled when background is removed), adjust quality (60%–100%), view exact output resolution, **Download**, or **Share** natively via the Web Share API (`navigator.share`) on Android.

### Visual Identity & Theme

- **Aesthetic Direction**: Clean, daylight-legible creative studio inspired by Adobe Lightroom Mobile and high-craft minimalist photography tools — letting the user's photograph remain the dominant focal anchor while chrome stays airy and restrained.
- **Color Palette & 60-30-10 Budget**:
  - *60% Dominant Neutral Canvas*: Pure White (`--background: #FFFFFF`) and Cool Studio Alabaster (`--surface-subtle: #F8FAFC`) for the canvas backdrop.
  - *30% Structural Surfaces & Typography*: Soft Slate dividers (`--border: #E2E8F0`), Light Slate recessed controls (`--surface-muted: #F1F5F9`), Deep Ink primary text (`--foreground: #0F172A`), and Slate secondary labels (`--muted-foreground: #64748B`).
  - *10% Focused Brand Accent*: Studio Cobalt Blue (`--primary: #2563EB`, hover `#1D4ED8`, soft active tint `#EFF6FF`, accessible blue-900 ink on tint) reserved strictly for primary CTAs (**Auto Background**, **Save**, active tool states, slider fills).
  - Semantic error/warning feedback pairs color with clear icons and explicit text (never hue-only).
- **Typography & Hierarchy**:
  - *Display & UI Headings*: `Plus Jakarta Sans` (SemiBold 600 / Bold 700, tight tracking) for brand wordmark, sheet titles, and primary section headings.
  - *Body & Control Labels*: `DM Sans` (Regular 400 / Medium 500) for crisp legibility across compact mobile toolbars and sliders.
  - *Precision Readouts*: `JetBrains Mono` with `tabular-nums` strictly for numeric slider readouts, zoom percentages, and export dimensions.
  - Clean unboxed metadata using subtle `·` separators (zero decorative pill enclosures, zero thick left accent borders, zero fake telemetry tickers).
- **Responsive Layout & Thumb-Zone Ergonomics**:
  - *Mobile (375px–430px)*: Compact 52px sticky Top Bar (`Back`, `Undo`, `Redo`, `Compare`, `Save`), expansive center photo stage, and a thumb-reachable Bottom Toolbar (`Crop`, `Adjust`, `Filters`, `Background`, `AI`, `Text`, `Stickers`) that raises clean `rounded-t-3xl` slide-up control sheets. All touch targets meet `≥ 44×44px` hitboxes and sticky chrome remains compact.
  - *Desktop (1024px–1440px+)*: Expands into a full-viewport studio layout — top utility bar, spacious central interactive photo viewport, and a dedicated right-hand Studio Inspector panel (360px) with the 7 tool categories cleanly docked on the side/bottom rail so desktop users get an unobstructed Lightroom-class workspace.

### Interactive Feedback & Motion

- **Tactile Micro-Interactions**: Fast `150ms–200ms` settling transitions on sheet reveals, slider snaps, and active tabs (`cubic-bezier(0.16, 1, 0.3, 1)`), respecting `prefers-reduced-motion`.
- **Cancellable AI Processing Overlay**: Translucent luminous blue scan shimmer over the active image displaying real progress steps (e.g., *"Analyzing subject & lighting..."*, *"Blending studio background..."*) alongside an always-reachable **Cancel** button that aborts the in-flight request cleanly.
- **Resilient Error & Offline States**: Non-intrusive offline indicator banner when disconnected (local tools stay 100% functional while AI buttons inform the user connectivity is required); clear retryable error banners if an AI request fails or times out — never substituting fake results.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Dual-Engine AI Pipeline (Gemini Vision + Gemini Image Editing)**
  - *Chosen Approach*: Use `gemini-4-hydrogen` with structured JSON schemas for fast scene analysis, background style recommendation, and 16-slider **AI Color Tune** calculation; use `gemini-3.1-flash-lite-image` (Fast) and `gemini-nano-banana-2.1` (Studio HD) for pixel-level background replacement, AI Enhance, Portrait Enhance, and Brush Object Removal.
  - *Why*: Users get instant, non-destructive, editable sliders for color tuning rather than a black-box result, while structural edits like background replacement and object removal benefit from full generative relighting and shadow synthesis.
  - *Alternatives Considered*: Using image generation for every adjustment (slower, destroys slider fine-tuning, risks altering facial identity during simple color edits).
- **Decision 2 — True Alpha-Transparent PNG Cutout Pipeline**
  - *Chosen Approach*: When the user selects **Remove Background (Transparent PNG)**, the server instructs Gemini image editing to isolate the subject cleanly onto a high-contrast uniform chroma key backdrop (chosen dynamically to contrast the subject's colors), followed by a client-side canvas edge-matting and color-despill pass that converts the backdrop to genuine alpha transparency (`alpha = 0`).
  - *Why*: Generative image models return opaque RGB images without an alpha channel; pairing semantic subject isolation with precision edge-despill matting delivers authentic transparent PNG downloads and lets users preview the cutout over a checkerboard or swap solid/gradient studio backdrops instantaneously.
  - *Alternatives Considered*: Returning a white-background JPG and calling it "transparent" (unacceptable for real PNG export requirements).
- **Decision 3 — Non-Destructive Layered State with Snapshot History**
  - *Chosen Approach*: Keep `originalImage` immutable forever. Maintain a history stack (`past`, `present`, `future`) where each state holds the current base raster image (updated by AI edits or baked crops), the 16 live color adjustment parameters, active filter preset, transform/crop settings, text layers, sticker layers, and transparency flag.
  - *Why*: Guarantees instant Undo/Redo across both AI generations and manual edits, instantaneous live Before/After comparison against the untouched original, and zero accidental overwriting of user photos.
- **Decision 4 — Full-Stack Server Proxy Architecture**
  - *Chosen Approach*: Run an Express backend (`server.ts`) co-located with Vite on port 3000 to proxy all `@google/genai` vision and image-editing calls through `/api/ai/*` routes, supporting request cancellation and generous base64 image payload limits.
  - *Why*: Keeps `GEMINI_API_KEY` strictly server-side, centralizes retry/error normalization, and supports clean `AbortSignal` teardown when users cancel processing.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌────────────────────────────────────────────────────────────────────────────┐
│                     BT Kite PWA (React + TypeScript)                       │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  Editor Store (Immutable Original + Undo/Redo History + Active Tool) │  │
│  └───────────────┬──────────────────────────────────────┬───────────────┘  │
│                  │                                      │                  │
│     ┌────────────▼────────────┐          ┌──────────────▼───────────────┐  │
│     │      Home Hub View      │          │     Editor Workspace View    │  │
│     │  • Upload / Camera /    │          │  • Top Bar (Undo/Redo/Save)  │  │
│     │    Sample Studio Photos │          │  • Photo Stage Canvas        │  │
│     │  • PWA Install Banner   │          │    - Live 16-Param Pipeline  │  │
│     └─────────────────────────┘          │    - Before/After Slider     │  │
│                                          │    - Zoom/Pan & Fullscreen   │  │
│                                          │    - Interactive Brush Mask  │  │
│                                          │    - Draggable Text/Stickers │  │
│                                          │  • Bottom Dock / Side Panel  │  │
│                                          │    - AI Hub (6 Major Tools)  │  │
│                                          │    - Background Studio (15)  │  │
│                                          │    - Color Tune & Adjust(16) │  │
│                                          │    - Filters(15) / Crop      │  │
│                                          │    - Text / Stickers         │  │
│                                          │  • Export & Share Modal      │  │
│                                          └──────────────┬───────────────┘  │
└─────────────────────────────────────────────────────────┼──────────────────┘
                                                          │ HTTP POST + AbortSignal
                                                          ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                   Express API Server (Port 3000 + Vite)                    │
│  ┌───────────────────────────┐   ┌──────────────────────────────────────┐  │
│  │ POST /api/ai/analyze-tune │   │ POST /api/ai/edit-image              │  │
│  │ • Scene classification    │   │ • Auto Background / 15 Categories    │  │
│  │ • Best BG recommendation  │   │ • Custom AI Background Prompt        │  │
│  │ • 16 Color Tune sliders   │   │ • Chroma Isolation (Transparent PNG) │  │
│  │ • Recommended Color Style │   │ • AI Enhance / Portrait Enhance      │  │
│  └─────────────┬─────────────┘   │ • Brush-Masked Object Removal        │  │
│                │                 └──────────────────┬───────────────────┘  │
│                ▼                                    ▼                      │
│     Gemini Vision (gemini-4-hydrogen)    Fast: gemini-3.1-flash-lite-image │
│     Structured JSON responseSchema       HD:   gemini-nano-banana-2.1 (2K) │
└────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Immutable Source Record**: Stores the original uploaded/captured image data URL, natural width/height, aspect ratio, filename, and MIME type — never overwritten without explicit user confirmation when replacing the active photo.
- **Edit Snapshot (`EditorSnapshot`)**:
  - `baseImageUrl`: Current working raster image (initially the original; updated after AI image edits, transparent matting, or confirmed crop).
  - `hasTransparency`: Boolean indicating whether the subject has an alpha-transparent cutout (enables checkerboard canvas & Transparent PNG export).
  - `adjustments`: All 16 numeric sliders (`exposure`, `brightness`, `contrast`, `highlights`, `shadows`, `whites`, `blacks`, `saturation`, `vibrance`, `temperature`, `tint`, `sharpness`, `clarity`, `colorBalance`, `skinTone`, `noiseReduction`).
  - `activeStyle`: Selected color style preset from the 15 professional styles + intensity (`0–100`).
  - `transform`: Rotation (`0°/90°/180°/270°`), horizontal/vertical flip flags.
  - `textLayers`: Array of positioned, styled text annotations (`id`, `text`, `x`, `y`, `fontSize`, `color`, `fontFamily`, `align`, `bgStyle`).
  - `stickerLayers`: Array of positioned vector studio stickers (`id`, `stickerId`, `x`, `y`, `scale`, `rotation`).
- **AI Session State**: Tracks `qualityMode` (`"fast" | "studio_hd"`), active `processingJob` (label, stage, `AbortController`), last AI analysis summary (detected photo category, lighting diagnosis, chosen background recommendation), and recoverable error message.

### Interactive Component & State Mapping

- **Home Intake & Camera Modal**: File input + drag-and-drop validates image MIME/size and loads into the immutable source store; Camera modal streams live `getUserMedia` (rear camera default on Android, toggle front/back) and captures a full-res frame; clicking any Sample Photo loads it directly into the Editor.
- **Top Bar Controls**: `Back` confirms if unsaved edits exist before returning to Home; `Undo`/`Redo` step through `past`/`future` snapshots cleanly; `Compare` toggles the interactive Before/After drag slider (plus press-and-hold quick peek); `Save` opens the Export & Share modal.
- **Canvas Render Pipeline**: Real-time offscreen & visible HTML5 Canvas compositor applies pixel-level tonal curves (Exposure, Highlights, Shadows, Whites, Blacks, Temperature, Tint, Vibrance, Saturation, Skin Tone, Color Balance), convolution passes (Sharpness, Clarity, Noise Reduction), active Filter Style blend, rotation/flip, and interactive draggable Text/Sticker layers — ensuring WYSIWYG parity between live preview and final exported file.
- **AI Tools & Background Studio**:
  - Pressing **Auto Background** invokes `/api/ai/analyze-tune` (to understand subject, attire, and best studio direction) followed immediately by `/api/ai/edit-image` (to generate & blend the background with matched lighting and realistic shadows), pushing the result as a new Undoable snapshot.
  - Selecting any of the **15 Background Categories** or submitting a **Custom Prompt** runs `/api/ai/edit-image` with tailored photographic lighting/shadow prompts.
  - Pressing **Remove Background** isolates the subject via `/api/ai/edit-image` and runs the client-side chroma-key edge-despill matting engine to produce a true alpha-transparent PNG snapshot.
  - Pressing **AI Color Tune** calls `/api/ai/analyze-tune`, displays the concise photo analysis insight (detected type + lighting diagnosis), and animates all 16 live sliders + style preset to the AI-recommended natural settings in one undoable step.
  - Selecting **Object Removal** activates the interactive brush overlay canvas on top of the photo; users draw blue mask strokes (with brush size, eraser, undo stroke, and optional text hint) and tap **Remove Object**, sending both the source photo and high-contrast mask image to `/api/ai/edit-image` for clean inpainting.
  - Pressing **AI Enhance** or **Portrait Enhance** calls `/api/ai/edit-image` with preservation-first studio enhancement directives.
  - Pressing **Cancel** during any AI call triggers `AbortController.abort()`, stops the loading overlay immediately, and preserves prior state cleanly.
- **Export & Share Modal**: Renders the final composited full-resolution canvas (preserving original pixel resolution wherever possible), supports **JPG** (quality 60%–100%), **PNG**, and **Transparent PNG** (when cutout is active), displays live file size & resolution, and triggers either direct file download or native Android share sheet (`navigator.share` with `File` fallback to download).

### Key Sequences & Integrations

- **Server-Side Gemini Proxy (`/api/ai/*`)**: Uses `@google/genai` (upgraded to latest) initialized strictly server-side with `process.env.GEMINI_API_KEY` and `'User-Agent': 'aistudio-build'`. Includes structured JSON validation for vision analysis, closest-supported aspect ratio calculation for `imageConfig`, graceful HTTP error propagation, and clean client abort handling.
- **PWA Integration**: Configured via `vite-plugin-pwa` with `devOptions: { enabled: true }`, standalone manifest (`BT Kite`), custom generated 192×192, 512×512, maskable 512×512 (with 15% safe-zone padding), and 180×180 Apple touch PNG icons, Google Fonts caching, `usePWAInstall` hook, in-app `PWAInstallButton`, and `OfflineIndicator`.
